#include <Wire.h>
#include <SPI.h>
#include <Arduino.h>
#include "SensorPCF85063.hpp"

#ifndef SENSOR_SDA
#define SENSOR_SDA  8
#endif

#ifndef SENSOR_SCL
#define SENSOR_SCL  7
#endif


SensorPCF85063 rtc;
uint32_t lastMillis;

void setup()
{
    Serial.begin(115200);
    Wire.begin(SENSOR_SDA, SENSOR_SCL);
    if (!rtc.begin(Wire)) {
        while (1) {
        Serial.println("Failed to find PCF8563 - check your wiring!");
        delay(1000);
        }
    }
    RTC_DateTime datetime = rtc.getDateTime();

    if (datetime.getYear() < 2025) {
        rtc.setDateTime(2025, 1, 1, 12, 0, 0);
    }

}


void loop()
{
    if (millis() - lastMillis > 1000) {
        lastMillis = millis();
        RTC_DateTime datetime = rtc.getDateTime();
        Serial.printf(" Year :"); Serial.print(datetime.getYear());
        Serial.printf(" Month:"); Serial.print(datetime.getMonth());
        Serial.printf(" Day :"); Serial.print(datetime.getDay());
        Serial.printf(" Hour:"); Serial.print(datetime.getHour());
        Serial.printf(" Minute:"); Serial.print(datetime.getMinute());
        Serial.printf(" Sec :"); Serial.println(datetime.getSecond());

    }
}



