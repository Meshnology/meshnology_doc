#include <RadioLib.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <LittleFS.h>
#include <esp_rom_crc.h>
#include <esp32-hal-rgb-led.h>
#include <ctype.h>

#if __has_include("esp32-hal-psram.h")
  #include "esp32-hal-psram.h"
#endif

// The camera library is optional: without esp32-camera it falls back to the synthetic animation
#if __has_include("esp_camera.h")
  #include "esp_camera.h"
  #define CAM_LIB_OK 1
#else
  #define CAM_LIB_OK 0
#endif

// ==================== Radio SPI pins (same as 01~05) ====================
#define PIN_SCK     12
#define PIN_MISO    11
#define PIN_MOSI    10
#define PIN_NSS     47
#define PIN_DIO7    42
#define PIN_NRESET  39
#define PIN_BUSY    21
#define PIN_LED     48    // WS2812 RGB LED

// ==================== Button ====================
#define PIN_PTT     0     // BOOT button: board A toggles streaming

// ==================== Camera pins (W11 expansion board) ====================
// Note: these pins overlap the radio pins above, so only one of the two can be used
#define CAM_PIN_PWDN    -1
#define CAM_PIN_RESET   -1
#define CAM_PIN_XCLK    10
#define CAM_PIN_SIOD    40
#define CAM_PIN_SIOC    39
#define CAM_PIN_D7      48
#define CAM_PIN_D6      11
#define CAM_PIN_D5      12
#define CAM_PIN_D4      14
#define CAM_PIN_D3      16
#define CAM_PIN_D2      18
#define CAM_PIN_D1      17
#define CAM_PIN_D0      15
#define CAM_PIN_VSYNC   38
#define CAM_PIN_HREF    47
#define CAM_PIN_PCLK    13

#define USE_CAMERA      0

// Camera resolution / quality (smaller jpeg_quality = sharper, larger = less bandwidth)
#define CAM_FRAMESIZE   FRAMESIZE_QQVGA    // 160x120, JPEG about 4~6KB - the first choice for video
#define CAM_QUALITY     14

// ==================== FLRC parameters (both boards must match exactly) ====================
#define FLRC_FREQ       2450.0f
#define FLRC_BR         1300
#define FLRC_POWER      12            // dBm (2.4G max 12)
// 32 bits of preamble = 24.6us, enough for the receiver AGC to settle before the sync word.
// At 16 bits (12.3us) an isolated packet - or the first packet after a gap - is regularly
// missed, which is exactly the "块丢 28%" pattern seen on this link. Same fix as 05_photo.
#define FLRC_PRE        32

// ==================== Video link parameters ====================
#define VIDEO_CHUNK       192         // payload bytes per packet
#define VIDEO_MAX_CHUNKS  64          // totalChunks is uint8, but the buffer only keeps 64 chunks
#define VIDEO_BUF_CAP     (VIDEO_MAX_CHUNKS * VIDEO_CHUNK)   // 12288 bytes

#define PKT_TX_TIMEOUT    120         // max wait for TX_DONE per packet (ms)
// One short round trip per frame to resend whatever was lost. A JPEG frame is undecodable
// with a single missing chunk, and at 3% loss a 50-chunk frame is complete only ~24% of the
// time - that is why the picture froze even after the radio was fixed. Resending 1~2 chunks
// costs ~15ms out of a 500ms frame and lifts the complete rate to ~95%.
#define ACK_WAIT_MS       100         // time to wait for board B's bitmap
#define ACK_ROUNDS        2           // one retransmit pass; more only adds latency
#define GAP_MIN           1           // auto-tuned packet gap never goes below this

// Default synthetic frame size. 96x64 = 6144 bytes = 32 chunks, about 4~5fps
#define VID_DEF_W         96
#define VID_DEF_H         64

// ==================== WiFi AP ====================
// Both boards run an AP, with different SSIDs so the phone knows which one it joined:
//   board A (tx) -> W16-CAM  : preview + parameters
//   board B (rx) -> W16-LIVE : live view
#define AP_SSID_TX      "W16-CAM"
#define AP_SSID_RX      "W16-LIVE"
#define AP_PASS         "12345678"    // at least 8 chars
#define WEB_PORT        80

// ==================== Packet types ====================
#define PKT_VIDEO        1
#define PKT_CTRL         2            // frame ended, please report what you missed
#define PKT_ACK          3            // board B -> A: missing-chunk bitmap (bit=1 = still missing)
// ---- File transfer: same 192-byte chunking, but the payload is a slice of an H.264 file ----
#define PKT_FILE         4            // A -> B: one chunk of a file page (frameId = page index)
#define PKT_FCTRL        5            // A -> B: file page ended, please report what you missed
#define PKT_FDONE        6            // A -> B: whole file sent, here is the size and CRC32
#define PKT_FACK         7            // B -> A: file stored, flags bit0 = CRC matched
#define PKT_FBEGIN       8            // A -> B: about to send a file (size, CRC32, page count)

// ==================== Frame formats ====================
#define FMT_RGB332       0            // 1 byte per pixel, expanded per pixel by canvas
#define FMT_JPEG         1            // straight from the camera, decoded by createImageBitmap
#define FMT_FILE         2            // opaque bytes: an H.264/MP4 file page, stored as-is

// ==================== File transfer parameters ====================
// A page is one "frame" worth of bytes: 64 chunks x 192 = 12288. The sender's browser keeps
// the whole file in memory and POSTs one page at a time, so board A never needs a filesystem -
// it only needs one page buffer, and the radio (10~25KB/s) never has to wait for the phone.
#define FILE_PAGE_BYTES   VIDEO_BUF_CAP
// 4.5MB, not 1.1MB: partitions.csv in this folder widens LittleFS from 1.5MB to 4.7MB by giving
// up the unused OTA slot. The cap is what decides how many bits per second the encoder may spend
// on a clip of a given length, so it is a picture-quality knob, not just a storage limit.
#define FILE_MAX_BYTES    (4608 * 1024)
#define FILE_PATH         "/w16.mp4"
// A tiny marker written only after the CRC check passes. Without it a half-received MP4 stays
// on flash, still looks like a file, and plays as a black screen - which reads as "the transfer
// worked but the video is broken". The page only offers a file that has this next to it.
#define FILE_OK_PATH      "/w16.ok"
#define FILE_ACK_WAIT_MS  500             // per round; board B answers only after writing the page
#define FILE_ACK_ROUNDS   8               // and retry more: a single hole ruins the whole file
#define FILE_PAGE_TRIES   3               // whole-page re-receives before calling the page dead

// ==================== Air frame ====================
// 12-byte header + 192 bytes of data = 204-byte fixed packet
struct __attribute__((packed)) VideoPacket {
    uint8_t  type;
    uint8_t  frameId;
    uint8_t  totalChunks;
    uint8_t  chunkIdx;
    uint8_t  format;
    uint8_t  flags;       // bit0 = key frame (reserved)
    uint16_t w;           // width (the camera may be 160/320, so uint16)
    uint16_t h;
    uint16_t frameLen;
    uint8_t  data[VIDEO_CHUNK];
};

// ==================== Roles ====================
enum Role { ROLE_IDLE = 0, ROLE_TX = 1, ROLE_RX = 2 };

Role gRole = ROLE_IDLE;

// ---- Forward declarations ----
// arduino-cli's auto prototype generation fails on this file (the embedded HTML/JS raw
// strings confuse its parser), so every function used before its definition must be
// declared here, otherwise: error: 'pollSerial' was not declared in this scope
void pollSerial();

// ==================== Radio ====================
// SPI clock matters far more here than it looks. RadioLib's Arduino HAL moves bytes one at a
// time (`in[i] = spi->transfer(out[i])`), so a 204-byte packet is 204 separate transfers, and
// every command and every IRQ poll is another transaction. The default is 2MHz - at that rate
// one packet's SPI traffic costs about as much time as its own air time, which is why the link
// sat at ~15KB/s instead of the ~45KB/s the 1300kbps rate allows. 8MHz is well inside the
// LR2021's 16MHz SPI limit and cuts that overhead by roughly 4x.
Module mod(PIN_NSS, PIN_DIO7, PIN_NRESET, PIN_BUSY, SPI, SPISettings(8000000, MSBFIRST, SPI_MODE0));
LR2021 radio(&mod);

// ==================== Global buffers ====================
// Three buffers with one job each, never used at the same time (only one role runs):
//   txBuf   board A: the frame being sent (the page previews it too)
//   rxBuf   board B: the frame being reassembled (overwritten by the next one)
//   liveBuf board B: last complete frame (read by the page, never torn by reassembly)
// 12288 x 3 = 36KB, PSRAM first, internal heap as fallback.
uint8_t* txBuf   = nullptr;
uint8_t* rxBuf   = nullptr;
uint8_t* liveBuf = nullptr;

// ==================== Parameters (serial / web) ====================
// Packet gap is the single most expensive knob on this link: air time for a 204-byte packet is
// only 1.3ms, while the SPI/command overhead around it is ~4.5ms. At gap 3 that is fine, but a
// gap of 13 (easy to leave on the slider) makes the gap 70% of every packet - the link then
// runs at a third of its capability. So the gap is no longer a value to guess at: it starts
// small and self-tunes from the ACK bitmap. Fewer clean frames -> try one ms less; any real
// loss -> back off. The slider / `gap N` only sets the ceiling.
uint8_t  gGapMs     = 2;      // current, auto-tuned
uint8_t  gGapMax    = 6;      // ceiling, set by `gap N` / the page slider
uint8_t  gapClean   = 0;      // consecutive frames that arrived with zero missing chunks
uint8_t  gTargetFps = 4;      // frame rate cap, 0 = unlimited
uint8_t  gPattern   = 1;      // synthetic animation style
uint16_t gVidW      = VID_DEF_W;
uint16_t gVidH      = VID_DEF_H;

// ==================== TX state ====================
uint8_t  gFrameId   = 0;
uint16_t txLastLen  = 0;
uint8_t  txLastFmt  = FMT_RGB332;
uint16_t txW        = 0, txH = 0;
volatile bool gStreaming  = false;   // streaming continuously
volatile bool gSendOne    = false;   // send a single frame

// ==================== Board A: frames pushed from the page (camera or local video) ====================
// The page draws to a canvas, packs RGB332 and POSTs /upframe?w=&h=&fmt=0; the board
// writes upBuf while receiving, then sets gUpReady and sendOneFrame() copies it to txBuf.
// A separate upBuf is needed because sending one frame takes tens of ms and calls
// webServer.handleClient() in between: writing straight into txBuf would tear the frame.
uint8_t* upBuf    = nullptr;
uint16_t upLen    = 0;
uint16_t upW      = 0, upH = 0;
uint8_t  upFmt    = FMT_RGB332;
volatile bool gUpReady = false;      // a complete page frame is waiting to be sent
bool     upBadEnc = false;
uint8_t  gSrcMode = 0;               // 0 = onboard (camera / animation), 1 = page push
uint32_t upFrames = 0, upDrops = 0;  // frames received / frames dropped
bool     txIdleLogged = false;       // "no frame yet" is reported only once

// ==================== File transfer: board A (sender) ====================
// The page holds the whole file and posts it page by page, so the board only ever needs one
// page in RAM. Flow: /fsend (open) -> /fpage?seq=N x pages -> /fdone (verify) ; the page
// waits for filePage to pass N before posting N+1, which is the flow control: the radio is
// roughly ten times slower than HTTP, and without it the upload would pile up in RAM.
uint8_t* fileBuf      = nullptr;      // FILE_PAGE_BYTES, the page being posted
volatile bool gFilePageReady = false; // a page is buffered and waiting to be transmitted
volatile bool filePageBusy   = false; // fileSendPage() is running: fileBuf must not be touched
bool     filePageReject = false;      // an upload arrived while busy, answer 409 at the end
uint16_t filePageLen  = 0;            // bytes in the buffered page
uint16_t filePageSeq  = 0;            // which page the buffered data belongs to
volatile bool fileActive  = false;    // a transfer is in progress
uint16_t filePages    = 0;            // total pages in this file
uint32_t fileTotal    = 0;            // total bytes
uint32_t fileCrc      = 0;            // CRC32 the sender computed over the whole file
volatile uint16_t filePageDone = 0;   // pages already transmitted (the page polls this)
uint8_t  fileState    = 0;            // 0 idle, 1 sending, 2 done, 3 failed
char     fileErr[48]  = "";
uint32_t fileSentMs   = 0;
// Transfer id. Board A retries PKT_FBEGIN up to 4 times, and board B used to treat every one
// of them as "new transfer" - it deleted the file and jumped back to page 0, which is fatal if
// the duplicate arrives late. With an id, a repeated BEGIN for the same transfer is just re-ACKed.
uint16_t fileTid      = 0;

// ==================== File transfer: board B (receiver) ====================
// A page is collected in RAM and only written to flash once it is complete: flash programming
// stalls the cache for tens of ms, and doing that per 192-byte chunk would starve the radio.
uint8_t* fileRxBuf    = nullptr;      // FILE_PAGE_BYTES
uint8_t  fileRxHave[32];
uint8_t  fileRxChunks = 0;
uint8_t  fileRxGot    = 0;
uint16_t fileRxPage   = 0;
uint16_t fileRxPageLen = 0;
bool     fileRxPageStored = false;    // this page is already on flash: a repeated FCTRL is just re-ACKed
uint8_t  fileRxPageTries  = 0;        // whole-page re-receives for the current page (CRC said no)
bool     fileRxActive = false;
uint16_t fileRxPages  = 0;
uint32_t fileRxTotal  = 0;
uint32_t fileRxCrc    = 0;
uint16_t fileRxTid    = 0;            // transfer id from PKT_FBEGIN
uint32_t fileRxWritten = 0;
uint8_t  fileRxState  = 0;            // 0 idle, 1 receiving, 2 stored, 3 failed
char     fileRxName[24] = "w16.mp4";
File     fileOut;

// ==================== RX state ====================
uint8_t  rxHave[32];                 // received-chunk bitmap (up to 256 chunks, only the first 64 are used)
uint8_t  rxCurId      = 0;
uint8_t  rxCurTotal   = 0;
uint16_t rxCurLen     = 0;
uint16_t rxGot        = 0;
uint16_t rxCurW       = 0, rxCurH = 0;
uint8_t  rxCurFmt     = FMT_RGB332;

// last displayable frame (the page reads this)
// Note: a 100% complete frame is not required - publish once more than half of the
// chunks are in and keep the previous pixels for the missing ones. All 32 chunks
// arriving is far too unlikely (6% loss leaves only 12% complete), so partial frames
// are the only way to keep the picture moving.
uint16_t liveLen  = 0;
uint16_t liveW    = 0, liveH = 0;
uint8_t  liveFmt  = FMT_RGB332;
volatile uint32_t liveSeq = 0;       // incremented per published frame, the page uses it to detect new frames

// ==================== Counters ====================
uint32_t txFrames = 0, txPkts = 0, txBytes = 0;
// Per-packet cost probe. Air time for 204 bytes at 1300kbps is only ~1.3ms; if the measured
// cost is several times that, the time is going into SPI / IRQ polling, not the radio - and
// that is the number to attack for throughput.
uint32_t txBusyUs = 0, txPollN = 0;
uint32_t txPrevFrames = 0, txPrevPkts = 0, txPrevBusyUs = 0, txPrevPollN = 0;
uint32_t txStatMs = 0;

uint32_t rxFrames = 0;               // frames assembled 100% complete
uint32_t rxShown  = 0;               // frames actually published (including partial ones)
uint32_t rxStarted = 0;              // frames started
uint32_t rxDropped = 0;              // frames with less than half the chunks, not published at all
uint32_t rxMissChunks = 0;           // accumulated missing chunks (block loss rate)
uint32_t rxPackets = 0, rxNoise = 0, rxOtherErr = 0;
// Length of the last packet that passed the radio's own CRC. A short packet is accepted by
// rxPoll (>= 12 bytes) but leaves the tail of the struct zeroed, so a file chunk could be
// marked "received" with 190 of its 192 bytes missing. The file path checks this; the live
// path does not, so a working video stream is not disturbed.
uint16_t gRxLastLen = 0;
uint32_t rxPrevFrames = 0;
uint32_t rxPrevShown  = 0;
uint32_t rxPrevPkts   = 0;
uint32_t rxPrevMiss   = 0;
uint32_t rxPrevNoise  = 0;
uint32_t rxStatMs = 0;
bool     rxSilent = true;            // true = no picture right now (used to print only on state change)
unsigned long lastErrPrint = 0;

// camera
bool gCamOk = false;

// Radio init result. Every radio call must be skipped when false, otherwise the main
// loop keeps printing startReceive FAIL and stalls.
bool gRadioOk = false;
// True while the chip is actually listening. startReceive() can fail with -707 (CMD_FAIL) on the
// very first call after power-up - the TCXO/calibration is not settled yet - and nothing used to
// retry it, so board B sat there deaf for the whole session while board A happily transmitted.
volatile bool gRxArmed = false;

// WiFi / Web
bool gWifiOn = false;
WebServer webServer(WEB_PORT);

// AP channel. 0 = automatic (ch1, farthest from the 2450MHz carrier), 1~11 = forced.
// Channel 1 is far from FLRC 2450MHz but is the most crowded one in practice - a weak
// beacon there gets buried and phones never see the SSID. 6 is much cleaner.
uint8_t gApChannel    = 0;
uint8_t gApChannelNow = 6;
uint8_t gApClients    = 0;
uint8_t gApPowerDbm   = 15;     // AP TX power: raise when the signal is weak, lower when the boards sit too close

// temporary SSID override for the "web" command (W16-WEB), nullptr normally
const char* gSsidOverride = nullptr;

// NVS: remember role / channel / power across reboots
Preferences prefs;

// ==================== Helpers ====================
static inline void bmSet(uint8_t* bm, uint16_t i)   { bm[i >> 3] |=  (uint8_t)(1u << (i & 7)); }
static inline bool bmGet(const uint8_t* bm, uint16_t i) { return (bm[i >> 3] >> (i & 7)) & 1u; }

static void bmClearAll(uint8_t* bm) { memset(bm, 0x00, 32); }

// CRC32 over a RAM buffer, same polynomial/init as the one the page computes in JS, so the two
// can be compared directly. Used to prove a whole page arrived *intact*: the chunk bitmap only
// proves that a packet arrived for every index, never that the bytes inside it were right.
// esp_rom_crc32_le() is the chained form (it inverts in and out), so feeding it block by block
// gives exactly the same result as one call over the whole buffer.
static uint32_t crc32Buf(const uint8_t* b, size_t n) {
    uint32_t c = 0;
    size_t off = 0;
    while (off < n) {
        size_t k = n - off;
        if (k > 1024) k = 1024;
        c = esp_rom_crc32_le(c, b + off, (uint32_t)k);
        off += k;
    }
    return c;
}

// RGB888 -> RGB332 (1-byte palette)
static inline uint8_t px332(uint8_t r, uint8_t g, uint8_t b) {
    return (uint8_t)((r & 0xE0) | ((g & 0xE0) >> 3) | (b >> 6));
}

// Triangle wave for a smooth gradient without sinf (faster than float, no jitter)
static inline uint8_t tri8(uint8_t v) { return (v < 128) ? (uint8_t)(v * 2) : (uint8_t)((255 - v) * 2); }

// ==================== LED ====================
void ledGreen() { neopixelWrite(PIN_LED, 0, 8, 0); }
void ledRed()   { neopixelWrite(PIN_LED, 8, 0, 0); }
void ledBlue()  { neopixelWrite(PIN_LED, 0, 0, 8); }
void ledOff()   { neopixelWrite(PIN_LED, 0, 0, 0); }

void blinkRed(int times) {
    for (int i = 0; i < times; i++) { ledRed(); delay(60); ledOff(); delay(60); }
}

// ==================== Radio init ====================
// RadioLib 8.0 removed the 7-argument beginFLRC() and turned it into beginFLRC(ConfigFLRC_t).
// That is not just a signature change - the units moved too:
//   v7: frequency in MHz (float), bitRate in kbps, tcxo voltage passed as the last argument
//   v8: frequency in Hz (uint32),  bitRate in bps,  tcxo voltage is a member set beforehand
// A sketch written for v7 fails to compile against v8 ("no matching function"), and one that
// merely switched to the struct would silently program 2450 Hz / 1300 bps. So build the config
// for whichever version is installed.
static int16_t beginFLRCCompat() {
#if defined(RADIOLIB_VERSION_MAJOR) && (RADIOLIB_VERSION_MAJOR >= 8)
    radio.tcxoVoltage = Voltage1V8;
    ConfigFLRC_t cfg;
    cfg.frequency      = (uint32_t)(FLRC_FREQ * 1000000.0f);   // Hz
    cfg.bitRate        = (uint32_t)FLRC_BR * 1000;             // bps
    cfg.codingRate     = RADIOLIB_LR2021_FLRC_CR_1_2;
    cfg.power          = FLRC_POWER;
    cfg.preambleLength = FLRC_PRE;
    cfg.dataShaping    = RADIOLIB_SHAPING_0_5;
    return radio.beginFLRC(cfg);
#else
    return radio.beginFLRC(FLRC_FREQ, FLRC_BR,
                           RADIOLIB_LR2021_FLRC_CR_1_2,
                           FLRC_POWER, FLRC_PRE,
                           RADIOLIB_SHAPING_0_5, 1.8);
#endif
}

// beginFLRC() order: setBitRate -> setCodingRate -> setOutputPower -> setPreambleLength
//   -> setDataShaping -> setSyncWord -> variablePacketLengthMode -> setCRC
// Once setOutputPower returns -706 (CMD_PERR), RADIOLIB_ASSERT skips the following steps,
// so sync word / packet mode / CRC are never applied. If only one end takes that path the
// two sides disagree and every packet fails CRC, hence each setting is re-applied here.
bool beginRadio() {
    radio.irqDioNum = 7;

    // Up to 3 attempts: right after power-up the TCXO may not be stable and a command can
    // fail with -707 (CMD_FAIL); one retry usually clears it. Wrong wiring fails all three.
    int16_t st = RADIOLIB_ERR_CHIP_NOT_FOUND;
    for (int attempt = 1; attempt <= 3; attempt++) {
        st = beginFLRCCompat();
        if (st == RADIOLIB_ERR_NONE || st == RADIOLIB_ERR_SPI_CMD_INVALID) break;
        Serial.print("[RADIO] 第"); Serial.print(attempt);
        Serial.print("次初始化失败 err="); Serial.println(st);
        delay(80);
    }

    bool needPatch = (st == RADIOLIB_ERR_SPI_CMD_INVALID);
    if (needPatch) {
        Serial.println("[RADIO] WARN 2.4G PA 被拒(-706), 补设被跳过的 FLRC 参数");
    } else if (st != RADIOLIB_ERR_NONE) {
        Serial.print("[RADIO] beginFLRC FAIL - err="); Serial.println(st);
        // Give a direction from the error code instead of guessing
        if (st == RADIOLIB_ERR_CHIP_NOT_FOUND) {
            Serial.println("[RADIO]   -2 = 芯片没应答: 查 SPI 引脚(MISO/MOSI 是否接反)、3V3、NSS、复位脚");
        } else if (st == RADIOLIB_ERR_SPI_CMD_FAILED) {
            Serial.println("[RADIO]   -707 = 芯片回了 CMD_FAIL: 多为 SPI 总线错位/时钟过快, 或 TCXO 未起振");
        } else if (st == RADIOLIB_ERR_SPI_CMD_INVALID) {
            Serial.println("[RADIO]   -706 = 命令参数被拒");
        }
        return false;
    }

    if (needPatch) {
        int16_t s2 = radio.setPreambleLength(FLRC_PRE);
        int16_t s3 = radio.setDataShaping(RADIOLIB_SHAPING_0_5);
        uint8_t sync[] = { 0x2D, 0x01, 0x4B, 0x1D };
        int16_t s4 = radio.setSyncWord(sync, 4);
        int16_t s5 = radio.setCRC(2);
        Serial.print("[RADIO] 补设 pre="); Serial.print(s2);
        Serial.print(" shape="); Serial.print(s3);
        Serial.print(" sync=");  Serial.print(s4);
        Serial.print(" crc=");   Serial.println(s5);
    }

    // Fixed packet length must come after setSyncWord() (it recomputes packet params)
    int16_t s1 = radio.fixedPacketLengthMode(sizeof(VideoPacket));
    if (s1 != RADIOLIB_ERR_NONE) {
        Serial.print("[RADIO] fixedPacketLengthMode FAIL - err="); Serial.println(s1);
        return false;
    }

    radio.standby();
    Serial.print("[RADIO] OK  FLRC ");
    Serial.print(FLRC_FREQ, 1); Serial.print("MHz ");
    Serial.print(FLRC_BR);      Serial.print("kbps CR1/2 pre=");
    Serial.print(FLRC_PRE);     Serial.print(" pkt=");
    Serial.println((unsigned int)sizeof(VideoPacket));
    return true;
}

// ==================== Enter RX / enter TX standby ====================
// -707 (SPI_CMD_FAILED) right after power-up is the chip refusing to start the RX chain while
// its TCXO/calibration is still settling. It clears on its own within tens of ms, so retry
// instead of giving up: one lost attempt must never leave the receiver deaf.
bool enterRx() {
    if (!gRadioOk) return false;
    int16_t st = RADIOLIB_ERR_UNKNOWN;
    for (int attempt = 0; attempt < 4; attempt++) {
        radio.standby();
        delay(2 + attempt * 10);        // 2 / 12 / 22 / 32 ms of settling time
        st = radio.startReceive();
        if (st == RADIOLIB_ERR_NONE) {
            gRxArmed = true;
            return true;
        }
    }
    gRxArmed = false;
    // Must throttle: one line at 115200 takes ~30ms and flooding stalls the main loop
    if (millis() - lastErrPrint > 1000) {
        Serial.print("[RF] startReceive FAIL - err="); Serial.println(st);
        if (st == RADIOLIB_ERR_SPI_CMD_FAILED) {
            Serial.println("[RF]   -707 = 芯片拒绝进入接收(TCXO 未稳定/SPI 错位), 会在主循环里继续重试");
        }
        lastErrPrint = millis();
    }
    return false;
}

// Put the radio in standby before a startTransmit(): calling it while still in RX is
// rejected by the chip, and the packet is silently lost.
void enterTxStandby() {
    radio.standby();
    gRxArmed = false;
    delay(2);
}

// ==================== Send one packet ====================
bool sendPkt(const VideoPacket& p) {
    if (!gRadioOk) return false;
    uint32_t tPkt = micros();
    int16_t st = radio.startTransmit((const uint8_t*)&p, sizeof(p));
    if (st != RADIOLIB_ERR_NONE) {
        if (millis() - lastErrPrint > 1000) {
            Serial.print("[RF] startTransmit FAIL - err="); Serial.println(st);
            lastErrPrint = millis();
        }
        radio.standby();     // Return to a sane state after an error, otherwise the next packet fails too
        return false;
    }

    unsigned long t0 = millis();
    bool done = false;
    uint16_t spins = 0;
    while (millis() - t0 < PKT_TX_TIMEOUT) {
        // DIO7 drops IRQs on this board, so poll the IRQ register instead of radio.transmit()
        if (radio.getIrqFlags() & RADIOLIB_LR2021_IRQ_TX_DONE) { done = true; break; }
        txPollN++;
        // delay(0) is a FreeRTOS yield, and a yield can cost a whole 1ms tick when the WiFi
        // task is runnable - which is several ms of dead time per packet. Spin for a few
        // hundred us and only hand the CPU over occasionally so nothing starves.
        if ((++spins & 63) == 0) delay(0);
        else                     delayMicroseconds(20);
    }
    radio.finishTransmit();
    txBusyUs += (micros() - tPkt);
    return done;
}

// ==================== Receive one packet (non-blocking) ====================
// true = one packet decoded into *p; false = nothing available right now.
// CRC failures are mostly air noise hitting the sync word (normal at 1300kbps), counted
// as rxNoise.
bool rxPoll(VideoPacket* p) {
    if (!gRadioOk) return false;
    if (!(radio.getIrqFlags() & RADIOLIB_LR2021_IRQ_RX_DONE)) return false;

    size_t len = radio.getPacketLength();
    if (len < 12 || len > sizeof(VideoPacket)) {
        // Bad length: readData() was never called, so the FIFO and IRQ flags are still set
        enterRx();
        return false;
    }

    // Clear before reading. A short packet (noise, or a stray frame from another sketch) only
    // fills len bytes, and whatever was left in the caller's buffer would then be parsed as a
    // real field - that is how a file-end packet once carried a 3.8-billion-byte length.
    memset(p, 0, sizeof(VideoPacket));

    int16_t st = radio.readData((uint8_t*)p, len);
    if (st != RADIOLIB_ERR_NONE) {
        if (st == RADIOLIB_ERR_CRC_MISMATCH) rxNoise++;
        else                                 rxOtherErr++;
        return false;
    }
    // No re-arm needed after a good packet: readData() only drains the FIFO and clears the
    // flags, the chip returns to RX by itself. startReceive() here would be rejected (-706).
    rxPackets++;
    gRxLastLen = (uint16_t)len;
    return true;
}

// ==================== Camera ====================
void initCamera() {
#if (USE_CAMERA && CAM_LIB_OK)
    camera_config_t cfg;
    memset(&cfg, 0, sizeof(cfg));
    cfg.ledc_channel = LEDC_CHANNEL_0;
    cfg.ledc_timer   = LEDC_TIMER_0;
    cfg.pin_pwdn     = CAM_PIN_PWDN;
    cfg.pin_reset    = CAM_PIN_RESET;
    cfg.pin_xclk     = CAM_PIN_XCLK;
    cfg.pin_sccb_sda = CAM_PIN_SIOD;
    cfg.pin_sccb_scl = CAM_PIN_SIOC;
    cfg.pin_d0       = CAM_PIN_D0;
    cfg.pin_d1       = CAM_PIN_D1;
    cfg.pin_d2       = CAM_PIN_D2;
    cfg.pin_d3       = CAM_PIN_D3;
    cfg.pin_d4       = CAM_PIN_D4;
    cfg.pin_d5       = CAM_PIN_D5;
    cfg.pin_d6       = CAM_PIN_D6;
    cfg.pin_d7       = CAM_PIN_D7;
    cfg.pin_vsync    = CAM_PIN_VSYNC;
    cfg.pin_href     = CAM_PIN_HREF;
    cfg.pin_pclk     = CAM_PIN_PCLK;
    cfg.xclk_freq_hz = 20000000;
    cfg.frame_size   = CAM_FRAMESIZE;
    cfg.pixel_format = PIXFORMAT_JPEG;
    cfg.grab_mode    = CAMERA_GRAB_LATEST;   // Video wants the newest frame, never a queue of stale ones
    cfg.fb_location  = psramFound() ? CAMERA_FB_IN_PSRAM : CAMERA_FB_IN_DRAM;
    cfg.jpeg_quality = CAM_QUALITY;
    cfg.fb_count     = 2;

    esp_err_t err = esp_camera_init(&cfg);
    if (err != ESP_OK) {
        Serial.print("[CAM] 初始化失败 0x"); Serial.println(err, HEX);
        gCamOk = false;
        return;
    }
    sensor_t* s = esp_camera_sensor_get();
    if (s) {
        s->set_vflip(s, 1);      // Same as W11: vertical flip, no mirror
        s->set_hmirror(s, 0);
    }
    gCamOk = true;
    Serial.println("[CAM] OK  DVP 摄像头就绪");
#else
    gCamOk = false;
#if !CAM_LIB_OK
    Serial.println("[CAM] 未安装 esp32-camera 库 -> 用合成动画");
#else
    Serial.println("[CAM] USE_CAMERA=0 -> 用合成动画");
#endif
#endif
}

// ==================== Synthetic animation (RGB332, 1 byte per pixel) ====================
// 3x5 digit font used to stamp the frame number on the picture - dropped frames become
// visible at a glance, far more direct than staring at serial counters.
static const uint8_t FONT3x5[10][5] = {
    {0b111, 0b101, 0b101, 0b101, 0b111},   // 0
    {0b010, 0b110, 0b010, 0b010, 0b111},   // 1
    {0b111, 0b001, 0b111, 0b100, 0b111},   // 2
    {0b111, 0b001, 0b111, 0b001, 0b111},   // 3
    {0b101, 0b101, 0b111, 0b001, 0b001},   // 4
    {0b111, 0b100, 0b111, 0b001, 0b111},   // 5
    {0b111, 0b100, 0b111, 0b101, 0b111},   // 6
    {0b111, 0b001, 0b001, 0b001, 0b001},   // 7
    {0b111, 0b101, 0b111, 0b101, 0b111},   // 8
    {0b111, 0b101, 0b111, 0b001, 0b111},   // 9
};

static void fillRect(uint8_t* f, int W, int H, int x0, int y0, int w, int h, uint8_t col) {
    for (int y = y0; y < y0 + h; y++) {
        if (y < 0 || y >= H) continue;
        for (int x = x0; x < x0 + w; x++) {
            if (x < 0 || x >= W) continue;
            f[y * W + x] = col;
        }
    }
}

// Draw one digit (scaled up)
static void drawDigit(uint8_t* f, int W, int H, int x0, int y0, int d, int scale, uint8_t col) {
    if (d < 0 || d > 9) return;
    for (int ry = 0; ry < 5; ry++) {
        uint8_t row = FONT3x5[d][ry];
        for (int rx = 0; rx < 3; rx++) {
            if (!(row & (4 >> rx))) continue;
            for (int sy = 0; sy < scale; sy++) {
                for (int sx = 0; sx < scale; sx++) {
                    int px = x0 + rx * scale + sx;
                    int py = y0 + ry * scale + sy;
                    if (px >= 0 && px < W && py >= 0 && py < H) f[py * W + px] = col;
                }
            }
        }
    }
}

static void drawNumber(uint8_t* f, int W, int H, int x0, int y0,
                       uint32_t v, int digits, int scale, uint8_t col) {
    for (int i = digits - 1; i >= 0; i--) {
        drawDigit(f, W, H, x0 + i * (4 * scale), y0, (int)(v % 10), scale, col);
        v /= 10;
    }
}

// Build one synthetic frame. frameNo drives the animation, pattern picks the style.
void buildFrame(uint8_t* f, int W, int H, uint8_t frameNo, uint8_t pattern) {
    static const uint8_t BARS[8][3] = {   // RGB
        {255, 255, 255}, {255, 255, 0}, {0, 255, 255}, {0, 255, 0},
        {255, 0, 255},   {255, 0, 0},   {0, 0, 255},   {0, 0, 0}
    };

    if (pattern == 0) {
        // ---- 0: colour bars + moving line + white border ----
        const int markX = (int)(((uint16_t)frameNo * 3u) % (uint16_t)W);
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                uint8_t v;
                if (x < 1 || x >= W - 1 || y < 1 || y >= H - 1) {
                    v = 0xFF;
                } else {
                    const uint8_t* c = BARS[(x * 8) / W];
                    uint16_t k = (uint16_t)(140 + (x * 115) / (W - 1));   // dark on the left, bright on the right
                    uint8_t r = (uint8_t)((c[0] * k) >> 8);
                    uint8_t g = (uint8_t)((c[1] * k) >> 8);
                    uint8_t b = (uint8_t)((c[2] * k) >> 8);
                    if (x >= markX && x < markX + 2) { r = g = b = 255; }
                    v = px332(r, g, b);
                }
                f[y * W + x] = v;
            }
        }
    } else if (pattern == 1) {
        // ---- 1: bouncing square (best for judging motion continuity) ----
        const int boxW = W / 4, boxH = H / 4;
        int spanX = W - boxW, spanY = H - boxH;
        if (spanX < 1) spanX = 1;
        if (spanY < 1) spanY = 1;

        int bx = (int)(((uint16_t)frameNo * 3u) % (uint16_t)(spanX * 2));
        if (bx > spanX) bx = spanX * 2 - bx;
        int by = (int)(((uint16_t)frameNo * 2u) % (uint16_t)(spanY * 2));
        if (by > spanY) by = spanY * 2 - by;

        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                // background: diagonal gradient from top-left to bottom-right
                uint8_t t = (uint8_t)(((x * 255) / (W > 1 ? W - 1 : 1) +
                                       (y * 255) / (H > 1 ? H - 1 : 1)) / 2);
                uint8_t v = px332((uint8_t)(t >> 1), (uint8_t)(t >> 2), t);
                if (x >= bx && x < bx + boxW && y >= by && y < by + boxH) {
                    // diagonal stripes inside the square make tearing easy to spot
                    v = (((x - bx) + (y - by)) & 8) ? 0xFF : 0x1C;
                }
                f[y * W + x] = v;
            }
        }
    } else {
        // ---- 2: rainbow sweep (the whole screen moves, good for bandwidth tests) ----
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                uint8_t t = (uint8_t)((x * 255) / (W > 1 ? W - 1 : 1) +
                                      (uint16_t)frameNo * 6u + (y >> 1));
                f[y * W + x] = px332(tri8(t), tri8((uint8_t)(t + 85)), tri8((uint8_t)(t + 170)));
            }
        }
    }

    // ---- overlay: frame number (white on black, top-left) ----
    int scale = (W >= 96 && H >= 48) ? 2 : 1;
    int dw = 4 * (4 * scale);          // width of 4 digits
    int dh = 5 * scale + 2 * scale;
    fillRect(f, W, H, 0, 0, dw, dh, 0x00);
    drawNumber(f, W, H, scale, scale, frameNo, 4, scale, 0xFF);
}

// ==================== Capture one frame ====================
// Returns the frame byte count, 0 on failure.
size_t captureFrame(uint8_t* fmtOut, uint16_t* wOut, uint16_t* hOut) {
#if (USE_CAMERA && CAM_LIB_OK)
    if (gCamOk) {
        camera_fb_t* fb = esp_camera_fb_get();
        if (fb) {
            size_t n = fb->len;
            if (n > VIDEO_BUF_CAP) n = 0;    // Over the buffer size the whole frame is dropped, never truncated (a cut JPEG cannot decode)
            if (n) memcpy(txBuf, fb->buf, n);
            *wOut = (uint16_t)fb->width;
            *hOut = (uint16_t)fb->height;
            esp_camera_fb_return(fb);
            if (n) { *fmtOut = FMT_JPEG; return n; }
            return 0;
        }
        return 0;
    }
#endif

    *fmtOut = FMT_RGB332;
    *wOut = gVidW;
    *hOut = gVidH;
    buildFrame(txBuf, gVidW, gVidH, gFrameId, gPattern);
    return (size_t)gVidW * (size_t)gVidH;
}

// ==================== Board A: send one frame (no retransmit, a lost chunk kills it) ====================
bool sendOneFrame() {
    if (!txBuf) { Serial.println("[TX] 缓冲未分配"); return false; }

    uint8_t  fmt = FMT_RGB332;
    uint16_t w = 0, h = 0;
    size_t   len = 0;

    if (gSrcMode == 1) {
        // ---- Page push mode: send each new frame once, repeat nothing (no stale picture) ----
        if (!gUpReady || !upBuf) return false;
        gUpReady = false;
        len = upLen; fmt = upFmt; w = upW; h = upH;
        if (len == 0 || len > VIDEO_BUF_CAP) return false;
        memcpy(txBuf, upBuf, len);   // Copy first, then send: new frames keep landing in upBuf and cannot tear this one
    } else {
        len = captureFrame(&fmt, &w, &h);
        if (len == 0) { Serial.println("[TX] 采集失败"); return false; }
    }

    uint16_t chunks = (uint16_t)((len + VIDEO_CHUNK - 1) / VIDEO_CHUNK);
    if (chunks == 0 || chunks > VIDEO_MAX_CHUNKS) {
        Serial.print("[TX] 一帧过大, 块数="); Serial.print(chunks);
        Serial.print(" 上限 "); Serial.print(VIDEO_MAX_CHUNKS);
        Serial.println(" (调小 w/h 或降分辨率)");
        return false;
    }

    gFrameId++;                      // uint8, wraps after 256 frames; the receiver compares modulo differences
    txLastLen = (uint16_t)len;
    txLastFmt = fmt;
    txW = w; txH = h;

    VideoPacket p;
    for (uint16_t i = 0; i < chunks; i++) {
        size_t off = (size_t)i * VIDEO_CHUNK;
        size_t n   = len - off;
        if (n > VIDEO_CHUNK) n = VIDEO_CHUNK;

        memset(&p, 0, sizeof(p));
        p.type        = PKT_VIDEO;
        p.frameId     = gFrameId;
        p.totalChunks = (uint8_t)chunks;
        p.chunkIdx    = (uint8_t)i;
        p.format      = fmt;
        p.flags       = 0;
        p.w           = w;
        p.h           = h;
        p.frameLen    = (uint16_t)len;
        memcpy(p.data, txBuf + off, n);

        sendPkt(p);
        txPkts++;
        if (gGapMs) delay(gGapMs);

        // Serve the page while sending. Every 4 chunks instead of 8: the upload arrives as a
        // series of 1436-byte multipart chunks and each handleClient() consumes only one, so
        // calling it half as often as needed was throttling the push.
        if (gWifiOn && (i & 3) == 3) webServer.handleClient();
    }

    // ---- Close the frame and resend whatever was lost ----
    // Board B answers with a bitmap; only the missing chunks go out again. This is the whole
    // difference between "JPEG needs 100%" being fatal and being fine.
    VideoPacket e;
    memset(&e, 0, sizeof(e));
    e.type        = PKT_CTRL;
    e.frameId     = gFrameId;
    e.totalChunks = (uint8_t)chunks;
    e.format      = fmt;
    e.w           = w;
    e.h           = h;
    e.frameLen    = (uint16_t)len;

    for (uint8_t round = 0; round < ACK_ROUNDS; round++) {
        enterTxStandby();     // round 1 returns from RX, where startTransmit() is rejected
        sendPkt(e);
        if (!enterRx()) break;

        VideoPacket a;
        bool got = false;
        unsigned long t0 = millis();
        unsigned long tHc = t0;
        while (millis() - t0 < ACK_WAIT_MS) {
            if (rxPoll(&a)) {
                if (a.type == PKT_ACK && a.frameId == gFrameId) { got = true; break; }
            } else {
                // Keep draining the phone's upload while waiting. The page pushes one frame at a
                // time (inflight), so every millisecond this window spends not serving HTTP is a
                // millisecond the whole stream stands still - that dead time was what capped it
                // at ~1.3fps. The ACK waits in the one-packet RX FIFO, so this cannot lose it.
                if (gWifiOn && (millis() - tHc) >= 10) {
                    webServer.handleClient();
                    tHc = millis();
                }
                delay(0);
            }
        }
        // No bitmap at all: send the frame as it is. Stalling the stream to chase one ack
        // would cost more than the frame is worth.
        if (!got) break;

        uint16_t miss = 0;
        for (uint16_t i = 0; i < chunks; i++)
            if (a.data[i >> 3] & (uint8_t)(1 << (i & 7))) miss++;

        // Self-tuning packet gap. The bitmap is a free measurement of how much turnaround
        // board B actually needs: zero missing chunks means we are waiting longer than
        // necessary, real loss means we are not waiting long enough. The gap only ever moves
        // inside [GAP_MIN, gGapMax] - one step at a time, so it settles instead of ringing.
        if (miss == 0) {
            if (++gapClean >= 4 && gGapMs > GAP_MIN) {
                gGapMs--;
                gapClean = 0;
                Serial.print("[GAP] 无丢包 -> 包间隔降到 "); Serial.print((int)gGapMs); Serial.println("ms");
            }
        } else {
            gapClean = 0;
            if (miss * 8 >= chunks && gGapMs < gGapMax) {
                gGapMs++;
                Serial.print("[GAP] 丢 "); Serial.print((int)miss); Serial.print(" 块 -> 包间隔升到 ");
                Serial.print((int)gGapMs); Serial.println("ms");
            }
        }

        if (miss == 0) break;
        if (round + 1 >= ACK_ROUNDS) break;

        enterTxStandby();
        for (uint16_t i = 0; i < chunks; i++) {
            if (!(a.data[i >> 3] & (uint8_t)(1 << (i & 7)))) continue;

            size_t off = (size_t)i * VIDEO_CHUNK;
            size_t n   = len - off;
            if (n > VIDEO_CHUNK) n = VIDEO_CHUNK;

            memset(&p, 0, sizeof(p));
            p.type        = PKT_VIDEO;
            p.frameId     = gFrameId;
            p.totalChunks = (uint8_t)chunks;
            p.chunkIdx    = (uint8_t)i;
            p.format      = fmt;
            p.flags       = 0;
            p.w           = w;
            p.h           = h;
            p.frameLen    = (uint16_t)len;
            memcpy(p.data, txBuf + off, n);

            sendPkt(p);
            txPkts++;
            if (gGapMs) delay(gGapMs);
        }
    }
    enterTxStandby();     // leave the radio ready for the next frame's startTransmit()

    txFrames++;
    txBytes += len;
    return true;
}

// ==================== Board A: open a file transfer ====================
// Board B needs to know the size before the first byte: it has to open the file, check that
// the 1.5MB partition has room and answer yes/no. Everything else is page-by-page.
static bool fileSendBegin(uint32_t total, uint32_t crc, uint16_t pages) {
    if (total == 0 || total > FILE_MAX_BYTES) {
        fileState = 3;
        snprintf(fileErr, sizeof(fileErr), "文件 %uKB 超过上限 %uKB",
                 (unsigned)(total / 1024), (unsigned)(FILE_MAX_BYTES / 1024));
        return false;
    }
    if (pages == 0 || pages > 255) {
        fileState = 3;
        snprintf(fileErr, sizeof(fileErr), "页数 %u 不合法", (unsigned)pages);
        return false;
    }

    fileTotal    = total;
    fileCrc      = crc;
    filePages    = pages;
    filePageDone = 0;
    fileState    = 1;
    fileErr[0]   = 0;
    fileTid++;

    VideoPacket d;
    memset(&d, 0, sizeof(d));
    d.type = PKT_FBEGIN;
    d.w    = pages;
    d.h    = fileTid;
    memcpy(d.data + 0, &total, 4);
    memcpy(d.data + 4, &crc, 4);

    for (int round = 0; round < 4; round++) {
        enterTxStandby();
        sendPkt(d);
        if (!enterRx()) break;
        VideoPacket a;
        unsigned long t0 = millis();
        while (millis() - t0 < 500) {
            if (rxPoll(&a)) {
                if (a.type == PKT_FACK) {
                    if (a.flags & 1) {
                        Serial.print("[FILE] 开始发送 ");
                        Serial.print((int)total); Serial.print(" 字节  ");
                        Serial.print((int)pages); Serial.println(" 页");
                        return true;
                    }
                    fileState = 3;
                    snprintf(fileErr, sizeof(fileErr), "B 板拒绝接收");
                    return false;
                }
            } else {
                // Deliberately NOT serving HTTP here. This runs inside the /fsend handler, and
                // WebServer is not reentrant: calling handleClient() from within a handler
                // clobbers _currentClient and can re-dispatch the very request we are answering.
                // That is what made the transfer start twice and then corrupt itself.
                delay(0);
            }
        }
    }
    fileState = 3;
    snprintf(fileErr, sizeof(fileErr), "B 板无响应");
    return false;
}

// ==================== Board A: send one file page ====================
// Same chunking and the same bitmap-ACK retransmit as a video frame, with two differences:
//   * the page index travels in w (16 bit), because 4.5MB is 384 pages and frameId is only 8 bit;
//   * a hole is fatal here - one missing chunk corrupts the file - so it retries much harder
//     than the live stream does, and gives up loudly instead of moving on.
// Returns true only when board B reported an empty bitmap for this page.
static bool fileSendPage(uint16_t seq, const uint8_t* buf, uint16_t len) {
    uint16_t chunks = (uint16_t)((len + VIDEO_CHUNK - 1) / VIDEO_CHUNK);
    if (chunks == 0 || chunks > VIDEO_MAX_CHUNKS) return false;

    VideoPacket p;
    uint8_t pid = (uint8_t)seq;

    enterTxStandby();       // the radio may still be in RX from the previous page's ACK
    for (uint16_t i = 0; i < chunks; i++) {
        size_t off = (size_t)i * VIDEO_CHUNK;
        size_t n   = len - off;
        if (n > VIDEO_CHUNK) n = VIDEO_CHUNK;

        memset(&p, 0, sizeof(p));
        p.type        = PKT_FILE;
        p.frameId     = pid;
        p.totalChunks = (uint8_t)chunks;
        p.chunkIdx    = (uint8_t)i;
        p.format      = FMT_FILE;
        p.w           = seq;
        p.frameLen    = len;
        memcpy(p.data, buf + off, n);

        sendPkt(p);
        txPkts++;
        if (gGapMs) delay(gGapMs);
        if (gWifiOn && (i & 3) == 3) webServer.handleClient();
    }

    VideoPacket e;
    memset(&e, 0, sizeof(e));
    e.type        = PKT_FCTRL;
    e.frameId     = pid;
    e.totalChunks = (uint8_t)chunks;
    e.format      = FMT_FILE;
    e.w           = seq;
    e.frameLen    = len;
    // CRC32 of exactly the bytes that were just transmitted. Board B compares it against what it
    // assembled: a full bitmap only proves that 64 packets arrived, not that their contents were
    // intact, and a single flipped byte used to surface only at the very end as
    // "校验不符" over the whole 100KB file, with no way to tell which page was bad.
    uint32_t pageCrc = crc32Buf(buf, len);
    memcpy(e.data + 8, &pageCrc, 4);

    bool clean = false;
    for (uint8_t round = 0; round < FILE_ACK_ROUNDS; round++) {
        enterTxStandby();
        sendPkt(e);
        if (!enterRx()) break;

        VideoPacket a;
        bool got = false;
        unsigned long t0 = millis(), tHc = t0;
        while (millis() - t0 < FILE_ACK_WAIT_MS) {
            if (rxPoll(&a)) {
                // Only a full-size packet is a real answer. A short packet keeps data[] zeroed,
                // which decodes as "nothing missing" - that is how board A used to skip a page
                // that board B had never received in full, leaving holes in the stored file.
                if (a.type == PKT_ACK && a.frameId == pid && gRxLastLen == sizeof(VideoPacket)) {
                    got = true;
                    break;
                }
            } else {
                if (gWifiOn && (millis() - tHc) >= 10) { webServer.handleClient(); tHc = millis(); }
                delay(0);
            }
        }
        if (!got) continue;                       // no bitmap at all: just ask again

        uint16_t miss = 0;
        for (uint16_t i = 0; i < chunks; i++)
            if (a.data[i >> 3] & (uint8_t)(1 << (i & 7))) miss++;
        if (miss == 0) {
            // Board B sets flags bit0 only after the page is really on flash. Without that proof
            // an all-zero bitmap is indistinguishable from a stray packet, so ask again.
            if (a.flags & 1) { clean = true; break; }
            continue;
        }

        enterTxStandby();
        for (uint16_t i = 0; i < chunks; i++) {
            if (!(a.data[i >> 3] & (uint8_t)(1 << (i & 7)))) continue;
            size_t off = (size_t)i * VIDEO_CHUNK;
            size_t n   = len - off;
            if (n > VIDEO_CHUNK) n = VIDEO_CHUNK;

            memset(&p, 0, sizeof(p));
            p.type        = PKT_FILE;
            p.frameId     = pid;
            p.totalChunks = (uint8_t)chunks;
            p.chunkIdx    = (uint8_t)i;
            p.format      = FMT_FILE;
            p.w           = seq;
            p.frameLen    = len;
            memcpy(p.data, buf + off, n);
            sendPkt(p);
            txPkts++;
            if (gGapMs) delay(gGapMs);
        }
    }
    enterTxStandby();
    return clean;
}

// Tell board B the file is over; B re-reads what it stored, checks the CRC and answers.
static bool fileSendDone() {
    VideoPacket d;
    memset(&d, 0, sizeof(d));
    d.type     = PKT_FDONE;
    d.frameLen = (uint16_t)(fileTotal & 0xFFFF);
    memcpy(d.data + 0, &fileTotal, 4);
    memcpy(d.data + 4, &fileCrc, 4);

    for (int round = 0; round < 5; round++) {
        enterTxStandby();
        sendPkt(d);
        if (!enterRx()) return false;
        VideoPacket a;
        unsigned long t0 = millis();
        while (millis() - t0 < 400) {
            if (rxPoll(&a)) {
                if (a.type == PKT_FACK) return (a.flags & 1) != 0;
            } else {
                delay(0);       // no handleClient(): we are inside the /fdone handler
            }
        }
    }
    return false;
}

static void fileSendReset() {
    fileActive     = false;
    gFilePageReady = false;
    filePages      = 0;
    fileTotal      = 0;
    fileCrc        = 0;
    filePageDone   = 0;
    filePageSeq    = 0;
    fileState      = 0;
    fileErr[0]     = 0;
}

// ==================== Board A: continuous streaming ====================
void streamVideo() {
    if (!txBuf) { Serial.println("[TX] 缓冲未分配"); gStreaming = false; return; }

    gStreaming = true;
    ledRed();

    Serial.print("[TX] 开始推流  ");
    if (gSrcMode == 1) Serial.print("网页推帧");
    else { Serial.print(gVidW); Serial.print("x"); Serial.print(gVidH); }
    Serial.print("  目标 "); Serial.print((int)gTargetFps);
    Serial.print("fps  包间隔 "); Serial.print((int)gGapMs);
    Serial.print("ms (上限 "); Serial.print((int)gGapMax); Serial.println("ms, 自动收敛)");
    Serial.println("[TX] 输入 idle 或按 BOOT 停止");

    radio.standby();
    delay(2);

    uint32_t nextUs = micros();
    txStatMs = millis();
    txPrevFrames = txFrames;
    txIdleLogged = false;

    while (gStreaming && gRole == ROLE_TX) {
        pollSerial();                                   // allow idle / parameter changes in the middle
        if (gWifiOn) webServer.handleClient();

        if (gSrcMode == 1) {
            // Page push mode: one frame in, one frame out. The phone sets the pace, so no fixed fps
            // here - otherwise the same picture would be sent again and waste radio bandwidth.
            if (gUpReady) sendOneFrame();
            else delay(2);
        } else {
            if (!sendOneFrame()) {
                // A capture failure (camera gone / bad size) must not spin the log
                delay(50);
            }
            // Frame rate cap: align on absolute time so the send duration is not added to the period
            if (gTargetFps) {
                nextUs += 1000000UL / gTargetFps;
                int32_t waitUs = (int32_t)(nextUs - micros());
                if (waitUs > 0) {
                    delayMicroseconds((uint32_t)waitUs);
                } else if (waitUs < -1000000) {
                    nextUs = micros();                  // More than 1 second behind: resync instead of catching up
                }
            }
        }

        // Report the real frame rate / bandwidth every 2s - this single line tells link quality
        uint32_t now = millis();
        if (now - txStatMs >= 2000) {
            uint32_t dFrames = txFrames - txPrevFrames;
            uint32_t dPkts   = txPkts - txPrevPkts;
            if (dFrames > 0) {
                uint32_t dt = now - txStatMs;
                float fps  = (float)dFrames * 1000.0f / (float)dt;
                float kbps = (float)dFrames * (float)txLastLen * 1000.0f / (float)dt / 1024.0f;
                Serial.print("[STAT] TX  ");
                Serial.print(fps, 1); Serial.print("fps  ");
                Serial.print(kbps, 1); Serial.print("KB/s  ");
                Serial.print(txLastLen); Serial.print("B/帧  ");
                Serial.print((int)((txLastLen + VIDEO_CHUNK - 1) / VIDEO_CHUNK)); Serial.print("块  ");
                Serial.print((int)txPkts); Serial.print(" 包  ");
                // µs spent inside sendPkt per packet vs. its ~1300us of air time. If this is much
                // larger, the radio is waiting on SPI/polling, not on the air.
                if (dPkts) {
                    Serial.print((unsigned long)((txBusyUs - txPrevBusyUs) / dPkts));
                    Serial.print("us/包  ");
                    Serial.print((unsigned long)((txPollN - txPrevPollN) / dPkts));
                    Serial.print("轮  gap ");
                    Serial.print((int)gGapMs);
                    Serial.print("/");
                    Serial.print((int)gGapMax);
                    Serial.print("ms");
                }
                Serial.println();
                txIdleLogged = false;
            } else if (gSrcMode == 1 && !txIdleLogged) {
                // Page push mode with no frames arriving: report once, not every 2s
                txIdleLogged = true;
                Serial.println("[TX] 还没收到网页画面 —— 手机端点\"开始\"了吗? (页面需在前台)");
            }
            txPrevFrames = txFrames;
            txPrevPkts = txPkts;
            txPrevBusyUs = txBusyUs;
            txPrevPollN = txPollN;
            txStatMs = now;
        }
    }

    gStreaming = false;
    radio.standby();
    delay(2);
    ledOff();
    Serial.print("[TX] 推流结束, 共 ");
    Serial.print((int)txFrames);
    Serial.println(" 帧");
}

// ==================== Board B: reassemble (partial frames are published) ====================
// Publish the rxBuf being assembled. A complete frame is NOT required: missing chunks keep
// the previous frame's pixels, so the picture shows one or two stale bands instead of being
// discarded and leaving the page waiting 3 seconds for an image.
static void publishLive() {
    if (rxCurLen == 0 || rxCurLen > VIDEO_BUF_CAP) return;
    memcpy(liveBuf, rxBuf, rxCurLen);
    liveLen = rxCurLen;
    liveW   = rxCurW;
    liveH   = rxCurH;
    liveFmt = rxCurFmt;
    liveSeq++;
    rxShown++;
    ledGreen();
}

// ==================== Board B: file receive ====================
// Nothing is decoded here. The ESP32-S3 has no H.264 decoder, so board B is a disk: it stores
// the bytes exactly as they arrive and the phone's browser does the playing.
static bool ensureFs() {
    static bool tried = false, ok = false;
    if (tried) return ok;
    tried = true;
    ok = LittleFS.begin(true);          // format on failure: a corrupt partition is worthless
    if (!ok) {
        Serial.println("[FS] LittleFS 挂载失败 —— 文件传输不可用");
        return false;
    }
    Serial.print("[FS] LittleFS 可用 ");
    Serial.print((int)((LittleFS.totalBytes() - LittleFS.usedBytes()) / 1024));
    Serial.println("KB");
    // Leftover from a transfer interrupted before the marker was written. It can never play, so
    // reclaim the space instead of offering the page a black video.
    if (!fileRxActive && LittleFS.exists(FILE_PATH) && !LittleFS.exists(FILE_OK_PATH)) {
        LittleFS.remove(FILE_PATH);
        Serial.println("[FS] 已清理上次未传完的文件");
    }
    return true;
}

static void fileRxResetAll() {
    if (fileOut) { fileOut.close(); }
    fileRxActive  = false;
    fileRxPage    = 0;
    fileRxPageLen = 0;
    fileRxChunks  = 0;
    fileRxGot     = 0;
    fileRxWritten = 0;
    fileRxPageStored = false;
    fileRxPageTries  = 0;
    memset(fileRxHave, 0, sizeof(fileRxHave));
}

// Write the buffered page. Called only when the page is complete, because programming 12KB of
// flash stalls the cache long enough to swallow the first few packets of the next page.
// fileRxPageLen is cleared afterwards on purpose: the page is also flushed again when the next
// page's first chunk arrives, and without this the same 12KB went to flash twice - two stalls
// per page instead of one, which is exactly the window where whole pages were being lost.
static bool fileRxFlush() {
    if (!fileOut || !fileRxPageLen) return true;
    uint32_t base = (uint32_t)fileRxPage * FILE_PAGE_BYTES;
    uint16_t len  = fileRxPageLen;
    if (!fileOut.seek(base)) return false;      // File::seek() returns bool, not the new position
    size_t w = fileOut.write(fileRxBuf, len);
    if (w != len) return false;
    fileRxWritten = base + len;
    fileRxPageLen = 0;
    // Remember that this page is on flash. Without it a repeated FCTRL (the ACK was lost) found
    // every bitmap bit still set and re-armed fileRxPageLen, so the same 12KB went to flash a
    // second time for nothing - and a page whose ACK was lost could never be re-received.
    fileRxPageStored = true;
    return true;
}

static void fileRxBegin(const VideoPacket& p) {
    uint32_t total = 0, crc = 0;
    memcpy(&total, p.data + 0, 4);
    memcpy(&crc,   p.data + 4, 4);
    uint16_t tid = p.h;

    // Same transfer, announced again because board A missed the first answer: keep the pages
    // already on flash and just answer. Wiping here used to throw away real progress.
    if (fileRxActive && tid == fileRxTid && total == fileRxTotal && crc == fileRxCrc) {
        VideoPacket a;
        memset(&a, 0, sizeof(a));
        a.type  = PKT_FACK;
        a.flags = 1;
        enterTxStandby();
        sendPkt(a);
        enterRx();
        return;
    }

    bool ok = false;
    do {
        if (total == 0 || total > FILE_MAX_BYTES) {
            snprintf(fileErr, sizeof(fileErr), "文件 %u 字节超出上限 %u", (unsigned)total, (unsigned)FILE_MAX_BYTES);
            break;
        }
        if (!ensureFs()) { snprintf(fileErr, sizeof(fileErr), "存储未就绪"); break; }

        uint32_t freeB = LittleFS.totalBytes() - LittleFS.usedBytes();
        if (freeB < total + 16384) {
            snprintf(fileErr, sizeof(fileErr), "空间不足 %uKB/%uKB", (unsigned)(freeB / 1024), (unsigned)(total / 1024));
            break;
        }
        fileRxResetAll();
        if (LittleFS.exists(FILE_OK_PATH)) LittleFS.remove(FILE_OK_PATH);
        if (LittleFS.exists(FILE_PATH)) LittleFS.remove(FILE_PATH);
        fileOut = LittleFS.open(FILE_PATH, "w");
        if (!fileOut) { snprintf(fileErr, sizeof(fileErr), "无法创建文件"); break; }

        fileRxTotal  = total;
        fileRxCrc    = crc;
        fileRxTid    = tid;
        fileRxPages  = p.w;
        fileRxPage   = 0;
        fileRxActive = true;
        fileRxState  = 1;
        ok = true;
        Serial.print("[FILE] 开始接收  ");
        Serial.print((int)total); Serial.print(" 字节  ");
        Serial.print((int)p.w);   Serial.println(" 页");
    } while (0);

    if (!ok) {
        fileRxState = 3;
        Serial.print("[FILE] 拒绝接收: "); Serial.println(fileErr);
    }

    VideoPacket a;
    memset(&a, 0, sizeof(a));
    a.type  = PKT_FACK;
    a.flags = ok ? 1 : 0;
    enterTxStandby();
    sendPkt(a);
    enterRx();
}

static void fileRxChunk(const VideoPacket& p) {
    if (!fileRxActive) return;
    // A truncated packet has a valid header but a zeroed tail, so it would be marked received
    // while carrying 190 bytes of nothing. Never accept one as a file chunk.
    if (gRxLastLen != sizeof(VideoPacket)) return;
    if (p.totalChunks == 0 || p.totalChunks > VIDEO_MAX_CHUNKS) return;
    if (p.chunkIdx >= p.totalChunks) return;

    uint16_t page = p.w;
    if (page != fileRxPage) {
        int16_t d = (int16_t)(page - fileRxPage);
        if (d < 0) return;                    // late duplicate of a page already stored
        if (d > 1) {
            // A page was skipped entirely: the transfer is already broken, stop pretending
            fileRxState = 3;
            snprintf(fileErr, sizeof(fileErr), "漏收第 %u 页", (unsigned)(fileRxPage + 1));
            return;
        }
        // Never write a page that still has holes. fileRxBuf keeps whatever the *previous* page
        // left at those offsets, so the file would come out at exactly the right length with
        // wrong bytes inside - which is precisely the "校验不符" at the very end of the transfer,
        // with no way to tell which page was bad. Fail here instead, and name the page.
        if (!fileRxPageStored && (fileRxChunks == 0 || fileRxGot < fileRxChunks)) {
            fileRxState = 3;
            snprintf(fileErr, sizeof(fileErr), "第 %u 页不完整",
                     (unsigned)(fileRxPage + 1));
            Serial.print("[FILE] 页 "); Serial.print((int)fileRxPage + 1);
            Serial.print(" 缺 "); Serial.print((int)fileRxChunks - (int)fileRxGot);
            Serial.println(" 块, 已丢弃");
            return;
        }
        if (!fileRxFlush()) {
            fileRxState = 3;
            snprintf(fileErr, sizeof(fileErr), "写入失败(存储满?)");
            return;
        }
        fileRxPage    = page;
        fileRxChunks  = p.totalChunks;
        fileRxPageLen = p.frameLen;
        fileRxGot     = 0;
        fileRxPageStored = false;
        fileRxPageTries  = 0;
        memset(fileRxHave, 0, sizeof(fileRxHave));
    }

    // The page is already on flash and chunks for it are arriving again: board A is re-sending
    // the whole page (its ACK was lost, or the CRC rejected it). Collect it from scratch - the
    // old bitmap still says "every chunk is here", which would make every one of them a no-op.
    if (fileRxPageStored) {
        fileRxPageStored = false;
        fileRxGot        = 0;
        memset(fileRxHave, 0, sizeof(fileRxHave));
    }

    fileRxChunks  = p.totalChunks;
    fileRxPageLen = p.frameLen;
    if (fileRxPageLen == 0 || fileRxPageLen > FILE_PAGE_BYTES) return;
    if (bmGet(fileRxHave, p.chunkIdx)) return;

    size_t off = (size_t)p.chunkIdx * VIDEO_CHUNK;
    if (off >= fileRxPageLen) return;
    size_t n = fileRxPageLen - off;
    if (n > VIDEO_CHUNK) n = VIDEO_CHUNK;

    bmSet(fileRxHave, p.chunkIdx);
    memcpy(fileRxBuf + off, p.data, n);
    fileRxGot++;
}

// Whole file arrived: re-read it from flash and compare the CRC32 the sender computed. Doing it
// on what was actually stored (not on what was received) also catches a bad flash write.
static void fileRxFinish(const VideoPacket& p) {
    uint32_t total = 0, crc = 0;
    memcpy(&total, p.data + 0, 4);
    memcpy(&crc,   p.data + 4, 4);

    bool ok = false;
    do {
        if (!fileRxActive) { snprintf(fileErr, sizeof(fileErr), "没有正在接收的文件"); break; }
        if (!fileRxFlush()) { snprintf(fileErr, sizeof(fileErr), "末页写入失败"); break; }
        if (fileOut) fileOut.close();

        File f = LittleFS.open(FILE_PATH, "r");
        if (!f) { snprintf(fileErr, sizeof(fileErr), "文件打不开"); break; }
        uint32_t sz = f.size(), c = 0;
        uint8_t tmp[1024];
        while (f.available()) {
            size_t n = f.read(tmp, sizeof(tmp));
            if (!n) break;
            c = esp_rom_crc32_le(c, tmp, n);
        }
        f.close();

        fileRxActive = false;
        // The size to compare against comes from PKT_FBEGIN, not from this packet. A damaged
        // FDONE used to produce nonsense like "长度不符 86016/3832189616" and hid the real
        // question (did the stored bytes match what was announced?).
        uint32_t want = fileRxTotal;      // both announced by PKT_FBEGIN, which is ACKed
        uint32_t wantCrc = fileRxCrc;
        if (total != want || crc != wantCrc) {
            Serial.print("[FILE] 注意: 结束包字段异常 total=");
            Serial.print((unsigned)total); Serial.print(" crc="); Serial.println((unsigned)crc, HEX);
        }
        if (sz != want) {
            snprintf(fileErr, sizeof(fileErr), "长度不符 %u/%u", (unsigned)sz, (unsigned)want);
            break;
        }
        if (c != wantCrc) {
            // Every page passed its own CRC before it was written, so a mismatch here means the
            // bytes changed between RAM and flash, not on the air.
            snprintf(fileErr, sizeof(fileErr), "校验不符 %08X/%08X 疑落盘",
                     (unsigned)c, (unsigned)wantCrc);
            break;
        }
        fileRxState = 2;
        ok = true;
        // Only now is the file worth offering to the page. 1 byte, written once per transfer.
        File mk = LittleFS.open(FILE_OK_PATH, "w");
        if (mk) { mk.write((uint8_t)1); mk.close(); }
        Serial.print("[FILE] 接收完成  ");
        Serial.print((int)sz); Serial.print(" 字节  CRC ");
        Serial.println(crc, HEX);
    } while (0);

    if (!ok) {
        fileRxState = 3;
        // Throw the partial file away: it can never be played, and leaving it there made the
        // page show a black video that looked like a decoder problem.
        if (fileOut) fileOut.close();
        if (LittleFS.exists(FILE_PATH)) LittleFS.remove(FILE_PATH);
        if (LittleFS.exists(FILE_OK_PATH)) LittleFS.remove(FILE_OK_PATH);
        Serial.print("[FILE] 接收失败: "); Serial.println(fileErr);
        Serial.println("[FILE] 已删除不完整的文件");
    }

    VideoPacket a;
    memset(&a, 0, sizeof(a));
    a.type  = PKT_FACK;
    a.flags = ok ? 1 : 0;
    enterTxStandby();
    sendPkt(a);
    enterRx();
}

void handleRxPacket(const VideoPacket& p) {
    // ---- File transfer packets: board B is a disk, not a decoder ----
    if (p.type == PKT_FBEGIN) { fileRxBegin(p); return; }
    if (p.type == PKT_FILE)   { fileRxChunk(p); return; }
    if (p.type == PKT_FDONE)  { fileRxFinish(p); return; }

    if (p.type == PKT_FCTRL) {
        // Report which chunks of this page are still missing. When nothing is missing the page
        // is written to flash *before* the ACK goes out, so the ACK doubles as "safely stored":
        // board A then sends the next page into an idle receiver instead of into the middle of
        // a 12KB flash write, which is where the first chunks of every page were being lost.
        VideoPacket a;
        memset(&a, 0, sizeof(a));
        a.type        = PKT_ACK;
        a.frameId     = p.frameId;
        a.totalChunks = p.totalChunks;
        bool ours = (fileRxActive && p.w == fileRxPage);

        // Repeated FCTRL for a page that is already on flash (our ACK was lost on the way back).
        // Answer "nothing missing" and leave both the buffer and the flash alone.
        if (ours && fileRxPageStored) {
            a.flags = 1;                 // "really stored" - see board A's check
            enterTxStandby();
            sendPkt(a);
            enterRx();
            return;
        }

        uint16_t miss = 0;
        for (uint16_t i = 0; i < p.totalChunks; i++) {
            bool gone = ours ? !bmGet(fileRxHave, i) : true;
            if (gone) { a.data[i >> 3] |= (uint8_t)(1 << (i & 7)); miss++; }
        }

        if (ours && miss == 0) {
            // Every index arrived - but did the right bytes arrive? Compare the whole page
            // against the CRC32 board A computed over the bytes it transmitted. This is the only
            // check that catches a packet which passed the air CRC yet carried wrong payload,
            // and it localises the damage to one page instead of one 100KB file.
            uint32_t wantCrc = 0;
            memcpy(&wantCrc, p.data + 8, 4);
            uint32_t gotCrc = crc32Buf(fileRxBuf, fileRxPageLen);

            if (wantCrc != 0 && gotCrc != wantCrc) {
                fileRxPageTries++;
                Serial.print("[FILE] 页 "); Serial.print((int)fileRxPage + 1);
                Serial.print(" 内容不符 "); Serial.print((unsigned long)gotCrc, HEX);
                Serial.print("/"); Serial.print((unsigned long)wantCrc, HEX);
                Serial.print(" 整页重收 "); Serial.print((int)fileRxPageTries);
                Serial.print("/"); Serial.println(FILE_PAGE_TRIES);

                if (fileRxPageTries > FILE_PAGE_TRIES) {
                    fileRxState = 3;
                    snprintf(fileErr, sizeof(fileErr), "第 %u 页内容不符",
                             (unsigned)(fileRxPage + 1));
                } else {
                    // Throw the bad bytes away and ask for the whole page again: clearing the
                    // bitmap is what makes the resent chunks actually get copied this time.
                    memset(fileRxHave, 0, sizeof(fileRxHave));
                    fileRxGot = 0;
                    memset(a.data, 0xFF, (size_t)((p.totalChunks + 7) / 8));
                }
            } else {
                uint32_t t0 = millis();
                bool wrote = fileRxFlush();
                uint32_t ms = millis() - t0;
                if (!wrote) {
                    fileRxState = 3;
                    snprintf(fileErr, sizeof(fileErr), "写入失败(存储满?)");
                    Serial.println("[FILE] 写盘失败");
                } else {
                    // flags bit0 = "this page is really on flash". Board A refuses to accept an
                    // all-zero bitmap without it, because a short or stray packet also decodes as
                    // an all-zero bitmap and would let A skip a page that was never delivered.
                    a.flags = 1;
                    Serial.print("[FILE] 页 "); Serial.print((int)fileRxPage + 1);
                    Serial.print(" 收齐 "); Serial.print((int)(p.frameLen));
                    Serial.print("B 写盘 "); Serial.print((unsigned long)ms); Serial.println("ms");
                }
            }
        }

        enterTxStandby();
        sendPkt(a);
        enterRx();
        return;
    }

    // ---- Frame ended: report which chunks are missing so board A can resend just those ----
    if (p.type == PKT_CTRL) {
        if (p.frameId != rxCurId) return;      // not the frame currently being assembled
        VideoPacket a;
        memset(&a, 0, sizeof(a));
        a.type        = PKT_ACK;
        a.frameId     = p.frameId;
        a.totalChunks = (uint8_t)rxCurTotal;
        // rxCurTotal == 0 means the frame was already complete and published, so the bitmap
        // stays all zero = "nothing missing, do not resend".
        if (rxCurTotal) {
            for (uint16_t i = 0; i < rxCurTotal; i++)
                if (!bmGet(rxHave, i)) a.data[i >> 3] |= (uint8_t)(1 << (i & 7));
        }
        enterTxStandby();
        sendPkt(a);
        enterRx();                             // straight back to listening
        return;
    }

    if (p.type != PKT_VIDEO) return;
    if (p.totalChunks == 0 || p.totalChunks > VIDEO_MAX_CHUNKS) return;
    if (p.chunkIdx >= p.totalChunks) return;
    if (p.frameLen == 0 || p.frameLen > VIDEO_BUF_CAP) return;

    rxPackets++;

    // frameId is uint8: a signed difference tells new from old (1..127 = newer, -128..-1 = late)
    int8_t d = (int8_t)(p.frameId - rxCurId);

    // The previous frame was already published and reset, and a chunk with the same frameId
    // arrives again (retransmit/duplicate) - drop it, otherwise a more broken copy is published.
    if (rxCurTotal == 0 && d == 0 && rxStarted > 0) return;

    if (rxCurTotal == 0 || d > 0) {
        // End of the previous frame (complete or not):
        //   more than half received -> publish (partial); less -> discard, do not pollute the picture
        if (rxCurTotal != 0) {
            rxMissChunks += (uint16_t)(rxCurTotal - rxGot);
            if (rxCurFmt == FMT_JPEG) {
                // JPEG is a compressed stream: one missing chunk and it cannot decode (garbage or black).
                // So a JPEG frame is dropped whole and the page keeps showing the last complete image.
                rxDropped++;
            } else if ((uint32_t)rxGot * 2 >= (uint32_t)rxCurTotal) {
                publishLive();          // RGB332: publish partial frames, missing chunks keep the previous pixels
            } else {
                rxDropped++;
            }
        }

        rxCurId    = p.frameId;
        rxCurTotal = p.totalChunks;
        rxCurLen   = p.frameLen;
        rxCurW     = p.w;
        rxCurH     = p.h;
        rxCurFmt   = p.format;
        rxGot      = 0;
        bmClearAll(rxHave);
        rxStarted++;

        // Size/format changed: clear the buffers, otherwise the edges keep pixels of the old frame
        if (liveLen != p.frameLen || liveW != p.w || liveH != p.h) {
            memset(rxBuf, 0, p.frameLen);
        }

        if (rxSilent) {
            rxSilent = false;
            Serial.print("[RX] 收到画面  ");
            Serial.print(p.w); Serial.print("x"); Serial.print(p.h);
            Serial.print("  "); Serial.print(p.frameLen);
            Serial.println(" 字节");
            ledBlue();
        }
    } else if (d < 0) {
        return;                          // Late chunk of an old frame, drop it
    }

    if (bmGet(rxHave, p.chunkIdx)) return;   // Duplicate chunk (rare, could be a noise misread)

    bmSet(rxHave, p.chunkIdx);
    size_t off = (size_t)p.chunkIdx * VIDEO_CHUNK;
    size_t n   = rxCurLen - off;
    if (n > VIDEO_CHUNK) n = VIDEO_CHUNK;
    memcpy(rxBuf + off, p.data, n);
    rxGot++;

    // 100% complete: publish at once, no need to wait for the next frame
    if (rxGot >= rxCurTotal) {
        rxFrames++;
        publishLive();
        rxCurTotal = 0;
        rxGot      = 0;
    }
}

// ==================== Board B: periodic stats ====================
// Print one line every 2s as long as packets arrive (even with no complete frame, the lost
// chunk count must be visible). No packet for 2s = stream stopped, reported once.
void rxStatsTick() {
    uint32_t now = millis();
    if (now - rxStatMs < 2000) return;
    uint32_t dt = now - rxStatMs;

    uint32_t dPkts  = rxPackets - rxPrevPkts;
    uint32_t dShown = rxShown   - rxPrevShown;

    // ---------- No packet for 2 seconds: stream stopped, reported once ----------
    if (dPkts == 0) {
        if (!rxSilent) {
            rxSilent = true;
            Serial.println("[RX] 画面中断, 继续 Listening......");
            ledBlue();
        }
        // Drop the half-received frame too. A stream that stops mid-frame (source switch,
        // phone paused) otherwise leaves rxCurTotal set, and the next frame's first chunk is
        // treated as a continuation of the dead one - the picture then stays frozen on the
        // last complete frame even though packets are arriving again.
        rxCurTotal = 0;
        rxGot      = 0;
        rxPrevPkts   = rxPackets;
        rxPrevShown  = rxShown;
        rxPrevFrames = rxFrames;
        rxPrevMiss   = rxMissChunks;
        rxStatMs     = now;
        return;
    }

    float fps   = (float)dShown * 1000.0f / (float)dt;
    float kbps  = (float)dShown * (float)liveLen * 1000.0f / (float)dt / 1024.0f;
    float okPct = rxStarted ? ((float)rxFrames * 100.0f / (float)rxStarted) : 0.0f;
    uint32_t dMiss = rxMissChunks - rxPrevMiss;
    float lossPct = (dPkts + dMiss) ? ((float)dMiss * 100.0f / (float)(dPkts + dMiss)) : 0.0f;

    Serial.print("[STAT] RX  ");
    Serial.print(fps, 1); Serial.print("fps  ");
    Serial.print(kbps, 1); Serial.print("KB/s  ");
    Serial.print((int)liveLen); Serial.print("B/帧  ");
    Serial.print("显示 "); Serial.print((int)rxShown);
    Serial.print("/");     Serial.print((int)rxStarted);
    Serial.print("  全齐 "); Serial.print(okPct, 0); Serial.print("%  ");
    Serial.print("块丢 "); Serial.print(lossPct, 1); Serial.print("%  ");
    Serial.print("噪声 "); Serial.print((int)rxNoise);
    Serial.print("  其他 "); Serial.println((int)rxOtherErr);

    rxPrevPkts   = rxPackets;
    rxPrevShown  = rxShown;
    rxPrevFrames = rxFrames;
    rxPrevMiss   = rxMissChunks;
    rxStatMs     = now;
}

// ==================== Web page (board B: live view) ====================
static const char PAGE_LIVE[] PROGMEM = R"rawliteral(
<!DOCTYPE html><html lang="zh-CN"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
<title>W16 实时画面</title>
<style>
  :root{--bg:#0e1116;--fg:#e8edf5;--dim:#8b95a7;--acc:#38bdf8;--ok:#34d399}
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--fg);
       font:14px/1.5 -apple-system,"Segoe UI",system-ui,"Microsoft YaHei",sans-serif}
  .wrap{max-width:760px;margin:0 auto;padding:16px}
  h1{font-size:17px;margin:0 0 12px;font-weight:600;letter-spacing:.3px}
  h1 span{color:var(--dim);font-weight:400;font-size:12px;margin-left:8px}
  .stage{background:#000;border-radius:12px;overflow:hidden;
         box-shadow:0 6px 24px rgba(0,0,0,.5);position:relative;min-height:180px}
  canvas{display:block;width:100%;height:auto;image-rendering:pixelated}
  .nodata{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
          color:var(--dim);font-size:13px;letter-spacing:1px}
  .bar{margin:12px 0 4px;font-size:13px;color:var(--dim);min-height:20px}
  .bar b{color:var(--acc)}
  .grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:12px}
  .grid div{background:#161b23;border-radius:10px;padding:10px 8px;text-align:center}
  .grid b{display:block;font-size:18px;color:var(--ok);font-variant-numeric:tabular-nums}
  .grid small{display:block;color:var(--dim);font-size:11px;margin-top:2px}
  .tip{color:var(--dim);font-size:12px;margin-top:16px;line-height:1.7}
  .tip code{background:#161b23;padding:1px 5px;border-radius:4px;color:var(--acc)}
  .sec{margin-top:18px;font-size:12px;color:var(--dim);letter-spacing:.5px}
  .pbar{height:8px;background:#161b23;border-radius:6px;margin-top:10px;overflow:hidden}
  .pbar i{display:block;height:100%;width:0;background:#34d399;transition:width .2s}
  .stat{margin-top:8px;font-size:12px;color:var(--dim)}
  .row{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap}
  .row button,.row a{flex:1;min-width:92px;padding:11px 10px;border-radius:10px;border:1px solid #263040;
       background:#161b23;color:var(--fg);font-size:14px;cursor:pointer;text-align:center;
       text-decoration:none;display:block}
  .row a.pri{background:#34d399;border-color:#34d399;color:#00120b;font-weight:600}
  #fvid{display:none;width:100%;margin-top:10px;border-radius:10px;background:#000}
</style></head><body>
<div class="wrap">
  <h1>W16 实时画面 <span id="who">B 板 · 接收端 · v4</span></h1>
  <div class="stage">
    <canvas id="cv" width="96" height="64"></canvas>
    <div class="nodata" id="nodata">等待信号…</div>
  </div>
  <div class="bar" id="bar">尚未收到画面</div>
  <div class="grid">
    <div><b id="fps">0</b><small>帧率 fps</small></div>
    <div><b id="okp">0%</b><small>显示率</small></div>
    <div><b id="sz">0</b><small>字节/帧</small></div>
    <div><b id="kbs">0</b><small>KB/s</small></div>
  </div>

  <div class="sec">收到的视频文件</div>
  <div class="stat" id="fstat">还没有收到文件（A 板页面里编码后点「发送到 B 板」）</div>
  <div class="pbar"><i id="fbar"></i></div>
  <video id="fvid" controls playsinline></video>
  <div class="row" id="frow" style="display:none">
    <a class="pri" id="fdl" download="w16.mp4">下载到本地</a>
    <button onclick="fshare()">存到相册 / 分享</button>
    <button onclick="fdel()">删除</button>
  </div>
  <p class="tip">
    清晰度完全取决于 A 板网页的设置：帧是 <code>JPEG</code>，缺一块就解不出来，会整帧跳过、继续显示上一张。<br>
    画面糊基本就是<b>像素太少</b>——链路每秒只过得去 10~15KB，180x240 的 JPEG 已经要 8KB。
    想更清楚，在 A 板页面把 <b>分辨率</b> 调大、<b>JPEG 质量</b> 调到 0.6~0.7，代价是帧率下降。<br>
    A 板状态栏的 <code>推送 x.xfps</code> 会自动跟住板子的实际发送能力，不用手动配。
  </p>
</div>
<script>
var cv = document.getElementById('cv'), ctx = cv.getContext('2d');
var seq = 0, gotFrame = false;

function drawFrame(ab){
  var dv = new DataView(ab);
  if (dv.getUint8(0) !== 87 || dv.getUint8(1) !== 86) return;
  var fmt = dv.getUint8(3);
  var w = dv.getUint16(4), h = dv.getUint16(6), len = dv.getUint16(8);
  seq = dv.getUint32(10);
  var p = new Uint8Array(ab, 16, len);
  gotFrame = true;
  document.getElementById('nodata').style.display = 'none';
  document.getElementById('sz').textContent = len;
  // RGB332 must be upscaled pixelated (otherwise it blurs), JPEG uses smooth interpolation
  cv.style.imageRendering = (fmt === 1) ? 'auto' : 'pixelated';

  if (fmt === 1) {
    createImageBitmap(new Blob([p], {type:'image/jpeg'})).then(function(b){
      // Upscale inside the canvas instead of letting CSS stretch a tiny canvas: a 180x240
      // backing store shown at ~700px wide goes through the browser's cheap bilinear filter,
      // which is exactly what makes the received picture look mushy. Size the canvas to the
      // real on-screen pixel size and let the canvas do one high-quality resample.
      var dpr = Math.min(2, window.devicePixelRatio || 1);
      var tw  = Math.min(w * 3, Math.max(w, Math.round((cv.clientWidth || w) * dpr)));
      var th  = Math.max(h, Math.round(tw * h / w));
      if (cv.width !== tw || cv.height !== th) { cv.width = tw; cv.height = th; }
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(b, 0, 0, tw, th);
    }).catch(function(){});
    return;
  }

  if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
  var img = ctx.createImageData(w, h), d = img.data;
  for (var i = 0, j = 0; i < len; i++, j += 4) {
    var v = p[i];
    d[j]     = (v >> 5) * 36.43;
    d[j + 1] = ((v >> 2) & 7) * 36.43;
    d[j + 2] = (v & 3) * 85;
    d[j + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
}

function tick(){
  fetch('/frame?since=' + seq, {cache:'no-store'}).then(function(r){
    return r.status === 200 ? r.arrayBuffer() : null;
  }).then(function(ab){
    if (ab) drawFrame(ab);
  }).catch(function(){}).then(function(){
    setTimeout(tick, 100);
  });
}

function poll(){
  fetch('/status', {cache:'no-store'}).then(function(r){ return r.json(); }).then(function(j){
    document.getElementById('fps').textContent = j.fps.toFixed(1);
    document.getElementById('okp').textContent = (j.showPct | 0) + '%';
    document.getElementById('kbs').textContent = j.kbps.toFixed(1);
    if (!gotFrame) {
      document.getElementById('bar').textContent = j.mode === 'RX'
        ? '已进入接收, 等 A 板推流…' : '当前不是接收角色 (串口输入 rx)';
    } else {
      document.getElementById('bar').innerHTML =
        '显示 <b>' + (j.shown | 0) + '</b>/' + (j.started | 0) + ' 帧 &middot; ' +
        j.w + 'x' + j.h + ' &middot; 块丢 ' + j.lossPct + '%' +
        ' &middot; 全齐 ' + (j.okPct | 0) + '% &middot; 噪声 ' + j.noise;
      // High loss still means stutter even with the retransmit pass, and the cheapest fix on
      // this link is a smaller frame rather than a different codec.
      if (j.lossPct > 12 && (j.okPct | 0) < 30) {
        document.getElementById('bar').innerHTML +=
          '<br><b style="color:#dc2626">块丢偏高, 画面会卡顿。' +
          '在 A 板页面把分辨率调到 240x180 或更低, 帧率会明显提升。</b>';
      }
    }
  }).catch(function(){}).then(function(){
    setTimeout(poll, 1000);
  });
}

tick();
poll();

// ================== Received video file ==================
// The board cannot decode H.264, so "preview" means: pull the stored bytes into a Blob and
// let the browser's own decoder play them. The same Blob feeds the download / share buttons,
// so nothing is re-fetched when the user saves it.
var fvBlob = null, fvState = -1, fvLoadedAt = 0;

function fbar(p){ document.getElementById('fbar').style.width = Math.max(0, Math.min(100, p)) + '%'; }

async function fload(){
  try {
    var r = await fetch('/file', {cache:'no-store'});
    if (!r.ok) { fvLoadedAt = Date.now(); return; }
    fvBlob = await r.blob();
    var v = document.getElementById('fvid');
    var isMp4 = (fvBlob.type || '').indexOf('mp4') >= 0;
    var a = document.getElementById('fdl');
    var url = URL.createObjectURL(fvBlob);
    // The board never decodes anything, so "preview" is the browser's own decoder. If this
    // browser cannot play the codec (H.265 in an MP4 is the common case on Android Chrome),
    // the file is still perfectly intact - say so instead of showing a black box.
    v.onerror = function(){
      v.style.display = 'none';
      document.getElementById('fstat').innerHTML =
        '<b style="color:#34d399">已收到 ' + (fvBlob.size / 1024).toFixed(0) + 'KB</b> · ' +
        (isMp4 ? 'MP4' : 'WebM') +
        ' · <b style="color:#fbbf24">这个浏览器解不了它的编码，但文件是完整的</b>，' +
        '点「下载到本地」保存后到相册/播放器里看。';
    };
    v.src = url;
    v.style.display = 'block';
    a.href = url;
    a.download = isMp4 ? 'w16.mp4' : 'w16.webm';
    document.getElementById('frow').style.display = 'flex';
    document.getElementById('fstat').innerHTML =
      '<b style="color:#34d399">已收到 ' + (fvBlob.size / 1024).toFixed(0) + 'KB</b> · ' +
      (isMp4 ? 'MP4/H.264' : 'WebM') + ' · 可直接播放或保存';
    fvLoadedAt = Date.now();
  } catch (e) { fvLoadedAt = Date.now(); }
}

async function fpoll(){
  try {
    var j = await (await fetch('/fstatus', {cache:'no-store'})).json();
    if (j.state === 1) {
      var pct = j.pages ? 100 * (j.done | 0) / j.pages : 0;
      fbar(pct);
      document.getElementById('fstat').innerHTML =
        '接收中 <b>' + (j.done | 0) + '/' + j.pages + '</b> 页 · ' +
        ((j.written | 0) / 1024).toFixed(0) + 'KB / ' + ((j.total | 0) / 1024).toFixed(0) + 'KB';
    } else if (j.state === 2) {
      fbar(100);
      if (fvState !== 2) { fvState = 2; fload(); }
    } else if (j.state === 3) {
      fbar(0);
      document.getElementById('fstat').innerHTML =
        '<b style="color:#dc2626">接收失败：</b>' + (j.err || '');
    } else if (j.state === 0) {
      if (fvState !== 0) { fvState = 0; }
      // Board B rebooted, or the page was opened later: the file is still on flash.
      if (!fvBlob && j.have) fload();
    }
  } catch (e) {}
  setTimeout(fpoll, 1000);
}

function fshare(){
  if (!fvBlob) return;
  var name = document.getElementById('fdl').download || 'w16.mp4';
  var f = new File([fvBlob], name, {type: fvBlob.type || 'video/mp4'});
  if (navigator.canShare && navigator.canShare({files: [f]})) {
    navigator.share({files: [f]}).catch(function(){});
  } else {
    alert('这个浏览器不支持直接分享，请用左边的「下载到本地」，文件会存到下载目录。');
  }
}

async function fdel(){
  if (!confirm('删除 B 板上保存的视频？')) return;
  await fetch('/fdel');
  fvBlob = null; fvState = 0;
  var v = document.getElementById('fvid');
  v.pause(); v.removeAttribute('src'); v.style.display = 'none';
  document.getElementById('frow').style.display = 'none';
  document.getElementById('fstat').textContent = '已删除';
  fbar(0);
}

fpoll();
</script>
</body></html>
)rawliteral";

// ==================== Web page (board A: streaming control) ====================
static const char PAGE_CTRL[] PROGMEM = R"rawliteral(
<!DOCTYPE html><html lang="zh-CN"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
<title>W16 视频发送</title>
<style>
  :root{--bg:#0e1116;--fg:#e8edf5;--dim:#8b95a7;--acc:#38bdf8;--ok:#34d399}
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--fg);
       font:14px/1.5 -apple-system,"Segoe UI",system-ui,"Microsoft YaHei",sans-serif}
  .wrap{max-width:760px;margin:0 auto;padding:16px}
  h1{font-size:17px;margin:0 0 12px;font-weight:600}
  h1 span{color:var(--dim);font-weight:400;font-size:12px;margin-left:8px}
  .stage{background:#000;border-radius:12px;overflow:hidden;position:relative;min-height:150px;
         box-shadow:0 6px 24px rgba(0,0,0,.5)}
  /* Smooth by default: a 320x240 canvas is stretched to the card width, and pixelated
     upscaling turns every pixel into a visible block (looks like mosaic even when the
     JPEG is fine). RGB332 switches this back to pixelated at runtime. */
  canvas{display:block;width:100%;height:auto;image-rendering:auto}
  .nodata{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
          color:var(--dim);font-size:13px;text-align:center;padding:0 20px}
  .row{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap}
  button{flex:1;min-width:92px;padding:11px 10px;border-radius:10px;border:1px solid #263040;
         background:#161b23;color:var(--fg);font-size:14px;cursor:pointer}
  button.on{background:#0c4a6e;border-color:#0ea5e9;color:#e0f2fe}
  button.pri{background:#0ea5e9;border-color:#0ea5e9;color:#001018;font-weight:600}
  .sec{margin-top:18px;font-size:12px;color:var(--dim);letter-spacing:.5px}
  .field{margin-top:10px;background:#161b23;border-radius:10px;padding:12px}
  .field label{display:flex;justify-content:space-between;font-size:13px;color:var(--dim)}
  .field label b{color:var(--acc);font-variant-numeric:tabular-nums}
  input[type=range]{width:100%;margin-top:8px;accent-color:#0ea5e9}
  .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:12px}
  .grid div{background:#161b23;border-radius:10px;padding:9px 8px;text-align:center}
  .grid b{display:block;font-size:16px;color:var(--ok);font-variant-numeric:tabular-nums}
  .grid small{display:block;color:var(--dim);font-size:11px}
  .msg{margin-top:12px;padding:10px 12px;border-radius:10px;font-size:12px;display:none}
  .msg.show{display:block}
  .msg.err{background:#3b1214;border:1px solid #7f1d1d;color:#fecaca}
  .tip{color:var(--dim);font-size:12px;margin-top:16px;line-height:1.7}
  .stat{margin-top:8px;font-size:12px;color:var(--dim)}
  .pbar{height:8px;background:#161b23;border-radius:6px;margin-top:10px;overflow:hidden}
  .pbar i{display:block;height:100%;width:0;background:#0ea5e9;transition:width .2s}
  code{background:#161b23;padding:1px 5px;border-radius:4px;color:var(--acc)}
  /* Do not hide the <video> with display:none - some browsers stop decoding it and
       drawImage yields black (symptom: "camera on but the picture is frozen").
       Keep it off-screen, 2x2 pixels and nearly transparent; it still decodes. */
  #vid{position:fixed;left:-4px;top:-4px;width:2px;height:2px;opacity:.01;
       pointer-events:none}
</style></head><body>
<div class="wrap">
  <h1>W16 视频发送 <span id="who">A 板 · 发送端 · v4</span></h1>

  <div class="stage">
    <canvas id="cv" width="96" height="64"></canvas>
    <div class="nodata" id="nodata">先选一个画面来源</div>
  </div>

  <div class="sec">画面来源</div>
  <div class="row">
    <button id="sCam"   onclick="useCam()">手机/电脑摄像头</button>
    <button id="sFile"  onclick="pickFile()">本地视频</button>
    <button id="sBoard" onclick="useBoard()">板载合成</button>
  </div>
  <div class="stat" id="camStat">未选择画面来源</div>
  <input type="file" id="file"    accept="video/*" style="display:none" onchange="onFile(this)">
  <input type="file" id="fileCam" accept="video/*" capture="environment" style="display:none" onchange="onFile(this)">

  <div class="row">
    <button class="pri" id="btnRun" onclick="toggle()">开始</button>
    <button onclick="snapOnce()">只发一帧</button>
  </div>

  <div class="sec">参数</div>
  <div class="field">
    <label>发送帧率 <b><span id="vFps">3</span> fps</b></label>
    <input type="range" id="rFps" min="1" max="10" value="3"
           oninput="fps=+this.value;document.getElementById('vFps').textContent=this.value;resetTimer()">
  </div>
  <div class="field">
    <label>分辨率 <b><span id="vRes">320 x 240</span></b></label>
    <div class="row" style="margin-top:8px">
      <button onclick="setRes(160,120)">160x120</button>
      <button onclick="setRes(240,180)">240x180</button>
      <button class="pri" id="r320" onclick="setRes(320,240)">320x240</button>
      <button onclick="setRes(480,360)">480x360</button>
    </div>
  </div>
  <div class="field">
    <label>JPEG 质量 <b><span id="vQ">0.50</span></b></label>
    <input type="range" id="rQ" min="20" max="85" value="50"
           oninput="qUser=+this.value/100;q=qUser;document.getElementById('vQ').textContent=q.toFixed(2)">
  </div>
  <div class="field">
    <label>包间隔上限 <b><span id="vGap">6</span> ms</b> <span style="color:#8b95a7;font-size:12px">板子会自己往下收敛</span></label>
    <input type="range" id="rGap" min="0" max="20" value="6"
           oninput="document.getElementById('vGap').textContent=this.value"
           onchange="setp('gap',this.value)">
  </div>

  <div class="grid">
    <div><b id="gFps">0</b><small>板上实际 fps</small></div>
    <div><b id="gKbs">0</b><small>KB/s</small></div>
    <div><b id="gGap">0</b><small>实际包间隔 ms</small></div>
    <div><b id="gUp">0</b><small>板子已收帧</small></div>
  </div>

  <div class="msg err" id="err"></div>

  <div class="sec">视频文件传输（H.264，整段存成文件）</div>
  <div class="field">
    <label>视频文件 <b><span id="fvName">未选择</span></b></label>
    <div class="row" style="margin-top:8px">
      <button onclick="document.getElementById('vfile').click()">选择本地视频</button>
      <button onclick="document.getElementById('vfileCam').click()">拍摄一段</button>
    </div>
    <input type="file" id="vfile"    accept="video/*" style="display:none" onchange="onVFile(this)">
    <input type="file" id="vfileCam" accept="video/*" capture="environment" style="display:none" onchange="onVFile(this)">
  </div>
  <div class="field">
    <label>码率 <b><span id="fvBr">600</span> kbps</b> <span style="color:#8b95a7;font-size:12px">清晰度主要看这个</span></label>
    <input type="range" id="fvBrR" min="100" max="3000" step="50" value="600"
           oninput="fvHint()">
  </div>
  <div class="field">
    <label>宽度 <b><span id="fvW">480</span> px</b> <span style="color:#8b95a7;font-size:12px">高度按片源比例</span></label>
    <input type="range" id="fvWR" min="160" max="720" step="16" value="480"
           oninput="fvHint()">
  </div>
  <div class="field">
    <label>帧率 <b><span id="fvF">15</span> fps</b> <span style="color:#8b95a7;font-size:12px">降帧率能把码率让给细节</span></label>
    <input type="range" id="fvFR" min="5" max="30" step="1" value="15"
           oninput="fvHint()">
  </div>
  <div class="stat" id="fvHint">—</div>
  <div class="row">
    <button class="pri" id="fvEnc" onclick="startEncode()">编码</button>
    <button id="fvRaw" onclick="useRaw()">原文件直传</button>
    <button id="fvSendBtn" onclick="startSend()">发送到 B 板</button>
  </div>
  <div class="stat" id="fvStat">未选择文件</div>
  <div class="pbar"><i id="fvBar"></i></div>

  <p class="tip">
    <b>文件传过来糊，几乎都是码率不够，不是链路的问题。</b>
    链路是逐字节校验的（每页 CRC32 + 全文件 CRC32），传过去的字节和手机上编码出来的完全一致，
    所以画质完全由编码那一刻决定。<br>
    判据是 <code>码率 ÷ (宽 × 高 × 帧率)</code>，即每像素每帧多少 bit：
    <b>低于 0.10 必糊</b>，0.16 偏软，0.25 在手机上看算干净，0.35 接近片源。
    上面那行会实时算给你看。<br>
    想更清楚，按效果排序：<b>① 提高码率</b>（最直接）<b>② 降低帧率</b>（15fps 对手机小屏足够，
    省下的码率全给细节）<b>③ 把宽度提到 480~640</b>（手机全屏看 320 宽一定是软的，
    但宽度翻倍会吃掉 4 倍码率，要一起调）<br>
    总预算是 <b>4.5MB</b>，也就是「码率 × 时长」有上限：600kbps 约能放 60 秒，
    2400kbps 约 15 秒。想要又长又清楚，就得分段传。<br>
    如果片源本身就是 MP4/WebM 且不到 4.5MB，直接用「<b>原文件直传</b>」——
    不重新编码，画质等于片源，这是这条链路上唯一真正的无损路径。
  </p>

  <p class="tip">
    画面统一用 <code>JPEG</code> 编码：320x240 一帧约 8~12KB，板端单帧上限 12288 字节。<br>
    质量是<b>自动收敛</b>的：只有单帧超过 11.8KB 才往下降 0.06，降下来之后只要有余量
    就会自己往滑块值涨回去，不会卡在最低质量上。<br>
    推送节奏会<b>自动跟住板子的实际发送能力</b>：板子只发得动 1.5fps 时，页面就按 1.5fps 推，
    不会白编码一堆帧再被丢掉（那样看起来反而更一顿一顿的）。<br>
    链路有效吞吐约 30~45KB/s，320x240 建议 <b>3fps</b>、480x360 建议 <b>2fps</b>；
    想更流畅就把分辨率降到 <b>240x180</b> 或 <b>160x120</b>，块数少了帧率立刻上去。<br>
    摄像头需要安全上下文：Chrome 打开
    <code>chrome://flags/#unsafely-treat-insecure-origin-as-secure</code>，
    填入 <code>http://192.168.4.1</code> → Enabled → Relaunch。
  </p>
</div>
<video id="vid" playsinline webkit-playsinline muted autoplay></video>
<script>
var cv = document.getElementById('cv'), ctx = cv.getContext('2d', {alpha:false});
// Downscaling 1080p to ~180x240 with the default 'low' filter is a big part of why the far end
// looks soft: the cheap filter drops detail and leaves aliasing on edges. 'high' is a proper
// multi-tap resample - same bytes per frame, visibly crisper picture.
ctx.imageSmoothingQuality = 'high';
var vid = document.getElementById('vid');

var W = 320, H = 240, fps = 3;
var pxBudget = 320 * 240;       // pixel budget picked by the resolution buttons; shape follows the source
var qUser = 0.50, q = 0.50;   // qUser = slider value, q = effective quality
var FRAME_MAX = 11800;         // 板端单帧上限 12288，留点余量
var lastBytes = 0;
var mode = 'board';            // 'cam' | 'file' | 'board'
var running = false, timer = null;
var inflight = false, sent = 0, fail = 0, lastCode = 0, dropped = 0;
var camStream = null, seq = 0;

function showErr(h){ var e=document.getElementById('err'); e.innerHTML=h; e.classList.add('show'); }
function hideErr(){ document.getElementById('err').classList.remove('show'); }
function nodata(t){
  var n = document.getElementById('nodata');
  if (t) { n.textContent = t; n.style.display = 'flex'; } else { n.style.display = 'none'; }
}
function mark(id){
  ['sCam','sFile','sBoard'].forEach(function(k){
    document.getElementById(k).className = (k === id) ? 'on' : '';
  });
}
function setp(k, v){ fetch('/set?k=' + k + '&v=' + v, {method:'POST'}).catch(function(){}); }
function send(path){ fetch(path, {method:'POST'}).catch(function(){}); }

// ---------------- Camera ----------------
// Pitfall: http://192.168.4.1 is not a secure context and Chrome removes
// navigator.mediaDevices entirely - clicking "camera" then does nothing at all.
// Strategy: capture live when possible, otherwise fall back to "record with the system
// camera" (input accept+capture), which does not need getUserMedia and always works.
function hasGUM(){
  return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
}

function camErrText(e){
  var n = (e && e.name) ? e.name : String(e);
  if (n === 'NotAllowedError' || n === 'SecurityError')
    return '权限被拒绝（或页面不是安全上下文）。点地址栏左边的图标，把"摄像头"改成允许。';
  if (n === 'NotFoundError' || n === 'DevicesNotFoundError')
    return '没找到摄像头设备。';
  if (n === 'NotReadableError' || n === 'TrackStartError')
    return '摄像头被别的 App 占用了（相机/微信/会议软件），先关掉它们再试。';
  if (n === 'OverconstrainedError')
    return '摄像头不支持这组参数（已自动用最宽松的参数重试）。';
  if (n === 'TypeError')
    return '页面拿不到 mediaDevices —— http 不是安全上下文，见下面的白名单步骤。';
  return n;
}

function releaseCam(){
  if (camStream) { camStream.getTracks().forEach(function(t){ t.stop(); }); camStream = null; }
}

function waitVideoReady(ms){
  return new Promise(function(res){
    var t0 = Date.now();
    (function chk(){
      if (vid.videoWidth > 0 && vid.readyState >= 2) return res(true);
      if (Date.now() - t0 > ms) return res(vid.videoWidth > 0);
      setTimeout(chk, 100);
    })();
  });
}

var camFallback = false;      // 实时摄像头失败后，按钮变成"系统相机录制"

async function useCam(){
  hideErr();

  // Already degraded once: open the system camera directly (must run inside the gesture, no await)
  if (camFallback) { document.getElementById('fileCam').click(); return; }

  stop();
  releaseCam();

  // 1) No mediaDevices (almost always an insecure http origin) -> use the system camera
  if (!hasGUM()) {
    camFallback = true;
    document.getElementById('sCam').textContent = '系统相机录制';
    document.getElementById('fileCam').click();
    return;
  }

  // 2) Try the ideal constraints first, retry once with the loosest ones
  var tries = [
    { video: { facingMode: {ideal:'environment'}, width:{ideal:640}, height:{ideal:480} }, audio:false },
    { video: true, audio: false }
  ];
  var lastErr = null;
  for (var i = 0; i < tries.length; i++) {
    try { camStream = await navigator.mediaDevices.getUserMedia(tries[i]); lastErr = null; break; }
    catch (e) { lastErr = e; camStream = null; }
  }
  if (!camStream) {
    // Note: after an await the browser no longer sees a user gesture, so the file picker
    // cannot be opened here - relabel the button "record with system camera" for a second click.
    camFallback = true;
    document.getElementById('sCam').textContent = '系统相机录制';
    showErr('<b>实时摄像头打不开：</b>' + camErrText(lastErr) +
      '<br>按钮已改成【系统相机录制】，<b>再点一次</b>就会打开系统相机录一段，' +
      '录完自动循环播放并上传。');
    mark('');
    return;
  }

  vid.removeAttribute('src');
  vid.srcObject = camStream;
  vid.loop = false; vid.muted = true;
  vid.setAttribute('playsinline', '');
  vid.setAttribute('webkit-playsinline', '');

  // 3) play() may be rejected by the autoplay policy - report it, otherwise "nothing happens"
  try {
    await vid.play();
  } catch (e) {
    showErr('<b>摄像头已授权，但画面没能开始播放：</b>' + camErrText(e) +
      '<br>点一下页面任意位置再试。');
  }
  if (!(await waitVideoReady(2500))) {
    showErr('<b>摄像头已授权，但一直没拿到画面</b>（videoWidth=0, readyState=' +
      vid.readyState + ', paused=' + vid.paused + '）。<br>' +
      '换个浏览器，或改用【本地视频】。');
  }

  mode = 'cam'; mark('sCam'); nodata('');
  fitToSource();          // no-op for a 4:3 camera in a 4:3 canvas, fixes odd ones
  setp('src', 1);
  start();
}

// ---------------- Local video / system camera recording ----------------
function pickFile(){ document.getElementById('file').click(); }

// A 16:9 file in a 4:3 canvas means a quarter of every encoded frame is picture the receiver
// never sees - the cover-fit crop throws it away after it has already been JPEG-compressed and
// sent. Match the canvas to the source instead.
//
// The resolution buttons pick a *pixel budget*, not a shape: a portrait 3:4 video at "320x240"
// becomes 240x320 - same number of pixels, same bytes per frame, but the whole picture fits and
// nothing is cropped. (Keeping the width instead, as a first attempt did, quietly gave portrait
// sources only 55% of the budget - which is the other half of why they looked soft.)
function fitToSource(){
  var vw = vid.videoWidth, vh = vid.videoHeight;
  if (!vw || !vh) return;
  var s = Math.sqrt(pxBudget / (vw * vh));
  var w = Math.round(vw * s), h = Math.round(vh * s);
  w -= w & 1; h -= h & 1;                              // even sizes keep JPEG chroma tidy
  if (w < 32 || h < 32) return;
  W = w; H = h;
  document.getElementById('vRes').textContent = w + ' x ' + h + '（跟随片源比例）';
}

function onFile(inp){
  var f = inp.files && inp.files[0];
  if (!f) return;
  hideErr();
  stop();
  releaseCam();
  if (vid.src && vid.src.indexOf('blob:') === 0) URL.revokeObjectURL(vid.src);
  vid.srcObject = null;
  vid.removeAttribute('src');
  vid.src = URL.createObjectURL(f);
  vid.loop = true; vid.muted = true;
  vid.setAttribute('playsinline', '');
  vid.setAttribute('webkit-playsinline', '');
  // videoWidth is only known after metadata loads - pick the canvas size then, not now
  vid.addEventListener('loadedmetadata', function once(){
    vid.removeEventListener('loadedmetadata', once);
    fitToSource();
  });
  vid.play().catch(function(){});
  mode = 'file'; mark('sFile'); nodata('');
  setp('src', 1);
  start();
  inp.value = '';        // 允许重复选同一个文件
}

// ---------------- Onboard synthetic ----------------
function useBoard(){
  hideErr();
  stop();
  releaseCam();
  try { vid.pause(); } catch (e) {}
  mode = 'board'; mark('sBoard');
  setp('src', 0);
  nodata('板载合成中');
  tick();
}

// ---------------- Capture -> JPEG ----------------
// A phone camera is 4:3 but a video file is usually 16:9, while the canvas is whatever the
// resolution buttons say - so drawImage(vid, 0,0,W,H) squashes the picture. Cover-fit instead:
// scale until both dimensions are filled, centre it, and let the excess be cropped. The aspect
// ratio is then correct and only the edges are lost, which is what a viewfinder does.
function drawFit(g, src, w, h){
  var vw = src.videoWidth || src.width;
  var vh = src.videoHeight || src.height;
  if (!vw || !vh) { g.drawImage(src, 0, 0, w, h); return; }
  var s  = Math.max(w / vw, h / vh);
  var sw = w / s, sh = h / s;
  g.drawImage(src, (vw - sw) / 2, (vh - sh) / 2, sw, sh, 0, 0, w, h);
}

var nullRun = 0;

function syncQ(){
  document.getElementById('rQ').value = Math.round(q * 100);
  document.getElementById('vQ').textContent = q.toFixed(2);
}

function postFrame(body, bytes){
  var fd = new FormData();
  fd.append('f', body, 'f.jpg');
  lastBytes = bytes;
  inflight = true;
  fetch('/upframe?w=' + W + '&h=' + H + '&fmt=1', {method:'POST', body: fd})
    .then(function(r){ lastCode = r.status; if (r.ok) sent++; else fail++; })
    .catch(function(){ fail++; })
    .then(function(){ inflight = false; });
}

function pushFrame(){
  if (mode === 'board') return;
  if (!vid.videoWidth || vid.readyState < 2) {
    // Never get a frame: do not fail silently, otherwise the user only sees "nothing happens"
    if (++nullRun === 40) {
      showErr('<b>画面源没有输出</b>：摄像头/视频还没就绪，或者浏览器把后台页面的解码停了。<br>' +
        '保持页面在前台，或重新选一次画面来源。');
    }
    return;
  }
  nullRun = 0;

  // Encode straight off the visible canvas: draw -> separate canvas -> toBlob costs one extra
  // full-frame copy per frame, which is real time at 320x240 on a phone.
  if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
  cv.style.imageRendering = 'auto';        // JPEG is a real photo: smooth upscale
  drawFit(ctx, vid, W, H);

  if (inflight) { dropped++; return; }
  inflight = true;                         // toBlob is async, hold the slot to avoid burst capture
  cv.toBlob(function(blob){
    inflight = false;
    if (!blob) { fail++; return; }
    // Over the board limit: drop this frame, step the quality down, retry on the next tick.
    if (blob.size > FRAME_MAX) {
      q = Math.max(0.20, q - 0.06); syncQ(); fail++; return;
    }
    // Room to spare: walk back up towards the slider value. Without this, one heavy frame
    // leaves the stream at q=0.20 forever - that was the real cause of the mosaic picture.
    if (blob.size < FRAME_MAX * 0.75 && q < qUser) { q = Math.min(qUser, q + 0.03); syncQ(); }
    postFrame(blob, blob.size);
  }, 'image/jpeg', q);
}

// Pacing: the board can only push ~38KB/s, so a 320x240 JPEG (10KB) tops out near 1.5fps no
// matter how often the page fires. Pushing at 3fps just throws half the encodes away and makes
// the motion uneven - which reads as stutter. So the page paces itself against the board.
//
// Feedback signal: the board reports both upFrames (what it received) and frames (what it
// actually managed to send). If we upload more than it sends, we are over-pushing; if it
// drains everything, there is headroom. That loop finds the real capacity instead of just
// locking in whatever rate it started at.
var paceMs = 0;                    // current send interval; 0 = use the slider
var winSent = 0, winTx = 0, winN = 0;
var lastSentCnt = 0, lastTxCnt = 0;

function baseMs(){ return Math.max(50, Math.round(1000 / fps)); }

function paceUpdate(sentDelta, txDelta){
  if (winN === 0) paceMs = paceMs || baseMs();
  winSent += sentDelta; winTx += txDelta; winN++;
  if (winN < 3) return;            // 3 polls ~= 3s, long enough that 1-frame granularity averages out
  if (winSent > winTx + 1)      paceMs = paceMs * 1.15;   // board fell behind: slow down
  else if (winSent > 0)         paceMs = paceMs * 0.93;   // board drained everything: try faster
  paceMs = Math.max(baseMs(), Math.min(3000, paceMs));
  winSent = 0; winTx = 0; winN = 0;
}

function nextDelay(){
  return Math.max(baseMs(), paceMs || 0);
}

function loop(){
  timer = null;
  if (!running || mode === 'board') return;
  pushFrame();
  timer = setTimeout(loop, nextDelay());
}

function resetTimer(){
  if (timer) { clearTimeout(timer); timer = null; }
  paceMs = baseMs();               // every (re)start probes from the slider value
  winSent = 0; winTx = 0; winN = 0;
  if (running && mode !== 'board') loop();
}

function start(){
  running = true;
  var b = document.getElementById('btnRun');
  b.textContent = '停止'; b.className = '';
  send('/start');
  resetTimer();
}
function stop(){
  running = false;
  var b = document.getElementById('btnRun');
  b.textContent = '开始'; b.className = 'pri';
  if (timer) { clearTimeout(timer); timer = null; }
  send('/stop');
}
function toggle(){
  if (running) { stop(); return; }
  if (mode === 'board') setp('src', 0);
  start();
}
function snapOnce(){
  if (mode === 'board') { send('/snap'); return; }
  pushFrame();
  setTimeout(function(){ send('/snap'); }, 150);
}

function setRes(w, h){
  // JPEG frames carry their real length, so any size is fine here - the page-side quality loop
  // and the board's 12288-byte cap are what actually bound a frame, not w*h.
  pxBudget = w * h;
  W = w; H = h;
  document.getElementById('vRes').textContent = w + ' x ' + h;
  // Re-shape to the source: the buttons choose how many pixels, the source chooses the aspect
  if (mode !== 'board') fitToSource();
  // The onboard animation is 1 raw byte per pixel, so it still cannot exceed the board buffer;
  // page frames carry their size in the URL, so the board w/h is not touched.
  if (mode === 'board' && w * h <= 12288) { setp('w', w); setp('h', h); }
}

// ---------------- Onboard mode: show the frame the board actually sent ----------------
function tick(){
  if (mode !== 'board') return;
  fetch('/frame?since=' + seq, {cache:'no-store'}).then(function(r){
    return r.status === 200 ? r.arrayBuffer() : null;
  }).then(function(ab){ if (ab) drawBoard(ab); })
   .catch(function(){}).then(function(){ setTimeout(tick, 250); });
}
function drawBoard(ab){
  var dv = new DataView(ab);
  if (dv.getUint8(0) !== 87 || dv.getUint8(1) !== 86) return;
  var fmt = dv.getUint8(3);
  var w = dv.getUint16(4), h = dv.getUint16(6), len = dv.getUint16(8);
  seq = dv.getUint32(10);
  var p = new Uint8Array(ab, 16, len);
  nodata('');
  if (fmt === 1) {
    createImageBitmap(new Blob([p], {type:'image/jpeg'})).then(function(b){
      if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
      ctx.drawImage(b, 0, 0, w, h);
    }).catch(function(){});
    return;
  }
  if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
  var img = ctx.createImageData(w, h), d = img.data;
  for (var i = 0, j = 0; i < len; i++, j += 4) {
    var v = p[i];
    d[j]     = (v >> 5) * 36.43;
    d[j + 1] = ((v >> 2) & 7) * 36.43;
    d[j + 2] = (v & 3) * 85;
    d[j + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
}

function camStatText(){
  if (mode === 'board') return '板载合成（画面由板子自己生成）';
  var name = (mode === 'cam') ? '摄像头' : '本地视频';
  if (!vid.videoWidth) return name + '：等待画面…（若一直这样，换【本地视频】或检查权限）';
  return name + '：' + vid.videoWidth + 'x' + vid.videoHeight +
         (vid.paused ? ' · 已暂停' : ' · 播放中') +
         ' → ' + W + 'x' + H + ' JPEG q' + q.toFixed(2) +
         (lastBytes ? ' · ' + Math.round(lastBytes / 1024) + 'KB/帧' : '') +
         ' · 推送 ' + (1000 / nextDelay()).toFixed(1) + 'fps' +
         ' · 已推 ' + sent + ' 帧' + (fail ? ' / 失败 ' + fail + '(HTTP ' + lastCode + ')' : '');
}

function poll(){
  fetch('/status', {cache:'no-store'}).then(function(r){ return r.json(); }).then(function(j){
    document.getElementById('gFps').textContent = j.fps.toFixed(1);
    document.getElementById('gKbs').textContent = j.kbps.toFixed(1);
    document.getElementById('gUp').textContent  = (j.upFrames | 0);
    document.getElementById('rGap').value = j.gapMax;
    document.getElementById('vGap').textContent = j.gapMax;
    document.getElementById('gGap').textContent = j.gap;
    // Feed the pacing loop: uploads vs. what the board actually got onto the air.
    var txNow = j.frames | 0;
    if (running && mode !== 'board') paceUpdate(sent - lastSentCnt, txNow - lastTxCnt);
    lastSentCnt = sent; lastTxCnt = txNow;
    document.getElementById('camStat').textContent = camStatText();
    if (j.mode !== 'TX') {
      showErr('板子当前不是发送角色，请在串口输入 <code>tx</code>');
    }
  }).catch(function(){}).then(function(){ setTimeout(poll, 1000); });
}

mark('sBoard');
cv.style.imageRendering = 'auto';
document.getElementById('vRes').textContent = W + ' x ' + H;
if (!hasGUM()) {
  document.getElementById('camStat').textContent =
    '当前页面拿不到摄像头接口（http 不是安全上下文）—— 点【手机/电脑摄像头】会自动改用系统相机录制';
}
poll();
tick();

// ================== H.264 file transfer ==================
// Neither board can encode or decode H.264 - the ESP32-S3 has no video codec at all. So the
// phone does both ends: it encodes the file with MediaRecorder, and the phone that opens
// board B's page plays it back with a plain <video>. The radio link is only a slow cable.
var fvSrcFile = null, fvBlob = null, fvMime = '', fvBusy = false;
var fvSrcDur = 0, fvSrcAR = 16 / 9;      // probe result: clip length and aspect ratio

// Bits per pixel per frame is the only number that predicts sharpness. 0.10 is visibly blocky,
// 0.16 is soft, 0.25 looks clean on a phone, 0.35 is close to "source quality". The sliders all
// feed the same budget: bitrate / (width x height x fps).
function fvHint(){
  var br  = (+document.getElementById('fvBrR').value) * 1000;
  var tw  = (+document.getElementById('fvWR').value) || 480;
  var fps = (+document.getElementById('fvFR').value) || 15;
  document.getElementById('fvBr').textContent = document.getElementById('fvBrR').value;
  document.getElementById('fvW').textContent  = tw;
  document.getElementById('fvF').textContent  = fps;

  var ar = fvSrcAR || 16 / 9;
  var th = Math.max(2, Math.round(tw / ar / 2) * 2);
  var bpp = br / (tw * th * fps);
  var verdict, color;
  if (bpp < 0.10)      { verdict = '很糊'; color = '#dc2626'; }
  else if (bpp < 0.16) { verdict = '偏软'; color = '#f59e0b'; }
  else if (bpp < 0.25) { verdict = '可看'; color = '#34d399'; }
  else                 { verdict = '清晰'; color = '#22d3ee'; }

  var s = tw + 'x' + th + ' · ' + bpp.toFixed(3) + ' bit/像素/帧 → ' +
          '<b style="color:' + color + '">' + verdict + '</b>';
  if (fvSrcDur) {
    var kb = br * fvSrcDur / 8 / 1024;          // KB
    s += '<br>片源 ' + fvSrcDur.toFixed(1) + 's，预计 <b>' + (kb / 1024).toFixed(2) + 'MB</b>' +
         ' · 传输约 ' + Math.ceil(kb / 11) + ' 秒';
    if (kb > 4608) s += ' · <b style="color:#dc2626">超出 4.5MB 上限</b>，缩短片段或降码率';
  }
  document.getElementById('fvHint').innerHTML = s;
}

function fvStat(t){ document.getElementById('fvStat').innerHTML = t; }
function fvBar(p){ document.getElementById('fvBar').style.width = Math.max(0, Math.min(100, p)) + '%'; }

// MP4/H.264 is the first choice: the file plays everywhere and downloads with a .mp4 name.
// High profile first, not Baseline. Baseline forbids B-frames and most of the coding tools, so at
// the same bitrate it throws away detail that High keeps for free - and the whole complaint here
// is that the picture looks soft. The page falls back one step at a time if a browser refuses it.
function pickMime(){
  var c = ['video/mp4;codecs=avc1.64001F',    // High 3.1
           'video/mp4;codecs=avc1.4D401F',    // Main 3.1
           'video/mp4;codecs=avc1.42E01E',    // Baseline 3.0
           'video/mp4;codecs=avc1', 'video/mp4',
           'video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'];
  for (var i = 0; i < c.length; i++) {
    try { if (window.MediaRecorder && MediaRecorder.isTypeSupported(c[i])) return c[i]; } catch (e) {}
  }
  return '';
}

// CRC32 (the same polynomial zlib and esp_rom_crc32_le use), so board B can prove the file it
// stored is byte-identical to the one encoded here.
function crc32(u8){
  if (!crc32.t) {
    var t = new Uint32Array(256);
    for (var n = 0; n < 256; n++) {
      var c = n;
      for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      t[n] = c >>> 0;
    }
    crc32.t = t;
  }
  var tt = crc32.t, c = 0xFFFFFFFF;
  for (var i = 0; i < u8.length; i++) c = tt[(c ^ u8[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}

function onVFile(inp){
  var f = inp.files && inp.files[0];
  if (!f) return;
  fvSrcFile = f; fvBlob = null; fvMime = '';
  fvSrcDur = 0; fvSrcAR = 16 / 9;
  document.getElementById('fvName').textContent = f.name || 'video';
  fvStat('已选择 ' + (f.size / 1048576).toFixed(1) + 'MB，点「编码」开始');
  fvBar(0);
  inp.value = '';
  fvHint();

  // Read the length and aspect ratio so the quality line can predict the file size. Cheap: only
  // the container header is fetched, the clip is not decoded.
  var pv = document.createElement('video');
  pv.preload = 'metadata';
  pv.muted = true;
  pv.onloadedmetadata = function(){
    if (isFinite(pv.duration) && pv.duration > 0) fvSrcDur = pv.duration;
    if (pv.videoWidth && pv.videoHeight) fvSrcAR = pv.videoWidth / pv.videoHeight;
    URL.revokeObjectURL(pv.src);
    fvHint();
  };
  pv.src = URL.createObjectURL(f);
}

// Encoding runs at playback speed: MediaRecorder stamps frames by wall clock, so a 20-second
// clip takes 20 seconds to encode. Trying to go faster would make the result play too fast.
async function startEncode(){
  if (fvBusy) return;
  if (!fvSrcFile) { fvStat('先选一个视频文件'); return; }
  var mime = pickMime();
  if (!mime) { fvStat('<b style="color:#dc2626">这个浏览器不支持视频编码</b>，请用 Chrome / Edge / Safari 新版'); return; }

  fvBusy = true;
  var br  = (+document.getElementById('fvBrR').value) * 1000;
  var tw  = +document.getElementById('fvWR').value;
  var fps = (+document.getElementById('fvFR').value) || 15;
  if (fps < 1) fps = 1;

  var v = document.createElement('video');
  v.src = URL.createObjectURL(fvSrcFile);
  v.muted = true; v.playsInline = true;
  await new Promise(function(r){ v.onloadedmetadata = r; });
  var th = Math.round(tw * (v.videoHeight || 9) / (v.videoWidth || 16));
  tw -= tw & 1; th -= th & 1;
  if (tw < 64 || th < 48) { fvBusy = false; fvStat('片源尺寸异常'); return; }

  var ec = document.createElement('canvas');
  ec.width = tw; ec.height = th;
  var eg = ec.getContext('2d');
  eg.imageSmoothingQuality = 'high';

  var stream = ec.captureStream(0);          // 0 = only frames we push ourselves
  var track  = stream.getVideoTracks()[0];

  // Some browsers report a profile as supported but still throw when asked to record it. Step
  // down the list instead of failing the whole encode over a codec string.
  var rec = null, tries = [mime, 'video/mp4', 'video/webm;codecs=vp9', 'video/webm'];
  for (var ti = 0; ti < tries.length && !rec; ti++) {
    try {
      rec = new MediaRecorder(stream, {mimeType: tries[ti], videoBitsPerSecond: br});
      mime = tries[ti];
    } catch (e) { rec = null; }
  }
  if (!rec) { fvBusy = false; URL.revokeObjectURL(v.src); fvStat('浏览器拒绝了这个编码参数，换 Chrome 试试'); return; }

  var parts = [];
  rec.ondataavailable = function(e){ if (e.data && e.data.size) parts.push(e.data); };
  var stopped = new Promise(function(r){ rec.onstop = r; });
  rec.start();

  var dur = v.duration || 0;
  if (!isFinite(dur) || dur <= 0) dur = 0;      // some containers report Infinity
  var t0 = performance.now();
  try { await v.play(); } catch (e) { fvBusy = false; fvStat('片源无法播放：' + e.message); return; }

  var step = 1000 / fps;
  while (!v.ended) {
    eg.drawImage(v, 0, 0, tw, th);
    if (track.requestFrame) track.requestFrame();
    var el = (performance.now() - t0) / 1000;
    fvBar(dur ? 100 * Math.min(1, el / dur) : 0);
    fvStat('编码中 ' + el.toFixed(1) + 's / ' + dur.toFixed(1) + 's · ' + tw + 'x' + th +
           ' · ' + fps + 'fps · ' + (br / 1000) + 'kbps');
    await new Promise(function(r){ setTimeout(r, step); });   // sample at the chosen frame rate
  }
  rec.stop();
  await stopped;
  URL.revokeObjectURL(v.src);

  fvBlob = new Blob(parts, {type: mime.split(';')[0]});
  fvMime = mime;
  fvBusy = false;
  fvBar(100);
  var pages = Math.ceil(fvBlob.size / 12288);
  var secs  = Math.ceil(fvBlob.size / 11000);   // ~11KB/s observed on this link
  var bpp   = br / (tw * th * fps);
  var line  = '<b>' + (fvBlob.size / 1024).toFixed(0) + 'KB</b> · ' + mime + ' · ' +
              tw + 'x' + th + ' · ' + bpp.toFixed(3) + ' bit/像素/帧 · ' +
              pages + ' 页 · 传输约 ' + secs + ' 秒';
  if (fvBlob.size > 4608 * 1024) {
    line += '<br><b style="color:#dc2626">超过板子 4.5MB 上限</b>：把码率调低，或换短一点的视频';
  }
  fvStat(line);
}

// H.264 is lossy by definition, so "lossless" can only mean one thing: do not re-encode at all.
// If the picked file is already an MP4/WebM that fits the 4.5MB partition, send its bytes as they
// are - the receiver gets a byte-identical copy, which is the only real 无损 path on this link.
// Re-encoding is for files that are too big or in a container the phone cannot play back.
function useRaw(){
  if (fvBusy) return;
  if (!fvSrcFile) { fvStat('先选一个视频文件'); return; }
  var t = (fvSrcFile.type || '').toLowerCase();
  if (t.indexOf('mp4') < 0 && t.indexOf('webm') < 0) {
    fvStat('<b style="color:#dc2626">这个文件不是 MP4/WebM</b>（' + (t || '未知类型') +
           '），板子存下来浏览器也放不了。请先点「编码」转成 MP4。');
    return;
  }
  if (fvSrcFile.size > 4608 * 1024) {
    fvStat('<b style="color:#dc2626">原文件 ' + (fvSrcFile.size / 1048576).toFixed(1) +
           'MB，超过板子 4.5MB 上限</b>。请点「编码」压到 4.5MB 以内。');
    return;
  }
  fvBlob = fvSrcFile;
  fvMime = fvSrcFile.type;
  var pages = Math.ceil(fvBlob.size / 12288);
  fvBar(0);
  fvStat('<b>' + (fvBlob.size / 1024).toFixed(0) + 'KB</b> · 原文件直传（不转码，逐字节一致）· ' +
         pages + ' 页 · 传输约 ' + Math.ceil(fvBlob.size / 11000) + ' 秒');
}

async function startSend(){
  if (!fvBlob) { fvStat('先点「编码」'); return; }
  if (fvBusy) return;
  fvBusy = true;

  var buf = new Uint8Array(await fvBlob.arrayBuffer());
  var crc = crc32(buf);
  var pages = Math.ceil(buf.length / 12288);
  fvBar(0);

  // A live stream would compete with the file for the same radio: board A sends a page before
  // anything else, so the two would just take turns and both crawl. Stop the stream first.
  if (running) stop();

  var j;
  var furl = '/fsend?total=' + buf.length + '&crc=' + crc.toString(16) + '&pages=' + pages;
  try {
    var r = await fetch(furl);
    j = await r.json();
    // 409 = the board still thinks a transfer is running (a page timed out earlier). Clear it
    // and start again instead of leaving the user with a dead button.
    if (r.status === 409) {
      await fetch('/fcancel');
      r = await fetch(furl);
      j = await r.json();
    }
  } catch (e) { fvBusy = false; fvStat('<b>板子没响应</b>，确认串口是 tx 角色'); return; }
  if (!j.ok) { fvBusy = false; fvStat('<b>开始失败：</b>' + (j.err || '')); return; }

  for (var p = 0; p < pages; p++) {
    var part = buf.slice(p * 12288, Math.min(buf.length, (p + 1) * 12288));
    var fd = new FormData();
    fd.append('f', new Blob([part]), 'p.bin');
    try {
      var pr = await fetch('/fpage?seq=' + p, {method: 'POST', body: fd});
      if (!pr.ok) { fvBusy = false; fvStat('<b>第 ' + (p + 1) + ' 页被板子拒收</b>（缓冲或长度问题）'); return; }
    }
    catch (e) { fvBusy = false; fvStat('<b>第 ' + (p + 1) + ' 页上传失败</b>'); return; }

    // Wait for the radio to finish this page before handing over the next one. That wait is
    // the flow control: the link moves ~11KB/s while HTTP moves megabytes per second.
    var okPage = false;
    for (var t = 0; t < 600; t++) {
      // 150ms, not 100ms: every poll is an HTTP round trip on the same antenna the radio is
      // using, and each one costs a couple of packets. 90 seconds of patience per page.
      await new Promise(function(r){ setTimeout(r, 150); });
      var st;
      try { st = await (await fetch('/fstatus')).json(); } catch (e) { continue; }
      if (st.state === 3) { fvBusy = false; fvStat('<b>传输中断：</b>' + (st.err || '')); return; }
      if ((st.done | 0) > p) { okPage = true; break; }
    }
    if (!okPage) { fvBusy = false; fvStat('<b>第 ' + (p + 1) + ' 页超时</b>'); return; }

    fvBar(100 * (p + 1) / pages);
    fvStat('发送中 ' + (p + 1) + '/' + pages + ' 页 · ' +
           ((p + 1) * 12288 / 1024).toFixed(0) + 'KB / ' + (buf.length / 1024).toFixed(0) + 'KB');
  }

  var fj;
  try { fj = await (await fetch('/fdone')).json(); }
  catch (e) { fj = {ok: false, err: '无响应'}; }
  fvBusy = false;
  if (fj.ok) {
    fvBar(100);
    fvStat('<b style="color:#34d399">传输完成</b> · 去 B 板页面（W16-LIVE）预览和下载');
  } else {
    fvStat('<b style="color:#dc2626">校验失败：</b>' + (fj.err || ''));
  }
}
fvHint();          // paint the quality readout with the default slider positions
</script>
</body></html>
)rawliteral";

// ==================== Web handlers ====================
void handleIndex() {
    webServer.sendHeader("Cache-Control", "no-store");
    if (gRole == ROLE_TX) {
        webServer.send_P(200, "text/html; charset=utf-8", PAGE_CTRL);
    } else {
        webServer.send_P(200, "text/html; charset=utf-8", PAGE_LIVE);
    }
}

// /frame?since=N
//   16-byte header + raw frame data; 204 when since is already the newest frame (saves WiFi).
//   header: 'W' 'V' ver fmt | w(2) h(2) len(2) seq(4) rsv(2)
void handleFrame() {
    const uint8_t* buf = nullptr;
    uint16_t len = 0, w = 0, h = 0;
    uint8_t  fmt = FMT_RGB332;
    uint32_t seq = 0;

    if (gRole == ROLE_TX) {
        buf = txBuf; len = txLastLen; w = txW; h = txH; fmt = txLastFmt;
        seq = gFrameId;
    } else {
        buf = liveBuf; len = liveLen; w = liveW; h = liveH; fmt = liveFmt;
        seq = liveSeq;
    }

    if (!buf || len == 0) {
        webServer.send(204, "text/plain", "");
        return;
    }

    if (webServer.hasArg("since")) {
        uint32_t since = (uint32_t)strtoul(webServer.arg("since").c_str(), nullptr, 10);
        if (since == seq) {
            webServer.send(204, "text/plain", "");
            return;
        }
    }

    uint8_t hdr[16];
    hdr[0] = 'W'; hdr[1] = 'V';
    hdr[2] = 1;
    hdr[3] = fmt;
    hdr[4] = (uint8_t)(w >> 8);   hdr[5] = (uint8_t)(w & 0xFF);
    hdr[6] = (uint8_t)(h >> 8);   hdr[7] = (uint8_t)(h & 0xFF);
    hdr[8] = (uint8_t)(len >> 8); hdr[9] = (uint8_t)(len & 0xFF);
    hdr[10] = (uint8_t)(seq >> 24); hdr[11] = (uint8_t)(seq >> 16);
    hdr[12] = (uint8_t)(seq >> 8);  hdr[13] = (uint8_t)(seq & 0xFF);
    hdr[14] = 0; hdr[15] = 0;

    webServer.sendHeader("Cache-Control", "no-store");
    webServer.setContentLength((size_t)len + 16);
    webServer.send(200, "application/octet-stream", "");
    webServer.sendContent((const char*)hdr, 16);
    webServer.sendContent((const char*)buf, len);
}

// Single parameter entry point: serial and web both come here, so the rules cannot diverge
bool applyParam(const char* k, long v) {
    if (!strcmp(k, "fps")) {
        if (v < 0) v = 0;
        if (v > 30) v = 30;
        gTargetFps = (uint8_t)v;
        Serial.print("[CFG] 目标帧率 "); Serial.print((int)gTargetFps); Serial.println("fps (0=不限)");
        return true;
    }
    if (!strcmp(k, "gap")) {
        if (v < 0) v = 0;
        if (v > 50) v = 50;
        gGapMax = (uint8_t)v;                     // ceiling only - the value self-tunes below it
        if (gGapMs > gGapMax) gGapMs = gGapMax;
        gapClean = 0;
        Serial.print("[CFG] 包间隔上限 "); Serial.print((int)gGapMax);
        Serial.print("ms (自动收敛, 当前 "); Serial.print((int)gGapMs); Serial.println("ms)");
        return true;
    }
    if (!strcmp(k, "src")) {
        gSrcMode = (v != 0) ? 1 : 0;
        gUpReady = false;
        txIdleLogged = false;
        Serial.print("[CFG] 画面来源 -> ");
        Serial.println(gSrcMode ? "网页推帧 (手机/电脑摄像头 或 本地视频)"
                                : "板载 (摄像头 / 合成动画)");
        return true;
    }
    if (!strcmp(k, "pattern")) {
        if (v < 0 || v > 2) return false;
        gPattern = (uint8_t)v;
        static const char* NAMES[3] = { "彩条", "弹跳方块", "彩虹扫描" };
        Serial.print("[CFG] 画面样式 "); Serial.println(NAMES[gPattern]);
        return true;
    }
    if (!strcmp(k, "w")) {
        if (v < 32 || v > 255) return false;
        if (v * (long)gVidH > VIDEO_BUF_CAP) {
            Serial.print("[CFG] w*h 超过 "); Serial.print(VIDEO_BUF_CAP);
            Serial.println(" 字节上限, 请先调小 h");
            return false;
        }
        gVidW = (uint16_t)v;
        Serial.print("[CFG] 画面 "); Serial.print(gVidW);
        Serial.print("x"); Serial.println(gVidH);
        return true;
    }
    if (!strcmp(k, "h")) {
        if (v < 24 || v > 255) return false;
        if ((long)gVidW * v > VIDEO_BUF_CAP) {
            Serial.print("[CFG] w*h 超过 "); Serial.print(VIDEO_BUF_CAP);
            Serial.println(" 字节上限, 请先调小 w");
            return false;
        }
        gVidH = (uint16_t)v;
        Serial.print("[CFG] 画面 "); Serial.print(gVidW);
        Serial.print("x"); Serial.println(gVidH);
        return true;
    }
    return false;
}

void handleSet() {
    if (!webServer.hasArg("k") || !webServer.hasArg("v")) {
        webServer.send(400, "application/json", "{\"ok\":false}");
        return;
    }
    bool ok = applyParam(webServer.arg("k").c_str(), webServer.arg("v").toInt());
    webServer.send(200, "application/json", ok ? "{\"ok\":true}" : "{\"ok\":false}");
}

void handleStart() {
    if (gRole != ROLE_TX) {
        webServer.send(409, "application/json", "{\"ok\":false,\"err\":\"not TX\"}");
        return;
    }
    gStreaming = true;       // streamVideo() starts as soon as the main loop sees this flag
    webServer.send(200, "application/json", "{\"ok\":true}");
}

void handleStop() {
    gStreaming = false;      // the while loop in streamVideo() exits
    webServer.send(200, "application/json", "{\"ok\":true}");
}

void handleSnap() {
    if (gRole != ROLE_TX) {
        webServer.send(409, "application/json", "{\"ok\":false}");
        return;
    }
    gSendOne = true;
    webServer.send(200, "application/json", "{\"ok\":true}");
}

// ---- Board A: receive frames pushed by the page (camera or local video) ----
// The page packs RGB332 (1 byte per pixel) and POSTs multipart/form-data to
// /upframe?w=96&h=64&fmt=0; upBuf is written while receiving.
// !! multipart is mandatory !! ESP32 WebServer only creates an upload context for
// multipart; with octet-stream the raw() branch reuses the same callback and
// webServer.upload() dereferences null -> LoadProhibited -> reboot, AP gone.
void handleUpChunk() {
    if (!webServer.header("Content-Type").startsWith("multipart/")) { upBadEnc = true; return; }
    if (gRole != ROLE_TX) { upBadEnc = true; return; }

    HTTPUpload& up = webServer.upload();

    if (up.status == UPLOAD_FILE_START) {
        upBadEnc = false;
        upLen = 0;
        // A new frame starts writing upBuf and voids the previous one even if unsent - for video
        // only the newest matters, and otherwise the sender could read a half-written buffer.
        gUpReady = false;
        upW = webServer.hasArg("w") ? (uint16_t)webServer.arg("w").toInt() : gVidW;
        upH = webServer.hasArg("h") ? (uint16_t)webServer.arg("h").toInt() : gVidH;
        upFmt = webServer.hasArg("fmt") ? (uint8_t)webServer.arg("fmt").toInt() : FMT_RGB332;
        // Only RGB332 is "1 byte per pixel", so only then can w*h validate the size. A JPEG is a
        // compressed stream: 320x240 gives w*h=76800, far over the buffer, while the payload may be
        // 8KB - judging it like RGB332 would reject every JPEG push.
        if (upW < 8 || upH < 8) upBadEnc = true;
        if (upFmt == FMT_RGB332 && (uint32_t)upW * upH > VIDEO_BUF_CAP) upBadEnc = true;
        return;
    }
    if (up.status == UPLOAD_FILE_WRITE) {
        if (upBadEnc || !upBuf || !up.currentSize) return;
        size_t n = up.currentSize;
        if ((uint32_t)upLen + n > VIDEO_BUF_CAP) { upBadEnc = true; upDrops++; return; }
        memcpy(upBuf + upLen, up.buf, n);
        upLen = (uint16_t)(upLen + n);
        return;
    }
    // UPLOAD_FILE_END is handled in handleUpDone()
}

void handleUpDone() {
    uint32_t need = (uint32_t)upW * upH;
    if (upBadEnc || upLen == 0 || (upFmt == FMT_RGB332 && (uint32_t)upLen < need)) {
        upDrops++;
        static bool warned = false;
        if (!warned) {
            warned = true;
            Serial.print("[UP] 拒绝网页帧: CT=\"");
            Serial.print(webServer.header("Content-Type"));
            Serial.print("\"  "); Serial.print((int)upLen);
            Serial.print("/");   Serial.print((int)need);
            Serial.println("B  (页面刷新到新版? 板子是 tx 吗?)");
        }
        webServer.send(400, "text/plain; charset=utf-8", "need multipart rgb332");
        return;
    }

    gUpReady = true;      // Handed to sendOneFrame()
    upFrames++;
    if (upFrames <= 2 || (upFrames % 150) == 0) {
        Serial.print("[UP] 网页帧 #"); Serial.print((int)upFrames);
        Serial.print("  "); Serial.print(upW); Serial.print("x"); Serial.print(upH);
        Serial.print("  "); Serial.print((int)upLen); Serial.println("B");
    }
    webServer.sendHeader("Cache-Control", "no-store");
    webServer.send(200, "application/json", "{\"ok\":true}");
}

// ==================== File transfer: HTTP endpoints ====================
// Board A keeps the file in the browser, not on its own flash, so a page is simply buffered
// and transmitted before the next one is accepted. That makes /fpage the flow-control point.
void handleFileSend() {
    if (gRole != ROLE_TX) { webServer.send(409, "application/json", "{\"ok\":false,\"err\":\"不是发送角色\"}"); return; }
    if (!fileBuf) { webServer.send(500, "application/json", "{\"ok\":false,\"err\":\"缓冲未分配\"}"); return; }
    // Two transfers at once cannot work: they share fileBuf and the radio. The page answers a
    // 409 here by cancelling and starting over, so a stuck transfer is never a dead end.
    if (fileState == 1) {
        webServer.send(409, "application/json", "{\"ok\":false,\"err\":\"已有传输在进行中\"}");
        return;
    }

    uint32_t total = (uint32_t)strtoul(webServer.arg("total").c_str(), nullptr, 10);
    uint32_t crc   = (uint32_t)strtoul(webServer.arg("crc").c_str(),   nullptr, 16);
    uint16_t pages = (uint16_t)webServer.arg("pages").toInt();

    // Live streaming blocks the loop inside streamVideo(), which would never reach the
    // file-page branch below - the transfer would hang on page 1 with no explanation.
    gStreaming = false;
    delay(20);

    fileSendReset();
    bool ok = fileSendBegin(total, crc, pages);
    String j = "{\"ok\":";
    j += (ok ? "true" : "false");
    j += ",\"err\":\""; j += fileErr; j += "\"}";
    webServer.sendHeader("Cache-Control", "no-store");
    webServer.send(ok ? 200 : 400, "application/json", j);
}

void handleFilePageChunk() {
    if (!webServer.header("Content-Type").startsWith("multipart/")) return;
    if (!fileBuf) return;
    HTTPUpload& up = webServer.upload();

    if (up.status == UPLOAD_FILE_START) {
        // If the previous page is still going out over the air, its bytes are being read out of
        // fileBuf right now - copying a new page in would corrupt both. Refuse instead.
        filePageReject = filePageBusy;
        filePageLen    = 0;
        if (filePageReject) return;
        filePageSeq    = webServer.hasArg("seq") ? (uint16_t)webServer.arg("seq").toInt() : 0;
        gFilePageReady = false;
        return;
    }
    if (filePageReject) return;
    if (up.status == UPLOAD_FILE_WRITE) {
        size_t n = up.currentSize;
        if ((uint32_t)filePageLen + n > FILE_PAGE_BYTES) { filePageLen = 0; return; }
        memcpy(fileBuf + filePageLen, up.buf, n);
        filePageLen = (uint16_t)(filePageLen + n);
        return;
    }
}

void handleFilePageDone() {
    if (filePageReject) {
        webServer.send(409, "application/json", "{\"ok\":false,\"err\":\"busy\"}");
        return;
    }
    if (!fileBuf || filePageLen == 0) {
        webServer.send(400, "application/json", "{\"ok\":false}");
        return;
    }
    gFilePageReady = true;
    webServer.sendHeader("Cache-Control", "no-store");
    webServer.send(200, "application/json", "{\"ok\":true}");
}

void handleFileDone() {
    bool ok = fileSendDone();
    fileState = ok ? 2 : 3;
    if (!ok && !fileErr[0]) snprintf(fileErr, sizeof(fileErr), "B 板校验未通过");
    String j = "{\"ok\":";
    j += (ok ? "true" : "false");
    j += ",\"err\":\""; j += fileErr; j += "\"}";
    webServer.sendHeader("Cache-Control", "no-store");
    webServer.send(ok ? 200 : 400, "application/json", j);
}

void handleFileCancel() {
    fileSendReset();
    fileRxResetAll();
    fileRxState = 0;
    webServer.send(200, "application/json", "{\"ok\":true}");
}

// Board B: download what was stored. streamFile() blocks, but a finished transfer means the
// radio is idle, so nothing is lost by it.
void handleFileGet() {
    if (!ensureFs()) { webServer.send(404, "text/plain; charset=utf-8", "no fs"); return; }
    // The marker is the only proof the CRC check passed. A file without it is a leftover from
    // an interrupted transfer and would play as a black screen.
    if (!LittleFS.exists(FILE_OK_PATH)) {
        webServer.send(404, "text/plain; charset=utf-8", "no complete file");
        return;
    }
    if (!LittleFS.exists(FILE_PATH)) { webServer.send(404, "text/plain; charset=utf-8", "no file"); return; }
    File f = LittleFS.open(FILE_PATH, "r");
    if (!f) { webServer.send(500, "text/plain; charset=utf-8", "open fail"); return; }

    // Tell MP4 from WebM by the box header instead of guessing: the page picks the container,
    // and the board never sees the name. Bytes 4..7 of an MP4 are 'ftyp'; a WebM starts with
    // EBML (0x1A45DFA3).
    char hdr[12] = {0};
    f.read((uint8_t*)hdr, 12);
    f.seek(0);
    bool isMp4 = (hdr[4] == 'f' && hdr[5] == 't' && hdr[6] == 'y' && hdr[7] == 'p');

    webServer.sendHeader("Content-Disposition",
                         isMp4 ? "attachment; filename=\"w16.mp4\""
                               : "attachment; filename=\"w16.webm\"");
    webServer.sendHeader("Cache-Control", "no-store");
    webServer.streamFile(f, isMp4 ? "video/mp4" : "video/webm");
    f.close();
}

void handleFileDelete() {
    if (ensureFs()) {
        if (LittleFS.exists(FILE_PATH))    LittleFS.remove(FILE_PATH);
        if (LittleFS.exists(FILE_OK_PATH)) LittleFS.remove(FILE_OK_PATH);
    }
    fileRxResetAll();
    fileRxState = 0;
    webServer.send(200, "application/json", "{\"ok\":true}");
}

void handleFileStatus() {
    String j = "{\"role\":\"";
    j += (gRole == ROLE_TX ? "TX" : (gRole == ROLE_RX ? "RX" : "IDLE"));
    if (gRole == ROLE_TX) {
        j += "\",\"state\":"; j += String((int)fileState);
        j += ",\"done\":";    j += String((int)filePageDone);
        j += ",\"pages\":";   j += String((int)filePages);
        j += ",\"total\":";   j += String((int)fileTotal);
        j += ",\"err\":\"";   j += fileErr; j += "\"";
    } else {
        j += "\",\"state\":"; j += String((int)fileRxState);
        j += ",\"done\":";    j += String((int)fileRxPage);
        j += ",\"pages\":";   j += String((int)fileRxPages);
        j += ",\"total\":";   j += String((int)fileRxTotal);
        j += ",\"written\":"; j += String((int)fileRxWritten);
        j += ",\"max\":";     j += String((int)FILE_MAX_BYTES);
        // A file already on flash survives a reboot, and the page has to find it again without
        // a new transfer - otherwise the video looks lost until board A sends it a second time.
        j += ",\"have\":";    j += (ensureFs() && LittleFS.exists(FILE_PATH) && LittleFS.exists(FILE_OK_PATH)) ? "1" : "0";
        j += ",\"err\":\"";   j += fileErr; j += "\"";
    }
    j += "}";
    webServer.sendHeader("Cache-Control", "no-store");
    webServer.send(200, "application/json", j);
}

void handleStatus() {
    // Frame rate from a 1-second sliding window, not an average since boot
    static uint32_t lastMs = 0, lastFrames = 0;
    static float fps = 0, kbps = 0;
    uint32_t now = millis();
    if (now - lastMs >= 900) {
        // RX uses the frames actually displayed, otherwise the page shows 0fps (few complete frames)
        uint32_t f = (gRole == ROLE_TX) ? txFrames : rxShown;
        uint32_t b = (gRole == ROLE_TX) ? txLastLen : liveLen;
        uint32_t df = f - lastFrames;
        float dt = (float)(now - lastMs) / 1000.0f;
        if (dt > 0.05f) {
            fps  = (float)df / dt;
            kbps = (float)df * (float)b / dt / 1024.0f;
        }
        lastFrames = f;
        lastMs = now;
    }

    float okPct   = rxStarted ? ((float)rxFrames * 100.0f / (float)rxStarted) : 0.0f;
    float showPct = rxStarted ? ((float)rxShown  * 100.0f / (float)rxStarted) : 0.0f;
    float lossPct = (rxPackets + rxMissChunks)
                  ? ((float)rxMissChunks * 100.0f / (float)(rxPackets + rxMissChunks)) : 0.0f;

    String j = "{";
    j += "\"mode\":\"";
    j += (gRole == ROLE_TX ? "TX" : (gRole == ROLE_RX ? "RX" : "IDLE"));
    j += "\",\"ip\":\""; j += (gWifiOn ? WiFi.softAPIP().toString() : String(""));
    j += "\",\"fps\":";   j += String(fps, 2);
    j += ",\"kbps\":";    j += String(kbps, 2);
    j += ",\"w\":";       j += String((int)(gRole == ROLE_TX ? (txW ? txW : gVidW) : liveW));
    j += ",\"h\":";       j += String((int)(gRole == ROLE_TX ? (txH ? txH : gVidH) : liveH));
    j += ",\"len\":";     j += String((int)(gRole == ROLE_TX ? txLastLen : liveLen));
    j += ",\"frames\":";  j += String((int)(gRole == ROLE_TX ? txFrames : rxFrames));
    j += ",\"shown\":";   j += String((int)rxShown);
    j += ",\"started\":"; j += String((int)rxStarted);
    j += ",\"dropped\":"; j += String((int)rxDropped);
    j += ",\"okPct\":";   j += String((int)(okPct + 0.5f));
    j += ",\"showPct\":"; j += String((int)(showPct + 0.5f));
    j += ",\"lossPct\":"; j += String(lossPct, 1);
    j += ",\"noise\":";   j += String((int)rxNoise);
    j += ",\"streaming\":"; j += (gStreaming ? "true" : "false");
    j += ",\"pattern\":"; j += String((int)gPattern);
    j += ",\"tFps\":";    j += String((int)gTargetFps);
    j += ",\"gap\":";     j += String((int)gGapMs);
    j += ",\"gapMax\":";  j += String((int)gGapMax);
    j += ",\"vW\":";      j += String((int)gVidW);
    j += ",\"vH\":";      j += String((int)gVidH);
    j += ",\"src\":";     j += String((int)gSrcMode);       // 0 = onboard, 1 = page push
    j += ",\"upFrames\":"; j += String((int)upFrames);      // page frames received by the board
    j += ",\"upDrops\":";  j += String((int)upDrops);
    j += ",\"cap\":";      j += String((int)VIDEO_BUF_CAP);  // per-frame byte cap

    // ---- AP diagnostics: these fields pin down "the phone cannot see the SSID" ----
    gApClients = gWifiOn ? (uint8_t)WiFi.softAPgetStationNum() : 0;
    j += ",\"ap\":";      j += (gWifiOn ? "true" : "false");
    j += ",\"ch\":";      j += String((int)gApChannelNow);
    j += ",\"sta\":";     j += String((int)gApClients);
    j += ",\"heap\":";    j += String((int)(ESP.getFreeHeap() / 1024));
    j += "}";
    webServer.sendHeader("Cache-Control", "no-store");
    webServer.send(200, "application/json", j);
}

// ==================== AP: channel and TX power ====================
// Two boards on one desk hit two traps that make phones see only one AP:
//   1) same channel -> co-channel pressure, the scan list keeps the stronger one;
//   2) 20dBm at ~10cm -> the phone front end is blocked and the other AP vanishes.
// Default: channels split by role (A=6 / B=11), 15dBm.
// The scan-based channel picker was dropped as well: on ESP32-S3 softAP() sometimes
// returns true without broadcasting any beacon.
static uint8_t channelForRole() {
    // Both boards use ch1 = 2412MHz, 38MHz away from the 2450MHz FLRC carrier. The AP and the
    // radio share one antenna, so a nearby channel desenses the receiver: ch6 (13MHz away) and
    // ch11 (12MHz) are what produced the 28% chunk loss. A per-role split does not help - board
    // A keeps beaconing while it transmits, so its channel hurts board B just as much. Within
    // the 1~11 range the ESP32 allows by default, ch1 is the only one far enough.
    return 1;
}

// dBm -> ESP32 power level enum
static wifi_power_t dbmToPower(int dbm) {
    if (dbm <= 8)  return WIFI_POWER_8_5dBm;
    if (dbm <= 11) return WIFI_POWER_11dBm;
    if (dbm <= 13) return WIFI_POWER_13dBm;
    if (dbm <= 15) return WIFI_POWER_15dBm;
    if (dbm <= 17) return WIFI_POWER_17dBm;
    if (dbm <= 19) return WIFI_POWER_19dBm;
    return WIFI_POWER_19_5dBm;
}

// Bring the AP up, 3 attempts. WiFi.mode(WIFI_AP) must be followed by a delay: calling
// softAP() right away sometimes returns success without broadcasting any beacon (the phone
// never sees the SSID). So check the real IP, not just the return value.
static bool apStart(const char* ssid, uint8_t ch) {
    if (ch < 1 || ch > 13) ch = 6;

    for (int attempt = 1; attempt <= 3; attempt++) {
        // Clean up first: previous AP, leftover STA link, then WiFi fully off
        WiFi.softAPdisconnect(true);
        WiFi.mode(WIFI_OFF);
        delay(300);

        WiFi.persistent(false);
        WiFi.mode(WIFI_AP);
        delay(400);                 // This delay cannot be skipped - it is the number one cause of "SSID not found"

        WiFi.softAPConfig(IPAddress(192, 168, 4, 1), IPAddress(192, 168, 4, 1),
                          IPAddress(255, 255, 255, 0));

        if (WiFi.softAP(ssid, AP_PASS, ch, 0, 4)) {
            WiFi.setSleep(false);   // The AP must not use power save, or beacons get irregular and harder to find
            WiFi.setTxPower(dbmToPower(gApPowerDbm));
            delay(250);
            IPAddress ip = WiFi.softAPIP();
            if ((uint32_t)ip != 0) {
                Serial.print("[WEB] softAP OK  模式="); Serial.print((int)WiFi.getMode());
                Serial.print("  IP="); Serial.print(ip);
                Serial.print("  功率="); Serial.print((int)gApPowerDbm);
                Serial.println("dBm");
                return true;
            }
            Serial.println("[WEB] softAP 返回 true 但没拿到 IP, 重来");
        } else {
            Serial.print("[WEB] 第"); Serial.print(attempt);
            Serial.println("次 softAP 失败, 重试…");
        }
        delay(500);
    }
    return false;
}

void startWeb() {
    if (gWifiOn) return;

    const char* ssid = gSsidOverride ? gSsidOverride
                                     : ((gRole == ROLE_TX) ? AP_SSID_TX : AP_SSID_RX);

    uint8_t ch = gApChannel;
    if (ch == 0) {
        ch = channelForRole();
        Serial.print("[WEB] 自动信道: "); Serial.println(ch);
    } else {
        Serial.print("[WEB] 使用指定信道 "); Serial.println(ch);
    }
    // softAP() rejects ch12/13 with the default country code (cc=01, 1~11) and fails all three
    // retries, leaving the board with no AP at all - which is exactly what ch13 did once.
    if (ch > 11) {
        Serial.print("[WEB] 信道 "); Serial.print(ch);
        Serial.println(" 超出 1~11, 改用 1");
        ch = 1;
    }

    if (!apStart(ssid, ch)) {
        Serial.println("[WEB] 热点启动失败 (3 次都失败)");
        Serial.println("[WEB]   输入 wifi 重开一次; 仍失败请查供电/天线");
        return;
    }
    gApChannelNow = ch;

    // Register routes once only: WebServer::on() appends to the handler list, so repeated
    // stopWeb()/startWeb() would stack several callbacks on the same URI.
    static bool routesReady = false;
    if (!routesReady) {
        // !! Headers must be registered explicitly !!
        // WebServer collects no header by default (_collectAllHeaders=false), so
        // webServer.header("Content-Type") always returns "" and the upload guard fails 100%.
        static const char* kHdrs[] = {"Content-Type", "Content-Length"};
        webServer.collectHeaders(kHdrs, 2);

        webServer.on("/",        handleIndex);
        webServer.on("/frame",   handleFrame);
        webServer.on("/status",  handleStatus);
        webServer.on("/set",     handleSet);
        webServer.on("/start",   handleStart);
        webServer.on("/stop",    handleStop);
        webServer.on("/snap",    handleSnap);
        // page push: completion callback + chunk callback (writes upBuf while receiving)
        webServer.on("/upframe", HTTP_POST, handleUpDone, handleUpChunk);
        // ---- video file transfer (H.264 file, not a live stream) ----
        webServer.on("/fsend",   handleFileSend);
        webServer.on("/fpage",   HTTP_POST, handleFilePageDone, handleFilePageChunk);
        webServer.on("/fdone",   handleFileDone);
        webServer.on("/fcancel", handleFileCancel);
        webServer.on("/fstatus", handleFileStatus);
        webServer.on("/file",    handleFileGet);
        webServer.on("/fdel",    handleFileDelete);
        // The icon every browser requests; answer 204 so it does not land in the 404 log
        webServer.on("/favicon.ico", []() { webServer.send(204, "text/plain", ""); });
        webServer.onNotFound([]() {
            webServer.send(404, "text/plain; charset=utf-8", "404");
        });
        routesReady = true;
    }
    webServer.begin();

    gWifiOn = true;
    Serial.print("[WEB] 热点 "); Serial.print(ssid);
    Serial.print(" / ");         Serial.print(AP_PASS);
    Serial.print("  信道 ");     Serial.print((int)ch);
    Serial.print(" (");          Serial.print(2407 + ch * 5); Serial.print("MHz)");
    Serial.print("  功率 ");     Serial.print((int)gApPowerDbm); Serial.print("dBm");
    Serial.print("  IP ");       Serial.print(WiFi.softAPIP());
    Serial.print("  MAC ");      Serial.println(WiFi.softAPmacAddress());
    Serial.print("[WEB] 手机打开 http://"); Serial.print(WiFi.softAPIP());
    Serial.print("/   (空闲堆 "); Serial.print(ESP.getFreeHeap() / 1024);
    Serial.println("KB)");
    Serial.println("[WEB] 手机搜不到热点? 1) 手机 WiFi 关掉再开 2) 串口 ch 6 换信道");
    Serial.println("[WEB]   3) 串口 power 20 加大功率 4) 仍不行查天线/供电");
}

void stopWeb() {
    if (!gWifiOn) return;
    webServer.stop();
    WiFi.softAPdisconnect(true);
    delay(120);          // Disconnect the client and let lwIP settle before switching the mode off.
// Doing it too fast logs "netstack cb reg failed with 12308" (harmless but noisy).
    WiFi.mode(WIFI_OFF);
    delay(200);          // Give the driver time to really stop, otherwise startWeb() right after fails
    gWifiOn = false;
    gApClients = 0;
    gSsidOverride = nullptr;
    Serial.println("[WEB] 热点已关闭");
}

// ==================== Board status summary ====================
// Printed after tx / rx / idle: role, AP, radio, picture and what to do next, so the state
// of the board is obvious without looking anywhere else.
static void printBoardStatus() {
    Serial.println("[STATUS] ─────────── 板子状态 ───────────");

    Serial.print("[STATUS] 角色    ");
    if (gRole == ROLE_TX)      Serial.println("TX · 推流端 (A 板)");
    else if (gRole == ROLE_RX) Serial.println("RX · 接收端 (B 板)");
    else                       Serial.println("IDLE · 已停收发 (射频 standby)");

    Serial.print("[STATUS] 热点    ");
    if (gWifiOn) {
        const char* ssid = (gRole == ROLE_TX) ? AP_SSID_TX
                         : (gRole == ROLE_RX ? AP_SSID_RX : "W16-WEB");
        Serial.print(ssid); Serial.print(" / "); Serial.print(AP_PASS);
        Serial.print("   信道 "); Serial.print((int)gApChannelNow);
        Serial.print(" ("); Serial.print(2407 + (int)gApChannelNow * 5); Serial.print("MHz)");
        Serial.print("  "); Serial.print((int)gApPowerDbm); Serial.print("dBm");
        Serial.print("  IP "); Serial.print(WiFi.softAPIP());
        Serial.print("  已连 "); Serial.print((int)WiFi.softAPgetStationNum()); Serial.println(" 台");
    } else {
        Serial.println("关 —— 输 tx 或 rx 时会一起打开");
    }

    Serial.print("[STATUS] 射频    ");
    if (gRadioOk) {
        Serial.print("OK  FLRC "); Serial.print(FLRC_FREQ, 1);
        Serial.print("MHz  ");    Serial.print(FLRC_BR);
        Serial.print("kbps  CR1/2  pre="); Serial.print(FLRC_PRE);
        Serial.print("  pkt=");   Serial.println((unsigned int)sizeof(VideoPacket));
    } else {
        Serial.println("未初始化 —— 查接线 SCK=12 MISO=11 MOSI=10 NSS=47 RST=39");
    }

    Serial.print("[STATUS] 画面    ");
    if (gRole == ROLE_TX) {
        if (gSrcMode == 1) {
            Serial.print("网页推帧 (手机/电脑摄像头 或 本地视频)  已收 ");
            Serial.print((int)upFrames); Serial.print(" 帧");
            if (txLastLen) {
                Serial.print("  最近一帧 ");
                Serial.print(txW); Serial.print("x"); Serial.print(txH);
                Serial.print("  "); Serial.print(txLastFmt == FMT_JPEG ? "JPEG" : "RGB332");
                Serial.print("  "); Serial.print((int)txLastLen); Serial.print("B  ");
                Serial.print((txLastLen + VIDEO_CHUNK - 1) / VIDEO_CHUNK); Serial.print(" 块");
            }
            Serial.println();
        } else {
            int w = txW ? txW : gVidW;
            int h = txH ? txH : gVidH;
            int len = txLastLen ? txLastLen : (gVidW * gVidH);   // RGB332: one byte per pixel
            Serial.print("板载合成  ");
            Serial.print(w); Serial.print("x"); Serial.print(h);
            Serial.print("  RGB332  "); Serial.print(len); Serial.print("B/帧  ");
            Serial.print((len + VIDEO_CHUNK - 1) / VIDEO_CHUNK); Serial.println(" 块");
        }
    } else if (gRole == ROLE_RX) {
        if (liveLen) {
            Serial.print(liveW); Serial.print("x"); Serial.print(liveH);
            Serial.print("  "); Serial.print(liveFmt == FMT_JPEG ? "JPEG" : "RGB332");
            Serial.print("  "); Serial.print((int)liveLen); Serial.println("B/帧 (已收到画面)");
        } else {
            Serial.print(gVidW); Serial.print("x"); Serial.print(gVidH);
            Serial.println("  RGB332  (还没收到画面)");
        }
    } else {
        Serial.print(gVidW); Serial.print("x"); Serial.print(gVidH);
        Serial.print("  合成动画 样式 "); Serial.println((int)gPattern);
    }

    Serial.print("[STATUS] 下一步  ");
    if (gRole == ROLE_TX) {
        Serial.println(gStreaming
            ? "正在推流 (网页点停止 / 按 BOOT / 输 idle 停)"
            : "手机连 W16-CAM -> http://192.168.4.1/ 选摄像头或本地视频后点\"开始\"");
    } else if (gRole == ROLE_RX) {
        Serial.println("手机连 W16-LIVE -> http://192.168.4.1/ 看画面; A 板输 tx 开始推流");
    } else {
        Serial.println("输 tx (A 板推流) 或 rx (B 板收画面)");
    }
    Serial.println("[STATUS] ──────────────────────────────");
    Serial.flush();
}

// ==================== Role switching ====================
void switchRole(Role r) {
    // Typing the same role again reopens the AP and prints the status, and it must say
    // something: a silent working command looks like a lost command.
    if (r == gRole) {
        if (r == ROLE_IDLE) {
            Serial.println("[MODE] 已经是 IDLE (不收发, 热点已关)");
        } else if (gWifiOn) {
            Serial.print("[MODE] 已经是 ");
            Serial.print(r == ROLE_TX ? "TX" : "RX");
            Serial.print(", 热点 ");
            Serial.print(r == ROLE_TX ? AP_SSID_TX : AP_SSID_RX);
            Serial.println(" 正在运行 (重复输入=重开热点)");
        } else {
            Serial.print("[MODE] 已经是 ");
            Serial.print(r == ROLE_TX ? "TX" : "RX");
            Serial.println(", 但热点没开, 正在重开…");
            startWeb();
        }
        printBoardStatus();   // Print the status again on a repeated command, for confirmation
        return;
    }

    // tx/rx still work when the radio failed to init - AP and web page are independent of the
    // radio. Returning early here used to keep the AP down whenever the radio was broken, so the
    // phone never saw W16-CAM and it looked like a WiFi fault.
    if (!gRadioOk && r != ROLE_IDLE) {
        Serial.println("[MODE] 注意: 射频未初始化, 热点照常打开, 但画面传不出去");
        Serial.println("[MODE]   网页预览/调参可用; 收发请先修射频接线");
    }

    gStreaming = false;
    if (gRadioOk) radio.standby();
    delay(5);

    // The SSID follows the role (A = W16-CAM / B = W16-LIVE). The old AP must be torn down
    // first, otherwise startWeb() returns early because gWifiOn is still true.
    if (gWifiOn) stopWeb();

    if (r == ROLE_TX) {
        gRole = ROLE_TX;
        gFrameId = 0;
        txFrames = 0; txPkts = 0; txBytes = 0;
        txLastLen = 0;
        ledBlue();
        Serial.println("[MODE] TX —— 推流端 (网页点开始 / 按 BOOT / 输入 send)");
        startWeb();
    } else if (r == ROLE_RX) {
        gRole = ROLE_RX;
        rxCurTotal = 0; rxGot = 0; rxCurId = 0; rxCurLen = 0;
        rxCurW = 0; rxCurH = 0; rxCurFmt = FMT_RGB332;
        bmClearAll(rxHave);
        liveLen = 0; liveSeq = 0; liveW = 0; liveH = 0;
        rxFrames = 0; rxShown = 0; rxDropped = 0; rxStarted = 0;
        rxMissChunks = 0; rxPackets = 0; rxNoise = 0; rxOtherErr = 0;
        rxPrevFrames = 0; rxPrevShown = 0; rxPrevPkts = 0;
        rxPrevMiss = 0; rxPrevNoise = 0; rxStatMs = millis();
        rxSilent = true;
        if (gRadioOk) enterRx();
        ledBlue();
        Serial.println("[MODE] RX —— 接收画面 (没画面时串口安静, 收到才报)");
        startWeb();
    } else {
        gRole = ROLE_IDLE;
        if (gRadioOk) radio.standby();
        ledOff();
        stopWeb();
        Serial.println("[MODE] IDLE —— 射频 standby");
    }

    // The role is not stored in NVS: boot is always IDLE and tx / rx must be typed.
    // (Storing it and restoring in setup() is what made the board flood RX with no command.)
    printBoardStatus();
}

// ==================== Serial ====================
void printHelp() {
    Serial.println();
    Serial.println("Commands (type and press Enter):");
    Serial.println("  tx        A 板: 开始推流 + 开热点 W16-CAM");
    Serial.println("  rx        B 板: 收流 + 开热点 W16-LIVE + 网页看画面");
    Serial.println("  idle      停止收发 (射频 standby)");
    Serial.println("  send      A 板: 只推一帧 (调试)");
    Serial.println("  src 0/1   A 板画面来源: 0=板载合成  1=网页推帧(手机摄像头/本地视频)");
    Serial.println("  fps N     目标帧率上限 (默认 4, 0=不限)");
    Serial.println("  gap N     包间隔上限 ms (默认 6; 实际值自动收敛, 越小越快)");
    Serial.println("  pattern N 合成动画 0=彩条 1=弹跳方块 2=彩虹扫描");
    Serial.println("  w N       合成画面宽 (默认 96)");
    Serial.println("  h N       合成画面高 (默认 64)");
    Serial.println("  size X    摄像头分辨率 qqvga/qvga/vga (需摄像头)");
    Serial.println("  wifi      开/关热点");
    Serial.println("  web       只开网页热点 W16-WEB (不依赖射频/角色), 排查搜不到 SSID");
    Serial.println("  wtest     只起一个测试热点 W16-TEST(20s), 排查搜不到 SSID");
    Serial.println("  ch N      热点信道: 0=自动 ch1 / 1~11=强制 (12~13 会被拒)");
    Serial.println("  power N   热点功率 5/8/11/15/20 dBm (默认 15, 信号弱就调大)");
    Serial.println("  status    打印计数");
    Serial.println("  help      本列表");
    Serial.println();
    Serial.println("  用法: A 板 tx -> 手机连 W16-CAM  开 192.168.4.1 点开始推流");
    Serial.println("        B 板 rx -> 手机连 W16-LIVE 开 192.168.4.1 看画面");
    Serial.println("  两块板必须烧同一版固件 (包长 204 / 同步字 / 速率都要一致)");
    Serial.println();
    Serial.flush();     // Flush this batch before the next log line, otherwise bytes get interleaved and lost
}

void printStatus() {
    Serial.print("[STATUS] 模式=");
    Serial.print(gRole == ROLE_TX ? "TX" : (gRole == ROLE_RX ? "RX" : "IDLE"));
    Serial.print("  推流="); Serial.print(gStreaming ? "是" : "否");
    Serial.print("  帧号="); Serial.println((int)gFrameId);

    Serial.print("[STATUS] 画面 ");
    if (gRole == ROLE_TX) {
        Serial.print(txW ? txW : gVidW); Serial.print("x"); Serial.print(txH ? txH : gVidH);
        Serial.print("  "); Serial.print((int)txLastLen);
        Serial.print(" 字节  "); Serial.print((int)((txLastLen + VIDEO_CHUNK - 1) / VIDEO_CHUNK));
        Serial.print(" 块  "); Serial.println(txLastFmt == FMT_JPEG ? "JPEG" : "RGB332");
    } else {
        Serial.print(liveW); Serial.print("x"); Serial.print(liveH);
        Serial.print("  "); Serial.print((int)liveLen);
        Serial.print(" 字节  "); Serial.println(liveFmt == FMT_JPEG ? "JPEG" : "RGB332");
    }

    Serial.print("[STATUS] 发送: "); Serial.print((int)txFrames);
    Serial.print(" 帧 / "); Serial.print((int)txPkts);
    Serial.print(" 包 / "); Serial.print((int)(txBytes / 1024));
    Serial.print("KB  目标 "); Serial.print((int)gTargetFps);
    Serial.print("fps  间隔 "); Serial.print((int)gGapMs); Serial.println("ms");

    Serial.print("[STATUS] 接收: 显示 "); Serial.print((int)rxShown);
    Serial.print(" / 开始 "); Serial.print((int)rxStarted);
    Serial.print("  全齐 "); Serial.print((int)rxFrames);
    Serial.print("  缺块 "); Serial.print((int)rxMissChunks);
    Serial.print("  丢帧 "); Serial.print((int)rxDropped);
    Serial.print("  收包 "); Serial.print((int)rxPackets);
    Serial.print("  噪声 "); Serial.print((int)rxNoise);
    Serial.print("  其他 "); Serial.println((int)rxOtherErr);

    Serial.print("[STATUS] 样式 "); Serial.print((int)gPattern);
    Serial.print("  "); Serial.print(gVidW); Serial.print("x"); Serial.print(gVidH);
    Serial.print("  ");
    Serial.print(gWifiOn ? "热点开 http://" : "热点关");
    if (gWifiOn) {
        Serial.print(WiFi.softAPIP());
        Serial.print("  信道="); Serial.print((int)gApChannelNow);
        Serial.print("  功率="); Serial.print((int)gApPowerDbm); Serial.print("dBm");
        Serial.print("  已连="); Serial.print((int)WiFi.softAPgetStationNum()); Serial.print("台");
    }
    Serial.println();

    Serial.print("[STATUS] 空闲堆 "); Serial.print(ESP.getFreeHeap() / 1024);
    Serial.print("KB  PSRAM ");
    Serial.print(psramFound() ? (int)(ESP.getFreePsram() / 1024) : -1);
    Serial.println("KB");
    Serial.flush();
}

void handleCommand(char* s) {
    int n = (int)strlen(s);
    while (n > 0 && (s[n - 1] == ' ' || s[n - 1] == '\t')) s[--n] = 0;
    if (n == 0) return;

    // Echo the input line so it is visible that the board actually received the command
    Serial.print("> "); Serial.println(s);

    if (!strcmp(s, "help") || !strcmp(s, "?")) { printHelp(); return; }
    if (!strcmp(s, "tx"))   { switchRole(ROLE_TX); return; }
    if (!strcmp(s, "rx"))   { switchRole(ROLE_RX); return; }
    if (!strcmp(s, "idle") || !strcmp(s, "stop")) { switchRole(ROLE_IDLE); return; }
    if (!strcmp(s, "status")) { printStatus(); return; }

    if (!strcmp(s, "send")) {
        if (gRole != ROLE_TX) { Serial.println("[CMD] 先输入 tx 切到发送角色"); return; }
        gSendOne = true;
        Serial.println("[CMD] 只推一帧");
        return;
    }
    // Frame source: 0 = onboard (camera / animation), 1 = page push (camera or local video)
    if (!strncmp(s, "src ", 4)) {
        int v = atoi(s + 4);
        if (v != 0 && v != 1) { Serial.println("[CMD] src 0=板载合成  1=网页推帧"); return; }
        applyParam("src", v);
        printBoardStatus();
        return;
    }
    // AP self-test: does not touch the radio, just brings the AP up for 20 seconds.
    // Two-way triage: W16-TEST visible -> WiFi is fine; not visible -> antenna / power.
    if (!strcmp(s, "wtest")) {
        bool wasOn = gWifiOn;
        if (wasOn) stopWeb();
        Serial.println("[WTEST] 单独起热点 W16-TEST / 12345678, 20 秒后自动关");
        if (apStart("W16-TEST", 9)) {
            for (int i = 0; i < 20; i++) {
                Serial.print("[WTEST] 剩 "); Serial.print(20 - i);
                Serial.print("s  已连 "); Serial.print((int)WiFi.softAPgetStationNum());
                Serial.print(" 台  IP "); Serial.println(WiFi.softAPIP());
                delay(1000);
            }
            WiFi.softAPdisconnect(true);
            WiFi.mode(WIFI_OFF);
            delay(300);
            Serial.println("[WTEST] 结束");
        } else {
            Serial.println("[WTEST] AP 起不来 -> 换 USB 口 / 换粗线 / 检查天线");
        }
        if (wasOn) startWeb();
        return;
    }
    // Web-only AP: no radio dependency, ignores the role, SSID is always W16-WEB
    if (!strcmp(s, "web")) {
        if (gWifiOn) { stopWeb(); return; }
        gSsidOverride = "W16-WEB";
        Serial.println("[CMD] 纯网页热点 W16-WEB / 12345678 (与射频、角色都无关)");
        startWeb();
        return;
    }
    if (!strcmp(s, "wifi")) {
        if (gRole == ROLE_IDLE) { Serial.println("[CMD] 先输入 tx 或 rx"); return; }
        if (gWifiOn) stopWeb(); else startWeb();
        return;
    }
    if (!strncmp(s, "ch ", 3)) {
        int v = atoi(s + 3);
        // 12 and 13 are rejected by softAP() with the default country code (1~11), so the
        // accepted input range stops at 11 as well.
        if (v < 0 || v > 11) { Serial.println("[CMD] 信道 0~11 (0=自动 ch1)"); return; }
        gApChannel = (uint8_t)v;

        if (gApChannel == 0) {
            Serial.println("[CMD] 信道 -> 自动 ch1 (离 2450MHz 最远)");
        } else {
            Serial.print("[CMD] 信道 -> "); Serial.print((int)gApChannel);
            Serial.println(", 正在重开热点… (已记住, 重启不丢)");
        }
        // Store the channel in NVS so a tuned value survives a reboot
        prefs.begin("w16", false);
        prefs.putUChar("ch", gApChannel);
        prefs.end();

        // No scanning any more, reopening takes ~0.7s and applies immediately
        if (gRole != ROLE_IDLE) {
            if (gWifiOn) stopWeb();
            startWeb();
        }
        return;
    }
    if (!strncmp(s, "power ", 6)) {
        int v = atoi(s + 6);
        if (v < 2 || v > 20) { Serial.println("[CMD] 功率 2~20 dBm (建议 5/8/11/15/20)"); return; }
        gApPowerDbm = (uint8_t)v;
        Serial.print("[CMD] 功率 -> "); Serial.print((int)gApPowerDbm);
        Serial.println("dBm, 正在重开热点… (已记住, 重启不丢)");
        prefs.begin("w16", false);
        prefs.putUChar("pw", gApPowerDbm);
        prefs.end();

        if (gRole != ROLE_IDLE) {
            if (gWifiOn) stopWeb();
            startWeb();
        }
        return;
    }

    // Commands with arguments go through applyParam, the same validation as the web /set
    static const struct { const char* key; uint8_t len; } PARAMS[] = {
        { "fps", 3 }, { "gap", 3 }, { "pattern", 7 }, { "w", 1 }, { "h", 1 },
    };
    for (unsigned i = 0; i < sizeof(PARAMS) / sizeof(PARAMS[0]); i++) {
        uint8_t L = PARAMS[i].len;
        if (n > L && s[L] == ' ' && !strncmp(s, PARAMS[i].key, L)) {
            applyParam(PARAMS[i].key, atol(s + L + 1));
            return;
        }
    }

    if (!strncmp(s, "size ", 5)) {
#if (USE_CAMERA && CAM_LIB_OK)
        if (!gCamOk) { Serial.println("[CMD] 摄像头未就绪"); return; }
        sensor_t* sn = esp_camera_sensor_get();
        if (!sn) return;
        const char* v = s + 5;
        framesize_t fs = FRAMESIZE_QQVGA;
        if      (!strcmp(v, "qqvga")) fs = FRAMESIZE_QQVGA;
        else if (!strcmp(v, "qvga"))  fs = FRAMESIZE_QVGA;
        else if (!strcmp(v, "vga"))   fs = FRAMESIZE_VGA;
        else { Serial.println("[CMD] 可选 qqvga/qvga/vga"); return; }
        sn->set_framesize(sn, fs);
        Serial.print("[CMD] 分辨率 -> "); Serial.println(v);
#else
        Serial.println("[CMD] 当前是合成动画模式, 无分辨率可设 (用 w/h 调尺寸)");
#endif
        return;
    }

    Serial.print("[CMD] 未知指令: "); Serial.println(s);
    Serial.println("       输入 help 看列表");
}

void pollSerial() {
    static char line[40];
    static uint8_t n = 0;
    while (Serial.available()) {
        char c = (char)Serial.read();
        if (c == '\r') continue;
        if (c == '\n') {
            line[n] = 0;
            if (n) handleCommand(line);
            n = 0;
        } else if (n < sizeof(line) - 1) {
            line[n++] = (char)tolower((int)c);
        }
    }
}

// ==================== Main loop ====================
void loop() {
    pollSerial();

    // Button: board A toggles streaming (still responsive while streaming, streamVideo polls serial)
    static bool pttPrev = true;
    bool ptt = (digitalRead(PIN_PTT) == LOW);
    if (ptt && !pttPrev) {
        if (gRole == ROLE_TX) {
            if (gStreaming) {
                gStreaming = false;
                Serial.println("[KEY] 停止推流");
            } else {
                gStreaming = true;
                Serial.println("[KEY] 开始推流");
            }
        }
    }
    pttPrev = ptt;

    if (gRole == ROLE_RX) {
        // Never stay deaf. enterRx() retries internally, but if all four attempts were rejected
        // the receiver has to keep trying instead of sitting there for the whole session - that
        // is exactly what a single -707 at boot used to cause.
        static uint32_t lastArmMs = 0, lastPkts = 0, lastChkMs = 0;
        uint32_t nowMs = millis();
        if (!gRxArmed && nowMs - lastArmMs >= 400) {
            lastArmMs = nowMs;
            if (enterRx()) Serial.println("[RF] 接收已恢复, 继续监听");
        } else if (nowMs - lastChkMs >= 3000) {
            // Three seconds of silence also re-arms. If the chip quietly dropped out of RX
            // (a command rejected mid-stream), nothing else would ever bring it back.
            lastChkMs = nowMs;
            if (rxPackets == lastPkts) {
                lastArmMs = nowMs;
                enterRx();
            }
            lastPkts = rxPackets;
        }

        // Drain every packet from the air first, serve the page second - the other order drops
        // packets: one 6KB /frame transfer holds WiFi/SPI for tens of ms, which at 4ms per packet
        // throws away 3~5 chunks. That is exactly why the complete-frame rate stayed low.
        VideoPacket p;
        for (int i = 0; i < 8; i++) {
            if (!rxPoll(&p)) break;
            handleRxPacket(p);
        }

        // Serve the page only between frames: rxCurTotal==0 means the last frame ended and the next
        // has not started. Board A pauses between frames while it waits for the phone, and that gap
        // is enough for one picture. If A streams back to back (fps=0), force a service every 500ms.
        static uint32_t lastWebMs = 0;
        if (gWifiOn) {
            if (rxCurTotal == 0 || millis() - lastWebMs > 500) {
                webServer.handleClient();
                lastWebMs = millis();
            }
        }
        rxStatsTick();
        return;
    }

    if (gRole == ROLE_TX) {
        if (gWifiOn) webServer.handleClient();

        // A file page waiting to go out. It is transmitted before anything else: the page that
        // posted it is blocking on /fstatus, and a live frame would only delay it.
        if (gFilePageReady) {
            gFilePageReady = false;
            uint16_t seq = filePageSeq;
            uint16_t len = filePageLen;

            // A page with a hole is worthless, so retry it a couple of times before giving up.
            // Every retry is a fresh 8-round ACK pass over just the chunks board B is missing.
            filePageBusy = true;
            bool ok = false;
            for (int attempt = 0; attempt < 3 && !ok; attempt++) {
                if (attempt) {
                    Serial.print("[FILE] 第 "); Serial.print((int)(seq + 1));
                    Serial.print(" 页重试 "); Serial.print(attempt); Serial.println("/2");
                }
                ok = fileSendPage(seq, fileBuf, len);
            }
            filePageBusy = false;

            if (ok) {
                filePageDone = (uint16_t)(seq + 1);
                // Board B writes the page to flash before it ACKs, so by now it is already idle.
                // Only a short turnaround is needed; the long wait would just slow the transfer.
                delay(20);
                // Print every page, not just the first two and every tenth. When a transfer fails
                // it is the page sequence that says whether A skipped one or B dropped one.
                Serial.print("[FILE] 页 ");
                Serial.print((int)(seq + 1));
                Serial.print("/");
                Serial.print((int)filePages);
                Serial.println(" 已发");
            } else {
                fileState = 3;
                snprintf(fileErr, sizeof(fileErr), "第 %u 页重传失败", (unsigned)(seq + 1));
                Serial.print("[FILE] 发送失败: "); Serial.println(fileErr);
            }
            ledBlue();
            return;
        }

        if (gSendOne) {
            gSendOne = false;
            sendOneFrame();
            ledBlue();
            return;
        }

        if (gStreaming) {
            streamVideo();          // Stream continuously until idle / page stop / button
            return;
        }

        // Idle standby: board A does not listen (radio in standby), only waits for commands
        delay(5);
        return;
    }

    delay(5);   // IDLE
}

// ==================== setup ====================
void setup() {
    // ---- USB-CDC serial hardening (important) ----
    // CDCOnBoot=Enabled, so Serial is USB-CDC (HWCDC) with a 256-byte TX ring by default.
    // Printing help (~900 bytes) at once overflows it and bytes are dropped: UTF-8 gets cut in
    // half, lines vanish, blank lines appear. The buffer must be enlarged, and setTxBufferSize()
    // only works before begin() (begin() allocates the ring).
#if defined(ARDUINO_USB_CDC_ON_BOOT) && ARDUINO_USB_CDC_ON_BOOT
    Serial.setTxBufferSize(4096);
#endif
    Serial.begin(115200);
#if defined(ARDUINO_USB_CDC_ON_BOOT) && ARDUINO_USB_CDC_ON_BOOT
    Serial.setTxTimeoutMs(100);        // Wait for the host instead of dropping bytes when the ring is full
    unsigned long tWait = millis();
    while (!Serial && millis() - tWait < 2000) delay(10);   // wait for the serial monitor
#endif
    delay(200);

    pinMode(PIN_PTT, INPUT_PULLUP);
    ledOff();

    Serial.println();
    Serial.println("=== W16 (LR2021) Video over FLRC + Web ===");

    // Reset reason: if the AP vanishes or the stream stalls because the board rebooted, this
    // tells brownout / panic / watchdog apart without guessing.
    {
        const char* why = "其他";
        esp_reset_reason_t rr = esp_reset_reason();
        switch (rr) {
            case ESP_RST_POWERON:   why = "上电"; break;
            case ESP_RST_SW:        why = "软件复位(烧录后正常)"; break;
            case ESP_RST_PANIC:     why = "程序崩溃(panic)! 上次跑挂了"; break;
            case ESP_RST_INT_WDT:   why = "中断看门狗复位!"; break;
            case ESP_RST_TASK_WDT:  why = "任务看门狗复位!"; break;
            case ESP_RST_WDT:       why = "看门狗复位!"; break;
            case ESP_RST_BROWNOUT:  why = "欠压复位! 供电不足实锤, 换粗线/换USB口/独立供电"; break;
            case ESP_RST_DEEPSLEEP: why = "深度睡眠唤醒"; break;
            default: break;
        }
        Serial.print("[INIT] 复位原因: "); Serial.println(why);
    }

    // AP station join/leave events with MAC, to see who actually connected
    WiFi.onEvent([](WiFiEvent_t event, WiFiEventInfo_t info) {
        const uint8_t* m = info.wifi_ap_staconnected.mac;
        char buf[18];
        snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X",
                 m[0], m[1], m[2], m[3], m[4], m[5]);
        Serial.print("[WEB] 手机已连上热点 ✓ MAC="); Serial.println(buf);
    }, ARDUINO_EVENT_WIFI_AP_STACONNECTED);
    WiFi.onEvent([](WiFiEvent_t event, WiFiEventInfo_t info) {
        const uint8_t* m = info.wifi_ap_stadisconnected.mac;
        char buf[18];
        snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X",
                 m[0], m[1], m[2], m[3], m[4], m[5]);
        Serial.print("[WEB] 手机从热点断开 ✗ MAC="); Serial.println(buf);
    }, ARDUINO_EVENT_WIFI_AP_STADISCONNECTED);

    Serial.print("[CFG] 单包 "); Serial.print((unsigned int)sizeof(VideoPacket));
    Serial.print(" 字节 (头 12 + 数据 "); Serial.print(VIDEO_CHUNK);
    Serial.println(")");
    Serial.print("[CFG] 最多 "); Serial.print(VIDEO_MAX_CHUNKS);
    Serial.print(" 块, 单帧上限 "); Serial.print(VIDEO_BUF_CAP);
    Serial.println(" 字节");

    // Four buffers: txBuf / rxBuf / liveBuf / upBuf, 12288 bytes each, 48KB total.
    // upBuf receives frames pushed by the page (phone camera / local video).
    txBuf = (uint8_t*)ps_malloc(VIDEO_BUF_CAP);
    if (!txBuf) txBuf = (uint8_t*)malloc(VIDEO_BUF_CAP);
    rxBuf = (uint8_t*)ps_malloc(VIDEO_BUF_CAP);
    if (!rxBuf) rxBuf = (uint8_t*)malloc(VIDEO_BUF_CAP);
    liveBuf = (uint8_t*)ps_malloc(VIDEO_BUF_CAP);
    if (!liveBuf) liveBuf = (uint8_t*)malloc(VIDEO_BUF_CAP);
    upBuf = (uint8_t*)ps_malloc(VIDEO_BUF_CAP);
    if (!upBuf) upBuf = (uint8_t*)malloc(VIDEO_BUF_CAP);
    // File transfer needs one page buffer per role: A holds the page the phone just posted,
    // B holds the page being assembled before it is written to flash. Only one role runs.
    fileBuf = (uint8_t*)ps_malloc(FILE_PAGE_BYTES);
    if (!fileBuf) fileBuf = (uint8_t*)malloc(FILE_PAGE_BYTES);
    fileRxBuf = (uint8_t*)ps_malloc(FILE_PAGE_BYTES);
    if (!fileRxBuf) fileRxBuf = (uint8_t*)malloc(FILE_PAGE_BYTES);

    if (!txBuf || !rxBuf || !liveBuf || !upBuf) {
        Serial.println("[INIT] 画面缓冲分配失败, 视频功能不可用");
    } else {
        Serial.print("[INIT] 画面缓冲 4 x "); Serial.print(VIDEO_BUF_CAP);
        Serial.print(" = "); Serial.print(VIDEO_BUF_CAP * 4);
        Serial.print(" 字节 @ ");
        Serial.println(psramFound() ? "PSRAM" : "内部 RAM");
    }
    if (!fileBuf || !fileRxBuf) Serial.println("[INIT] 文件传输缓冲分配失败, 文件传输不可用");

    initCamera();

    // !! This line cannot be omitted !!
    // RadioLib Module::init() only calls the parameterless SPI.begin(), and the ESP32-S3
    // defaults are SCK=12 / MISO=13 / MOSI=11 / SS=10 while this board is
    // SCK=12 / MISO=11 / MOSI=10 - MISO and MOSI are swapped. The chip then answers
    // intermittently: beginFLRC() returns -707 (CMD_FAIL) and startReceive() flips between
    // -707 and -2 (CHIP_NOT_FOUND). Create the bus here with the real pins first; mod->init()
    // then reuses it.
    SPI.begin(PIN_SCK, PIN_MISO, PIN_MOSI);

    if (!beginRadio()) {
        gRadioOk = false;
        Serial.println("[INIT] 射频初始化失败, 请检查接线");
        Serial.println("[INIT] 引脚: SCK=12 MISO=11 MOSI=10 NSS=47 RST=39 BUSY=21 DIO7=42");
        Serial.println("[INIT] 注意: 射频失败不影响热点! 输 tx/rx 或 web 照样能开 WiFi");
        Serial.println("[INIT]       只是画面传不出去, 网页预览/调参都正常");
    } else {
        gRadioOk = true;
    }

    // ==================== Boot into IDLE ====================
    // This used to restore tx/rx from NVS, open the AP and enter the RX loop, so with no
    // command typed the log already flooded [STAT] RX and the board looked like it ran itself.
    // Now boot only initializes: radio in standby, AP off, waiting for tx / rx.
    // Only ch / power are read back from NVS, so tuned values survive a reboot.
    gRole = ROLE_IDLE;
    gStreaming = false;
    if (gRadioOk) radio.standby();

    prefs.begin("w16", true);
    gApChannel  = prefs.getUChar("ch",  gApChannel);   // default 0 = automatic when unset
    // A channel saved by an older build (12/13) makes softAP() fail three times and leaves the
    // board without any AP, so drop it back to automatic instead of honouring it.
    if (gApChannel > 11) gApChannel = 0;
    gApPowerDbm = prefs.getUChar("pw",  gApPowerDbm);  // keep default 15 when unset
    prefs.end();
    if (gApPowerDbm < 2 || gApPowerDbm > 20) gApPowerDbm = 15;   // guard against bad data

    Serial.println("[INIT] 上电默认 IDLE —— 等你输指令, 不会自己收发");
    Serial.print("[INIT]   热点信道 "); Serial.print(gApChannel ? String((int)gApChannel)
                                                                : String("自动 ch1"));
    Serial.print("  功率 "); Serial.print((int)gApPowerDbm); Serial.println("dBm");
    Serial.println("[INIT]   输 tx -> 热点 W16-CAM  推流 (A 板)");
    Serial.println("[INIT]   输 rx -> 热点 W16-LIVE 收画面 (B 板)");
    Serial.println("[INIT]   输 status -> 看板子状态;  输 idle -> 停收发");
    printHelp();
}
