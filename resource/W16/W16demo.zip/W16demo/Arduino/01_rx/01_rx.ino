#include <RadioLib.h>

#if defined(RADIOLIB_VERSION_MAJOR) && (RADIOLIB_VERSION_MAJOR >= 8)
  #define RL8 1
#else
  #define RL8 0
#endif

#define PIN_SCK    12
#define PIN_MISO   11
#define PIN_MOSI   10
#define PIN_NSS    47
#define PIN_DIO7   42    // Chip DIO7 -> MCU GPIO42
#define PIN_NRESET 39
#define PIN_BUSY   21

#define PIN_LED    48    // WS2812 RGB LED

struct BandConfig {
    const char* name;
    float freq;           // MHz
    float bw;             // kHz
    float sf;             // Spreading factor
    uint8_t cr;           // Coding rate
    int8_t power;         // dBm (for display only)
};

BandConfig bands[] = {
    {"Sub-G", 868.0,  125.0, 12, 5, 22},
    {"Sub-G", 915.0,  125.0, 12, 5, 22},
    {"2.4G",  2450.0, 250.0, 12, 5, 12},
};
const int NUM_BANDS = sizeof(bands) / sizeof(bands[0]);

#if RL8
static void buildLoRaCfg(int bandIdx, int8_t power, ConfigLoRa_t& c) {
    c.frequency       = (uint32_t)(bands[bandIdx].freq * 1000000.0f);   // Hz
    c.bandwidth       = (uint32_t)(bands[bandIdx].bw   * 1000.0f);      // Hz
    c.spreadingFactor = (uint8_t)bands[bandIdx].sf;
    c.codingRate      = bands[bandIdx].cr;
    c.syncWord        = RADIOLIB_LR2021_LORA_SYNC_WORD_PRIVATE;
    c.power           = power;
    c.preambleLength  = 8;
}
#endif

Module mod(PIN_NSS, PIN_DIO7, PIN_NRESET, PIN_BUSY);
LR2021 radio(&mod);

#include <esp32-hal-rgb-led.h>

void ledGreen()  { neopixelWrite(PIN_LED, 0, 8, 0); }
void ledRed()    { neopixelWrite(PIN_LED, 8, 0, 0); }
void ledBlue()   { neopixelWrite(PIN_LED, 0, 0, 8); }
void ledOff()    { neopixelWrite(PIN_LED, 0, 0, 0); }

void blinkGreen(int times, int onMs, int offMs) {
    for (int i = 0; i < times; i++) {
        ledGreen();
        delay(onMs);
        ledOff();
        if (i < times - 1) delay(offMs);
    }
}

void blinkRed(int times, int onMs, int offMs) {
    for (int i = 0; i < times; i++) {
        ledRed();
        delay(onMs);
        ledOff();
        if (i < times - 1) delay(offMs);
    }
}

int currentBand = 1;          // default 915MHz Sub-G, switchable via serial command
unsigned int rxCount = 0;
int errorCount = 0;
bool rxActive = false;        // false = idle (standby), true = listening

void configureRadio(int bandIdx) {
    BandConfig* cfg = &bands[bandIdx];
#if RL8
    radio.setFrequency((uint32_t)(cfg->freq * 1000000.0f));
    radio.setBandwidth((uint32_t)(cfg->bw   * 1000.0f));
#else
    radio.setFrequency(cfg->freq);
    radio.setBandwidth(cfg->bw);
#endif
    radio.setSpreadingFactor((uint8_t)cfg->sf);
    radio.setCodingRate(cfg->cr);
}

int16_t beginRadio(int8_t power) {
    radio.irqDioNum = 7;
#if RL8
    radio.tcxoVoltage = Voltage1V8;
    ConfigLoRa_t cfg;
    buildLoRaCfg(currentBand, power, cfg);
    return radio.begin(cfg);
#else
    return radio.begin(bands[currentBand].freq, bands[currentBand].bw,
                       bands[currentBand].sf, bands[currentBand].cr,
                       RADIOLIB_LR2021_LORA_SYNC_WORD_PRIVATE,
                       power, 8, 1.8);
#endif
}

int16_t startRxOnBand(int bandIdx) {
    configureRadio(bandIdx);
    static const uint16_t waits[] = {2, 12, 22, 32};
    int16_t state = RADIOLIB_ERR_UNKNOWN;
    for (int i = 0; i < 4; i++) {
        radio.standby();
        delay(waits[i]);
        state = radio.startReceive();
        if (state == RADIOLIB_ERR_NONE) break;
    }
    rxActive = (state == RADIOLIB_ERR_NONE);
    return state;
}

bool rxDone() {
    if (!rxActive) return false;
    return (radio.getIrqFlags() & RADIOLIB_LR2021_IRQ_RX_DONE) != 0;
}

int16_t fullReinit() {
    int16_t state = beginRadio(0);
    if (state == RADIOLIB_ERR_SPI_CMD_INVALID && bands[currentBand].freq > 1500.0f) {
        state = RADIOLIB_ERR_NONE;
    }
    if (state == RADIOLIB_ERR_NONE) {
        state = startRxOnBand(currentBand);
    }
    return state;
}

void printBandCfg(int idx) {
    Serial.print(bands[idx].name);
    Serial.print(" ");
    Serial.print(bands[idx].freq, 0);
    Serial.print("MHz BW");
    Serial.print(bands[idx].bw, 0);
    Serial.print(" SF");
    Serial.print((int)bands[idx].sf);
    Serial.print(" CR4/");
    Serial.print((int)bands[idx].cr);
    Serial.print(" ");
    Serial.print((int)bands[idx].power);
    Serial.print("dBm");
}

void printNow() { printBandCfg(currentBand); }

void printBandInfo(int idx) {
    Serial.print("  ");
    Serial.print(idx + 1);
    Serial.print("  ");
    printBandCfg(idx);
    Serial.println();
}

void printHelp() {
    Serial.println("Commands (type and press Enter):");
    Serial.println("  868      switch to Sub-G 868MHz and START listening");
    Serial.println("  915      switch to Sub-G 915MHz and START listening");
    Serial.println("  2.4G     switch to 2.4GHz 2450MHz and START listening  (also: 2400)");
    Serial.println("  rx       resume listening on the current band (after idle)");
    Serial.println("  idle     stop listening, radio back to standby");
    Serial.println("  help     show this list");
}

void startRx();          // defined below; declared here so bandAndRx() does not rely on the auto-prototype

void bandAndRx(int idx) {
    if (idx < 0 || idx >= NUM_BANDS) return;

    if (idx == currentBand && rxActive) {
        Serial.print("[RX] 已在 ");
        printNow();
        Serial.println("  接收中, 参数未变");
        return;
    }

    int  previous = currentBand;
    bool wasActive = rxActive;
    currentBand = idx;
    rxCount = 0;
    errorCount = 0;

    startRx();

    if (!rxActive && wasActive && previous != idx) {
        Serial.println("[RX] 新频段启动失败, 回退到原频段");
        currentBand = previous;
        startRx();
    }
}

void startRx() {
    radio.standby();
    delay(50);

    int16_t state = startRxOnBand(currentBand);
    if (state != RADIOLIB_ERR_NONE) {
        Serial.print("[RX] startReceive FAIL - err="); Serial.println(state);
        state = fullReinit();
    }
    if (state != RADIOLIB_ERR_NONE) {
        Serial.print("[RX] start FAIL - err="); Serial.println(state);
        rxActive = false;
        ledOff();
        blinkRed(3, 100, 100);
        return;
    }

    rxCount = 0;
    errorCount = 0;
    Serial.print("[RX] 开始接收  ");
    printNow();
    Serial.println();
    blinkGreen(2, 200, 200);
    ledBlue();
}

void stopRx() {
    if (rxActive) radio.finishReceive();
    else radio.standby();
    rxActive = false;
    Serial.println("[MODE] IDLE (standby) - radio is NOT listening");
    ledOff();
}

String cmdBuf;

void handleCommand(String raw) {
    raw.trim();
    raw.toLowerCase();
    if (raw.length() == 0) return;

    if (raw == "help" || raw == "?") {
        printHelp();
    } else if (raw == "rx" || raw == "start") {
        startRx();
    } else if (raw == "idle" || raw == "stop") {
        stopRx();
    } else if (raw == "868") {
        bandAndRx(0);
    } else if (raw == "915") {
        bandAndRx(1);
    } else if (raw == "2.4g" || raw == "2400" || raw == "2450" || raw == "2.4") {
        bandAndRx(2);
    } else {
        Serial.print("[CMD] unknown command: ");
        Serial.println(raw);
        Serial.println("      valid: 868 / 915 / 2.4G (switch+RX) / rx / idle / help");
    }
}

void pollSerial() {
    while (Serial.available() > 0) {
        char c = Serial.read();
        if (c == '\r' || c == '\n') {
            if (cmdBuf.length() > 0) {
                handleCommand(cmdBuf);
                cmdBuf = "";
            }
        } else if (c >= 32 && c <= 126) {
            if (cmdBuf.length() < 16) cmdBuf += c;
        }
    }
}

void setup() {
    Serial.begin(115200);
    delay(3000);  // ESP32-S3 原生 USB CDC: 等串口监视器枚举/连接, 避免开机日志丢失

    Serial.println("\n=== LR2021 RX Test ===");
    for (int i = 0; i < NUM_BANDS; i++) printBandInfo(i);
    Serial.println();

    SPI.begin(PIN_SCK, PIN_MISO, PIN_MOSI);

    int state = beginRadio(0);

    if (state != RADIOLIB_ERR_NONE) {
        Serial.print("[INIT] FAIL - begin() err="); Serial.println(state);
        blinkRed(10, 100, 100);
        while (true) delay(10);
    }
    Serial.println("[INIT] PASS - Module initialized");
    Serial.println();

    radio.standby();
    rxActive = false;

    Serial.println("[MODE] IDLE (standby) - radio is NOT listening");
    Serial.print("[CFG]  preset band = ");
    printNow();
    Serial.println("   (not active yet)");
    Serial.println("[MODE] type 868 / 915 / 2.4G to START listening on that band");
    Serial.println("[MODE] \"rx\" resumes the current band after \"idle\"");
    Serial.println();

    printHelp();
    Serial.println();

    ledOff();
}

void loop() {
    pollSerial();

    if (!rxActive) {
        delay(10);
        return;
    }

    if (rxDone()) {
        String received;
        int state = radio.readData(received);

        if (state == RADIOLIB_ERR_NONE) {
            rxCount++;
            float rssi = radio.getRSSI();
            float snr  = radio.getSNR();

            Serial.print(rxCount);
            Serial.print("  ");
            printNow();
            Serial.print("  RSSI="); Serial.print(rssi, 1);
            Serial.print(" SNR=");  Serial.print(snr, 1);
            Serial.println();

            blinkGreen(1, 200, 0);
        } else {
            errorCount++;
            Serial.print("N/A  ");
            printNow();
            Serial.print("  ReadData FAIL - err="); Serial.println(state);

            blinkRed(3, 100, 100);
        }

        radio.standby();
        delay(50);
        state = startRxOnBand(currentBand);
        if (state != RADIOLIB_ERR_NONE) {
            fullReinit();
        }
    }

    delay(10);
}
