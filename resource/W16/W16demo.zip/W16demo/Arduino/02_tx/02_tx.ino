#include <RadioLib.h>

#if defined(RADIOLIB_VERSION_MAJOR) && (RADIOLIB_VERSION_MAJOR >= 8)
  #define RL8 1
#else
  #define RL8 0
#endif

#define PIN_SCK     12
#define PIN_MISO    11
#define PIN_MOSI    10
#define PIN_NSS     47
#define PIN_DIO7    42
#define PIN_NRESET  39
#define PIN_BUSY    21
#define PIN_LED     48    // WS2812 RGB LED

struct BandConfig {
    const char* name;
    float freq;           // MHz
    float bw;             // kHz
    uint8_t sf;           // Spreading factor
    uint8_t cr;           // Coding rate
    int8_t power;         // dBm (Sub-G max 22, 2.4G max 12)
};

BandConfig bands[] = {
    {"Sub-G", 868.0,  125.0, 12, 5, 22},
    {"Sub-G", 915.0,  125.0, 12, 5, 22},
    {"2.4G",  2450.0, 250.0, 12, 5, 12},
};
const int NUM_BANDS = sizeof(bands) / sizeof(bands[0]);

int currentBand = 1;      // default 915MHz Sub-G
int8_t activePower = 10;  // what the PA actually accepted for the current band (see applyBand)

#if RL8
static void buildLoRaCfg(int bandIdx, int8_t power, ConfigLoRa_t& c) {
    c.frequency       = (uint32_t)(bands[bandIdx].freq * 1000000.0f);   // Hz
    c.bandwidth       = (uint32_t)(bands[bandIdx].bw   * 1000.0f);      // Hz
    c.spreadingFactor = bands[bandIdx].sf;
    c.codingRate      = bands[bandIdx].cr;
    c.syncWord        = RADIOLIB_LR2021_LORA_SYNC_WORD_PRIVATE;
    c.power           = power;
    c.preambleLength  = 8;
}
#endif

Module mod(PIN_NSS, PIN_DIO7, PIN_NRESET, PIN_BUSY);
LR2021 radio(&mod);

volatile bool txFlag = false;

#include <esp32-hal-rgb-led.h>

void ledGreen()  { neopixelWrite(PIN_LED, 0, 8, 0); }
void ledRed()    { neopixelWrite(PIN_LED, 8, 0, 0); }
void ledBlue()   { neopixelWrite(PIN_LED, 0, 0, 8); }
void ledOff()    { neopixelWrite(PIN_LED, 0, 0, 0); }

void blinkRed(int times, int onMs, int offMs) {
    for (int i = 0; i < times; i++) {
        ledRed(); delay(onMs);
        ledOff(); if (i < times - 1) delay(offMs);
    }
}

void blinkGreen(int times, int onMs, int offMs) {
    for (int i = 0; i < times; i++) {
        ledGreen(); delay(onMs);
        ledOff(); if (i < times - 1) delay(offMs);
    }
}

unsigned int seqNum = 0;
bool txActive = false;    // false = idle (standby), true = transmitting

void printBandCfg(int idx, int8_t power) {
    Serial.print(bands[idx].name);
    Serial.print(" ");
    Serial.print(bands[idx].freq, 0);
    Serial.print("MHz BW");
    Serial.print(bands[idx].bw, 0);
    Serial.print(" SF");
    Serial.print((int)bands[idx].sf);
    Serial.print(" CR4/");
    Serial.print((int)bands[idx].cr);
    Serial.print(" ");
    Serial.print((int)power);
    Serial.print("dBm");
}

void printNow() { printBandCfg(currentBand, activePower); }

void printPktLine(const char* tail) {
    Serial.print(seqNum);
    Serial.print("  ");
    printNow();
    if (tail && *tail) { Serial.print("  "); Serial.print(tail); }
    Serial.println();
}

void printBandInfo(int idx) {
    Serial.print("  ");
    Serial.print(idx + 1);
    Serial.print("  ");
    printBandCfg(idx, bands[idx].power);
    Serial.println();
}

void printHelp() {
    Serial.println("Commands (type and press Enter):");
    Serial.println("  868      switch to Sub-G 868MHz and START transmitting");
    Serial.println("  915      switch to Sub-G 915MHz and START transmitting");
    Serial.println("  2.4G     switch to 2.4GHz 2450MHz and START transmitting  (also: 2400)");
    Serial.println("  tx       resume transmitting on the current band (after idle)");
    Serial.println("  idle     stop transmitting, radio back to standby");
    Serial.println("  help     show this list");
}

bool setPowerOrAccept(int idx, int8_t want, int8_t* actual) {
    bool    hf    = (bands[idx].freq > 1500.0f);   // 2.4GHz path (same cutoff RadioLib uses)
    int16_t state = radio.setOutputPower(want);

    if (state == RADIOLIB_ERR_SPI_CMD_INVALID && hf) {
        *actual = want;
        return true;
    }

    int8_t got = want;
    while (state != RADIOLIB_ERR_NONE && got > -9) {
        got--;
        state = radio.setOutputPower(got);
        if (state == RADIOLIB_ERR_SPI_CMD_INVALID && hf) {
            *actual = got;
            return true;
        }
    }
    if (state != RADIOLIB_ERR_NONE) {
        Serial.print("[TX] setOutputPower FAIL - err="); Serial.println(state);
        return false;
    }
    if (got != want) {
        Serial.print("[TX] 该频段 PA 不接受 "); Serial.print((int)want);
        Serial.print("dBm, 已降到 "); Serial.print((int)got); Serial.println("dBm");
    }
    *actual = got;
    return true;
}

bool applyBand(int idx) {
    if (idx < 0 || idx >= NUM_BANDS) return false;

#if RL8
    int16_t state = radio.setFrequency((uint32_t)(bands[idx].freq * 1000000.0f));
#else
    int16_t state = radio.setFrequency(bands[idx].freq);
#endif
    if (state != RADIOLIB_ERR_NONE) {
        Serial.print("[TX] setFrequency FAIL - err="); Serial.println(state);
        return false;
    }
#if RL8
    state = radio.setBandwidth((uint32_t)(bands[idx].bw * 1000.0f));
#else
    state = radio.setBandwidth(bands[idx].bw);
#endif
    if (state != RADIOLIB_ERR_NONE) {
        Serial.print("[TX] setBandwidth FAIL - err="); Serial.println(state);
        return false;
    }
    state = radio.setSpreadingFactor(bands[idx].sf);
    if (state != RADIOLIB_ERR_NONE) {
        Serial.print("[TX] setSpreadingFactor FAIL - err="); Serial.println(state);
        return false;
    }
    state = radio.setCodingRate(bands[idx].cr);
    if (state != RADIOLIB_ERR_NONE) {
        Serial.print("[TX] setCodingRate FAIL - err="); Serial.println(state);
        return false;
    }
    radio.standby();
    delay(50);

    int8_t got = 0;
    if (!setPowerOrAccept(idx, bands[idx].power, &got)) return false;
    activePower = got;

    currentBand = idx;
    return true;
}

void startTx();          // defined below; declared here so bandAndTx() does not rely on the auto-prototype

void bandAndTx(int idx) {
    if (idx == currentBand) {
        if (txActive) {
            Serial.print("[TX] 已在 ");
            printNow();
            Serial.println("  发射中, 参数未变");
            return;
        }
    } else {
        if (!applyBand(idx)) {
            Serial.println("[TX] band switch FAILED, keep current config");
            blinkRed(3, 100, 100);
            if (txActive) ledBlue();
            return;
        }
    }
    startTx();
}

void startTx() {
    radio.standby();
    delay(50);

    int8_t applied = activePower;
    if (!setPowerOrAccept(currentBand, activePower, &applied)) {
        blinkRed(3, 100, 100);
        ledOff();
        return;
    }
    activePower = applied;

    txActive = true;
    seqNum = 0;
    Serial.print("[TX] 开始发射  ");
    printNow();
    Serial.println();
    blinkGreen(2, 200, 200);
    ledBlue();
}

void printPktFail(int16_t err) {
    Serial.print(seqNum);
    Serial.print("  ");
    printNow();
    Serial.print("  FAIL - err="); Serial.println(err);
}

void stopTx() {
    radio.standby();
    txActive = false;
    txFlag = false;
    Serial.println("[MODE] IDLE (standby) - radio is NOT transmitting");
    ledOff();
}

String cmdBuf;

void handleCommand(String raw) {
    raw.trim();
    raw.toLowerCase();
    if (raw.length() == 0) return;

    if (raw == "help" || raw == "?") {
        printHelp();
    } else if (raw == "tx" || raw == "start") {
        startTx();
    } else if (raw == "idle" || raw == "stop") {
        stopTx();
    } else if (raw == "868") {
        bandAndTx(0);
    } else if (raw == "915") {
        bandAndTx(1);
    } else if (raw == "2.4g" || raw == "2400" || raw == "2450" || raw == "2.4") {
        bandAndTx(2);
    } else {
        Serial.print("[CMD] unknown command: ");
        Serial.println(raw);
        Serial.println("      valid: 868 / 915 / 2.4G (switch+TX) / tx / idle / help");
    }
}

void pollSerial() {
    while (Serial.available() > 0) {
        char c = Serial.read();
        if (c == '\r' || c == '\n') {
            if (cmdBuf.length() > 0) {
                handleCommand(cmdBuf);
                cmdBuf = "";
            }
        } else if (c >= 32 && c <= 126) {
            if (cmdBuf.length() < 16) cmdBuf += c;
        }
    }
}

// Non-blocking idle: keeps listening to serial while waiting between packets
void idleWait(unsigned long ms) {
    unsigned long start = millis();
    while (millis() - start < ms) {
        pollSerial();
        delay(10);
    }
}

void setup() {
    Serial.begin(115200);
    delay(3000);  // ESP32-S3 原生 USB CDC: 等串口监视器枚举/连接, 避免开机日志丢失

    Serial.println("\n=== LR2021 TX Test ===");
    for (int i = 0; i < NUM_BANDS; i++) printBandInfo(i);
    Serial.println();

    SPI.begin(PIN_SCK, PIN_MISO, PIN_MOSI);

    radio.irqDioNum = 7;

    Serial.print("[INIT] Radio...");
#if RL8
    radio.tcxoVoltage = Voltage1V8;
    ConfigLoRa_t cfg;
    buildLoRaCfg(currentBand, 10, cfg);
    int state = radio.begin(cfg);
#else
    int state = radio.begin(bands[currentBand].freq, bands[currentBand].bw,
                            bands[currentBand].sf, bands[currentBand].cr,
                            RADIOLIB_LR2021_LORA_SYNC_WORD_PRIVATE,
                            10, 8, 1.8);
#endif

    if (state != RADIOLIB_ERR_NONE) {
        Serial.print(" FAIL - begin() err="); Serial.println(state);
        blinkRed(10, 100, 100);
        while (true) delay(10);
    }
    Serial.println(" OK");

    // Apply the selected band parameters + PA (quiet: the mode block prints it)
    if (!applyBand(currentBand)) {
        Serial.println("[INIT] applyBand FAILED");
        blinkRed(10, 100, 100);
        while (true) delay(10);
    }
    Serial.println("[INIT] PASS - Module initialized");
    Serial.println();

    radio.standby();
    txActive = false;
    txFlag = false;

    Serial.println("[MODE] IDLE (standby) - radio is NOT transmitting");
    Serial.print("[CFG]  preset band = ");
    printNow();
    Serial.println("   (not active yet)");
    Serial.println("[MODE] type 868 / 915 / 2.4G to START transmitting on that band");
    Serial.println("[MODE] \"tx\" resumes the current band after \"idle\"");
    Serial.println();

    printHelp();
    Serial.println();

    ledOff();
    Serial.println("--- TX Test Ready ---\n");
}

void loop() {
    pollSerial();

    if (!txActive) {
        delay(10);
        return;
    }

    seqNum++;
    txFlag = false;

    String msg = "hello " + String(seqNum) + " " + bands[currentBand].name + " " + String(activePower) + "dBm";
    int state = radio.startTransmit(msg);

    if (state != RADIOLIB_ERR_NONE) {
        printPktFail(state);
        radio.finishTransmit();
        blinkRed(5, 100, 100);
        ledBlue();
        idleWait(2000);
        return;
    }

    unsigned long txTimeout = millis() + 5000;
    while (!txFlag && millis() < txTimeout) {
        if (radio.getIrqFlags() & RADIOLIB_LR2021_IRQ_TX_DONE) {
            txFlag = true;
            break;
        }
        delay(1);
    }
    radio.finishTransmit();

    if (!txFlag) {
        printPktLine("TIMEOUT");
        blinkRed(5, 100, 100);
        ledBlue();
        idleWait(2000);
        return;
    }

    printPktLine("OK");

    ledGreen(); delay(100); ledBlue();

    idleWait(2000);  // 2s interval, serial commands accepted meanwhile
}
