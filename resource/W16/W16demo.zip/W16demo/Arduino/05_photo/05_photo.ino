#include <RadioLib.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <esp32-hal-rgb-led.h>
#include <ctype.h>

#if __has_include("esp32-hal-psram.h")
  #include "esp32-hal-psram.h"
#endif

// The camera library is optional: without esp32-camera it falls back to a synthetic image
#if __has_include("esp_camera.h")
  #include "esp_camera.h"
  #define CAM_LIB_OK 1
#else
  #define CAM_LIB_OK 0
#endif

// ==================== Radio SPI pins (same as 01~04) ====================
#define PIN_SCK     12
#define PIN_MISO    11
#define PIN_MOSI    10
#define PIN_NSS     47
#define PIN_DIO7    42
#define PIN_NRESET  39
#define PIN_BUSY    21
#define PIN_LED     48    // WS2812 RGB LED

// ==================== Button ====================
#define PIN_PTT     0     // BOOT button, pressed (LOW) = board A takes a photo immediately

// ==================== Camera pins (W11 expansion board, see the schematic) ====================
// Note: these pins overlap the radio pins above, so only one of the two can be used
#define CAM_PIN_PWDN    -1
#define CAM_PIN_RESET   -1
#define CAM_PIN_XCLK    10
#define CAM_PIN_SIOD    40
#define CAM_PIN_SIOC    39
#define CAM_PIN_D7      48
#define CAM_PIN_D6      11
#define CAM_PIN_D5      12
#define CAM_PIN_D4      14
#define CAM_PIN_D3      16
#define CAM_PIN_D2      18
#define CAM_PIN_D1      17
#define CAM_PIN_D0      15
#define CAM_PIN_VSYNC   38
#define CAM_PIN_HREF    47
#define CAM_PIN_PCLK    13

#define USE_CAMERA      0

// Camera resolution / quality (smaller jpeg_quality = sharper, larger = less bandwidth)
#define CAM_FRAMESIZE   FRAMESIZE_QVGA     // 320x240, about 8~14KB
#define CAM_QUALITY     12

// ==================== FLRC parameters (both boards must match exactly) ====================
#define FLRC_FREQ       2450.0f
#define FLRC_BR         1300
#define FLRC_POWER      12            // dBm (2.4G max 12)
#define FLRC_PRE        32            // Preamble length in bits. 16 (=12us) is not enough for the
#define PHOTO_CHUNK      240
// 197 chunks x 240B = 47280 bytes = ~46KB, the same byte budget the 246 x 192 layout had.
// totalChunks is uint16_t, so the protocol would allow far more; this cap is a time
// budget, not a memory limit. The page shrinks the image to fit it.
#define PHOTO_MAX_CHUNKS 197
#define IMG_BUF_CAP      (PHOTO_MAX_CHUNKS * PHOTO_CHUNK + 64)   // 47344 bytes
#define BM_BYTES         ((PHOTO_MAX_CHUNKS + 7) / 8)            // 25 bytes = 200 bits >= 197

#define ACK_WAIT_MS      500          // time to wait for the bitmap after a round
#define ACK_ASK_TRIES    3            // re-send PKT_END this many times before redoing a round
#define BM_REPEAT        3            // board B sends the bitmap this many times, back to back
#define END_REPEAT       3            // board A sends PKT_END this many times, back to back
#define PKT_TX_TIMEOUT   120          // max wait for TX_DONE per packet
#define GAP_MIN          1            // floor for the auto-tuned inter-chunk gap (ms)

// Test image size (USE_CAMERA=0 only). 128x96 24bit BMP = 36918 bytes = 193 chunks
#define TEST_IMG_W       128
#define TEST_IMG_H       96

// ==================== WiFi AP ====================
// Both boards run an AP, with different SSIDs so the phone knows which one it joined:
//   board A (tx) -> W16-SEND  : upload an image (camera / local file)
//   board B (rx) -> W16-PHOTO : view the received image
#define AP_SSID_TX      "W16-SEND"
#define AP_SSID_RX      "W16-PHOTO"
#define AP_PASS         "12345678"    // at least 8 chars
#define WEB_PORT        80

// ==================== Packet types ====================
#define PKT_DATA         1
#define PKT_END          2
#define PKT_BITMAP       3
#define PKT_REQ          4

// ==================== Image formats ====================
// The receiver used to sniff the magic number for Content-Type, but an uploaded image
// may be JPEG/PNG/WebP and a wrong guess renders nothing. The sender states it explicitly now.
#define FMT_BMP          0
#define FMT_JPEG         1
#define FMT_PNG          2

// ==================== Air frame ====================
// 11-byte header + 240 bytes of data = a 251-byte fixed packet (FLRC max is 255).
// totalChunks is 16-bit and totalLen is 32-bit so an image is no longer capped at 48KB.
struct __attribute__((packed)) PhotoPacket {
    uint8_t  type;
    uint8_t  imgId;
    uint16_t totalChunks;
    uint8_t  format;      // FMT_xxx, so the receiver knows the Content-Type
    uint32_t totalLen;
    uint16_t chunkIdx;    // DATA: chunk index; BITMAP: number of missing chunks
    uint8_t  data[PHOTO_CHUNK];
};

// ==================== Roles ====================
enum Role { ROLE_IDLE = 0, ROLE_TX = 1, ROLE_RX = 2 };

Role gRole = ROLE_IDLE;

// Role memory: tx/rx is stored in NVS and restored at boot together with the AP, so
// each board is reachable without typing a command again.
Preferences prefs;

Module mod(PIN_NSS, PIN_DIO7, PIN_NRESET, PIN_BUSY, SPI,
           SPISettings(8000000, MSBFIRST, SPI_MODE0));
LR2021 radio(&mod);

uint8_t* imgBuf = nullptr;
// Actual capacity in chunks. Normally PHOTO_MAX_CHUNKS; halved at boot if the buffer could
// not be allocated, so the sketch degrades instead of not working at all.
uint16_t gMaxChunks = PHOTO_MAX_CHUNKS;

// ==================== State ====================
uint8_t  gImgId      = 0;         // image id (same meaning on both ends)
uint16_t gChunkTotal = 0;
uint32_t gImgLen     = 0;
uint8_t  gChunkGapMs = 1;         // current inter-chunk gap, auto-tuned after every round
uint8_t  gGapMaxMs   = 6;         // ceiling; the "gap N" command and the page slider set this
uint8_t  gMaxRounds  = 10;

// TX: pending bitmap (bit=1 = still to send)
uint8_t  txPending[BM_BYTES];
uint8_t  txRound = 0;

uint32_t txImgLen   = 0;
uint8_t  txImgFmt   = FMT_BMP;
bool     txHasImage = false;
volatile bool gTxBusy = false;    // sending in progress (the page shows "sending")
uint8_t  txPct      = 0;          // percentage of chunks sent this round

// RX: received bitmap (bit=1 = chunk received)
uint8_t  rxHave[BM_BYTES];
uint8_t  rxImgId      = 0;
uint16_t rxChunkTotal = 0;
uint8_t  rxFmt        = FMT_BMP;
uint32_t rxImgLen     = 0;
uint16_t rxGotChunks  = 0;
bool     rxDone       = false;

// last complete image (read by the page)
uint32_t rxLastLen   = 0;
uint8_t  rxLastImgId = 0;
uint8_t  rxLastFmt   = FMT_BMP;

// trigger flags
volatile bool gSendReq     = false;   // board A: time to send
volatile bool gWantCapture = false;   // board B: time to request an image

// counters
unsigned int txPhotos = 0, rxPhotos = 0;
unsigned int txFail = 0, txRetrans = 0;
unsigned int rxPackets = 0, rxNoise = 0, rxOtherErr = 0;
unsigned long lastErrPrint = 0;

uint32_t txBusyUs = 0;
uint32_t txPktN   = 0;

// camera
bool gCamOk = false;

bool gRadioOk = false;

// WiFi / Web
bool gWifiOn = false;
WebServer webServer(WEB_PORT);

uint8_t gApChannel    = 0;
uint8_t gApChannelNow = 1;      // effective channel (status / page display)
uint8_t gApClients    = 0;      // connected station count
uint8_t gApPowerDbm   = 15;     // AP TX power. With split channels (6/11) the two APs no longer fight, but 11dBm made
const char* gSsidOverride = nullptr;

// ==================== Helpers ====================
static inline void bmSet(uint8_t* bm, uint16_t i)   { bm[i >> 3] |=  (uint8_t)(1u << (i & 7)); }
static inline void bmClear(uint8_t* bm, uint16_t i) { bm[i >> 3] &= (uint8_t)~(1u << (i & 7)); }
static inline bool bmGet(const uint8_t* bm, uint16_t i) { return (bm[i >> 3] >> (i & 7)) & 1u; }

// Set/clear the whole bitmap and clear the bits beyond totalChunks
static void bmFill(uint8_t* bm, uint16_t n, bool set) {
    memset(bm, set ? 0xFF : 0x00, BM_BYTES);
    for (uint16_t i = n; i < PHOTO_MAX_CHUNKS; i++) bmClear(bm, i);
}

static uint16_t bmCount(const uint8_t* bm, uint16_t n) {
    uint16_t c = 0;
    for (uint16_t i = 0; i < n; i++) if (bmGet(bm, i)) c++;
    return c;
}

// ==================== LED ====================
void ledGreen() { neopixelWrite(PIN_LED, 0, 8, 0); }
void ledRed()   { neopixelWrite(PIN_LED, 8, 0, 0); }
void ledBlue()  { neopixelWrite(PIN_LED, 0, 0, 8); }
void ledOff()   { neopixelWrite(PIN_LED, 0, 0, 0); }

void blinkGreen(int times) {
    for (int i = 0; i < times; i++) { ledGreen(); delay(40); ledOff(); delay(40); }
}

void blinkRed(int times) {
    for (int i = 0; i < times; i++) { ledRed(); delay(60); ledOff(); delay(60); }
}

static int16_t beginFlrc() {
#if defined(RADIOLIB_VERSION_MAJOR) && (RADIOLIB_VERSION_MAJOR >= 8)
    radio.tcxoVoltage = Voltage1V8;            // 7.x passed this as the 7th argument
    ConfigFLRC_t cfg;
    cfg.frequency      = (uint32_t)(FLRC_FREQ * 1000000.0f);   // Hz
    cfg.bitRate        = (uint32_t)FLRC_BR * 1000;             // bps
    cfg.codingRate     = RADIOLIB_LR2021_FLRC_CR_1_2;
    cfg.power          = FLRC_POWER;
    cfg.preambleLength = FLRC_PRE;
    cfg.dataShaping    = RADIOLIB_SHAPING_0_5;
    return radio.beginFLRC(cfg);
#else
    return radio.beginFLRC(FLRC_FREQ, FLRC_BR,
                           RADIOLIB_LR2021_FLRC_CR_1_2,
                           FLRC_POWER, FLRC_PRE,
                           RADIOLIB_SHAPING_0_5, 1.8);
#endif
}

bool beginRadio() {
    radio.irqDioNum = 7;

    int16_t st = RADIOLIB_ERR_CHIP_NOT_FOUND;
    for (int attempt = 1; attempt <= 3; attempt++) {
        st = beginFlrc();
        if (st == RADIOLIB_ERR_NONE || st == RADIOLIB_ERR_SPI_CMD_INVALID) break;
        Serial.print("[RADIO] 第"); Serial.print(attempt);
        Serial.print("次初始化失败 err="); Serial.println(st);
        delay(80);
    }

    bool needPatch = (st == RADIOLIB_ERR_SPI_CMD_INVALID);
    if (needPatch) {
        Serial.println("[RADIO] WARN 2.4G PA 被拒(-706), 补设被跳过的 FLRC 参数");
    } else if (st != RADIOLIB_ERR_NONE) {
        Serial.print("[RADIO] beginFLRC FAIL - err="); Serial.println(st);
        // Give a direction from the error code instead of guessing
        if (st == RADIOLIB_ERR_CHIP_NOT_FOUND) {
            Serial.println("[RADIO]   -2 = 芯片没应答: 查 SPI 引脚(MISO/MOSI 是否接反)、3V3、NSS、复位脚");
        } else if (st == RADIOLIB_ERR_SPI_CMD_FAILED) {
            Serial.println("[RADIO]   -707 = 芯片回了 CMD_FAIL: 多为 SPI 总线错位/时钟过快, 或 TCXO 未起振");
        } else if (st == RADIOLIB_ERR_SPI_CMD_INVALID) {
            Serial.println("[RADIO]   -706 = 命令参数被拒");
        }
        return false;
    }

    if (needPatch) {
        int16_t s2 = radio.setPreambleLength(FLRC_PRE);
        int16_t s3 = radio.setDataShaping(RADIOLIB_SHAPING_0_5);
        uint8_t sync[] = { 0x2D, 0x01, 0x4B, 0x1D };
        int16_t s4 = radio.setSyncWord(sync, 4);
        int16_t s5 = radio.setCRC(2);
        Serial.print("[RADIO] 补设 pre="); Serial.print(s2);
        Serial.print(" shape="); Serial.print(s3);
        Serial.print(" sync=");  Serial.print(s4);
        Serial.print(" crc=");   Serial.println(s5);
    }

    // Fixed packet length must come after setSyncWord() (it recomputes packet params)
    int16_t s1 = radio.fixedPacketLengthMode(sizeof(PhotoPacket));
    if (s1 != RADIOLIB_ERR_NONE) {
        Serial.print("[RADIO] fixedPacketLengthMode FAIL - err="); Serial.println(s1);
        return false;
    }

    radio.standby();
    Serial.print("[RADIO] OK  FLRC ");
    Serial.print(FLRC_FREQ, 1); Serial.print("MHz ");
    Serial.print(FLRC_BR);      Serial.print("kbps CR1/2 pre=");
    Serial.print(FLRC_PRE);     Serial.print(" pkt=");
    Serial.println((unsigned int)sizeof(PhotoPacket));
    return true;
}

// ==================== Enter RX / enter TX standby ====================
bool enterRx() {
    if (!gRadioOk) return false;
    radio.standby();
    delay(2);
    int16_t st = radio.startReceive();
    if (st != RADIOLIB_ERR_NONE) {
        // Must throttle: one line at 115200 takes ~30ms and flooding stalls the main loop
        if (millis() - lastErrPrint > 1000) {
            Serial.print("[RF] startReceive FAIL - err="); Serial.println(st);
            lastErrPrint = millis();
        }
        return false;
    }
    return true;
}

void enterTxStandby() {
    radio.standby();
    delay(2);
}

// ==================== Send one packet ====================
bool sendPkt(const PhotoPacket& p) {
    if (!gRadioOk) return false;
    uint32_t tPkt = micros();
    int16_t st = radio.startTransmit((const uint8_t*)&p, sizeof(p));
    if (st != RADIOLIB_ERR_NONE) {
        txFail++;
        if (millis() - lastErrPrint > 1000) {
            Serial.print("[RF] startTransmit FAIL - err="); Serial.println(st);
            lastErrPrint = millis();
        }
        radio.standby();     // Return to a sane state after an error, otherwise the next packet fails too
        return false;
    }

    unsigned long t0 = millis();
    bool done = false;
    uint16_t spins = 0;
    while (millis() - t0 < PKT_TX_TIMEOUT) {
        // DIO7 drops IRQs on this board, so poll the IRQ register instead of radio.transmit()
        if (radio.getIrqFlags() & RADIOLIB_LR2021_IRQ_TX_DONE) { done = true; break; }
        // delay(0) is a FreeRTOS yield, and one yield can cost a full 1ms tick whenever the
        // WiFi task is runnable - several ms of dead time per packet, per chunk. Spin for a
        // few hundred us instead and hand the CPU over only occasionally so nothing starves.
        if ((++spins & 63) == 0) delay(0);
        else                     delayMicroseconds(20);
    }
    radio.finishTransmit();
    txBusyUs += (uint32_t)(micros() - tPkt);
    txPktN++;
    if (!done) {
        txFail++;
        if (millis() - lastErrPrint > 1000) {
            Serial.println("[RF] TX_TIMEOUT");
            lastErrPrint = millis();
        }
    }
    return done;
}

// ==================== Receive one packet (non-blocking) ====================
// true = one packet decoded into *p; false = nothing available right now.
// CRC failures are mostly air noise hitting the sync word (normal at 1300kbps), counted
// as rxNoise.
bool rxPoll(PhotoPacket* p) {
    if (!gRadioOk) return false;
    if (!(radio.getIrqFlags() & RADIOLIB_LR2021_IRQ_RX_DONE)) return false;

    size_t len = radio.getPacketLength();
    if (len < 8 || len > sizeof(PhotoPacket)) {
        // Bad length: readData() was never called, so the FIFO and IRQ flags are still set
        enterRx();
        return false;
    }

    int16_t st = radio.readData((uint8_t*)p, len);
    if (st != RADIOLIB_ERR_NONE) {
        if (st == RADIOLIB_ERR_CRC_MISMATCH) rxNoise++;
        else                                 rxOtherErr++;
        return false;
    }
    // No re-arm needed after a good packet: readData() only drains the FIFO and clears the
    // flags, the chip returns to RX by itself. startReceive() here would be rejected (-706).
    rxPackets++;
    return true;
}

// Receive with timeout (used by board A while waiting for the bitmap)
bool recvPkt(PhotoPacket* p, uint16_t timeoutMs) {
    unsigned long t0 = millis();
    while (millis() - t0 < timeoutMs) {
        if (rxPoll(p)) return true;
        delay(0);
    }
    return false;
}

// ==================== Camera ====================
void initCamera() {
#if (USE_CAMERA && CAM_LIB_OK)
    camera_config_t cfg;
    memset(&cfg, 0, sizeof(cfg));
    cfg.ledc_channel = LEDC_CHANNEL_0;
    cfg.ledc_timer   = LEDC_TIMER_0;
    cfg.pin_pwdn     = CAM_PIN_PWDN;
    cfg.pin_reset    = CAM_PIN_RESET;
    cfg.pin_xclk     = CAM_PIN_XCLK;
    cfg.pin_sccb_sda = CAM_PIN_SIOD;
    cfg.pin_sccb_scl = CAM_PIN_SIOC;
    cfg.pin_d0       = CAM_PIN_D0;
    cfg.pin_d1       = CAM_PIN_D1;
    cfg.pin_d2       = CAM_PIN_D2;
    cfg.pin_d3       = CAM_PIN_D3;
    cfg.pin_d4       = CAM_PIN_D4;
    cfg.pin_d5       = CAM_PIN_D5;
    cfg.pin_d6       = CAM_PIN_D6;
    cfg.pin_d7       = CAM_PIN_D7;
    cfg.pin_vsync    = CAM_PIN_VSYNC;
    cfg.pin_href     = CAM_PIN_HREF;
    cfg.pin_pclk     = CAM_PIN_PCLK;
    cfg.xclk_freq_hz = 20000000;
    cfg.frame_size   = CAM_FRAMESIZE;
    cfg.pixel_format = PIXFORMAT_JPEG;
    cfg.grab_mode    = CAMERA_GRAB_LATEST;
    // Prefer PSRAM; high resolutions need it, QVGA also fits in internal RAM
    cfg.fb_location  = psramFound() ? CAMERA_FB_IN_PSRAM : CAMERA_FB_IN_DRAM;
    cfg.jpeg_quality = CAM_QUALITY;
    cfg.fb_count     = 2;

    esp_err_t err = esp_camera_init(&cfg);
    if (err != ESP_OK) {
        Serial.print("[CAM] 初始化失败 0x"); Serial.println(err, HEX);
        gCamOk = false;
        return;
    }
    sensor_t* s = esp_camera_sensor_get();
    if (s) {
        s->set_vflip(s, 1);      // Same as W11: vertical flip, no mirror
        s->set_hmirror(s, 0);
    }
    gCamOk = true;
    Serial.println("[CAM] OK  DVP 摄像头就绪");
#else
    gCamOk = false;
#if !CAM_LIB_OK
    Serial.println("[CAM] 未安装 esp32-camera 库 -> 用合成测试图");
#else
    Serial.println("[CAM] USE_CAMERA=0 -> 用合成测试图");
#endif
#endif
}

// ==================== Synthetic test image (24bit BMP, bottom-up) ====================
static void put16(uint8_t* p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void put32(uint8_t* p, uint32_t v) {
    p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8);
    p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24);
}

// Draw a 128x96 colour-bar image: 8 vertical bars + a horizontal brightness ramp + a
// white line moving with the image id. BMP needs no encoder, a few dozen lines to build
// and native browser support.
size_t buildTestImage(uint8_t* buf, size_t cap) {
    const int W = TEST_IMG_W, H = TEST_IMG_H;
    const int rowBytes = ((W * 3) + 3) & ~3;
    const size_t dataLen = (size_t)rowBytes * (size_t)H;
    const size_t total   = 54 + dataLen;
    if (total > cap) return 0;

    memset(buf, 0, 54);
    buf[0] = 'B'; buf[1] = 'M';
    put32(buf + 2,  (uint32_t)total);
    put32(buf + 10, 54);                    // pixel data offset
    put32(buf + 14, 40);                    // BITMAPINFOHEADER
    put32(buf + 18, (uint32_t)W);
    put32(buf + 22, (uint32_t)H);
    put16(buf + 26, 1);                     // planes
    put16(buf + 28, 24);                    // bpp
    put32(buf + 34, (uint32_t)dataLen);
    put32(buf + 38, 2835);                  // 72 DPI
    put32(buf + 42, 2835);

    static const uint8_t bars[8][3] = {     // RGB
        {255,255,255}, {255,255,0}, {0,255,255}, {0,255,0},
        {255,0,255},   {255,0,0},   {0,0,255},   {0,0,0}
    };
    const int markX = (int)((gImgId * 9u) % (unsigned)W);

    uint8_t* px = buf + 54;
    for (int y = 0; y < H; y++) {
        uint8_t* row = px + (size_t)(H - 1 - y) * (size_t)rowBytes;   // BMP is bottom-up
        for (int x = 0; x < W; x++) {
            uint8_t r, g, b;
            if (x < 2 || x >= W - 2 || y < 2 || y >= H - 2) {         // white border
                r = g = b = 255;
            } else {
                const uint8_t* c = bars[(x * 8) / W];
                // Horizontal ramp, dark on the left: makes a truncated image obvious at a glance
                uint16_t k = (uint16_t)(128 + (x * 127) / (W - 1));
                r = (uint8_t)((c[0] * k) >> 8);
                g = (uint8_t)((c[1] * k) >> 8);
                b = (uint8_t)((c[2] * k) >> 8);
                if (x >= markX && x < markX + 2) { r = g = b = 255; } // moving marker
            }
            row[x * 3 + 0] = b;
            row[x * 3 + 1] = g;
            row[x * 3 + 2] = r;
        }
    }
    return total;
}

// ==================== Capture one image ====================
// Returns the byte count, 0 on failure. *mime tells the page how to render it.
// Sniff the format from the first bytes. Images uploaded from the phone are re-encoded
// by Canvas and are almost always JPEG, but curl may POST a raw file, so keep the fallback.
static uint8_t sniffFormat(const uint8_t* b, size_t n) {
    if (n >= 3 && b[0] == 0xFF && b[1] == 0xD8 && b[2] == 0xFF)            return FMT_JPEG;
    if (n >= 4 && b[0] == 0x89 && b[1] == 'P' && b[2] == 'N' && b[3] == 'G') return FMT_PNG;
    if (n >= 2 && b[0] == 'B'  && b[1] == 'M')                             return FMT_BMP;
    return FMT_JPEG;
}

static const char* fmtMime(uint8_t f) {
    switch (f) {
        case FMT_BMP: return "image/bmp";
        case FMT_PNG: return "image/png";
        default:      return "image/jpeg";
    }
}

size_t captureImage(uint8_t* fmtOut) {
    *fmtOut = FMT_BMP;

#if (USE_CAMERA && CAM_LIB_OK)
    if (gCamOk) {
        camera_fb_t* fb = esp_camera_fb_get();
        if (fb) {
            size_t n = fb->len;
            if (n > IMG_BUF_CAP) n = 0;
            if (n) memcpy(imgBuf, fb->buf, n);
            esp_camera_fb_return(fb);
            if (n) { *fmtOut = FMT_JPEG; return n; }
        }
        Serial.println("[CAM] 抓拍失败, 退回合成图");
    }
#endif

    return buildTestImage(imgBuf, IMG_BUF_CAP);
}

// ==================== Board A: send one image (rounds + bitmap retransmit) ====================
// fresh = true : capture a new image (camera / synthetic). Ignored when an uploaded image
//                is present, because recapturing would overwrite it.
// fresh = false: reuse the image in imgBuf (board B asked for a retransmit via PKT_REQ).
bool sendPhoto(bool fresh) {
    if (!imgBuf) { Serial.println("[TX] 缓冲未分配"); return false; }

    const uint32_t tStart = millis();
    uint8_t fmt = txImgFmt;
    size_t  len;

    if (txHasImage) {
        // Uploaded image, use it as is
        len = txImgLen;
        fmt = txImgFmt;
    } else if (!fresh && gImgLen) {
        // Reuse the previous image
        len = gImgLen;
    } else {
        len = captureImage(&fmt);
    }

    if (len == 0) {
        Serial.println("[TX] 采集失败");
        blinkRed(2);
        return false;
    }

    uint16_t chunks = (uint16_t)((len + PHOTO_CHUNK - 1) / PHOTO_CHUNK);
    if (chunks == 0 || chunks > gMaxChunks) {
        Serial.print("[TX] 图片过大, 块数="); Serial.println(chunks);
        blinkRed(2);
        return false;
    }

    gImgId++;
    gImgLen     = (uint32_t)len;
    txImgFmt    = fmt;
    gChunkTotal = chunks;
    bmFill(txPending, gChunkTotal, true);      // Mark everything pending

    Serial.print("[TX] #"); Serial.print(gImgId);
    Serial.print("  ");     Serial.print((unsigned int)len);
    Serial.print(" 字节 / "); Serial.print(chunks);
    Serial.print(" 块  ("); Serial.print(fmtMime(fmt));
    Serial.print(txHasImage ? ", 手机上传" : ", 本机采集");
    Serial.println(")");

    enterTxStandby();
    ledRed();
    gTxBusy = true;
    txPct   = 0;

    bool ok = false;
    uint32_t sentPkts = 0;
    uint16_t lastMissing = 0xFFFF;     // previous round's missing count, for stall detection

    for (txRound = 1; txRound <= gMaxRounds; txRound++) {
        // ---- 1. Send every pending chunk of this round ----
        PhotoPacket p;
        uint16_t sentThisRound = 0;
        for (uint16_t i = 0; i < gChunkTotal; i++) {
            if (!bmGet(txPending, i)) continue;

            size_t off = (size_t)i * PHOTO_CHUNK;
            size_t n   = len - off;
            if (n > PHOTO_CHUNK) n = PHOTO_CHUNK;

            memset(&p, 0, sizeof(p));
            p.type        = PKT_DATA;
            p.imgId       = gImgId;
            p.totalChunks = gChunkTotal;
            p.format      = fmt;
            p.totalLen    = (uint32_t)len;
            p.chunkIdx    = i;
            memcpy(p.data, imgBuf + off, n);

            sendPkt(p);
            sentPkts++;
            sentThisRound++;
            if (gChunkTotal) txPct = (uint8_t)((uint32_t)sentThisRound * 100UL / gChunkTotal);
            if (gChunkGapMs) delay(gChunkGapMs);
        }

        // ---- 2. Tell the peer the round ended and ask for the bitmap ----
        // Small guard before the END: board B may still be inside handleClient() for the last
        // few chunks, and a PKT_END that arrives while it is not in RX is simply gone.
        delay(20);
        memset(&p, 0, sizeof(p));
        p.type        = PKT_END;
        p.imgId       = gImgId;
        p.totalChunks = gChunkTotal;
        p.format      = fmt;
        p.totalLen    = (uint32_t)len;
        // Repeat the END back to back. It arrives 20ms after the last data packet, by which
        // time the receiver AGC has relaxed, so a single isolated packet is easily lost - the
        // first run showed only 3 of 30 ENDs getting through. Three copies 2ms apart keep the
        // AGC hot; board B answers the burst only once (it de-duplicates on its side).
        for (uint8_t i = 0; i < END_REPEAT; i++) {
            sendPkt(p);
            delay(2);
        }

        // ---- 3. Switch to RX and wait for the bitmap ----
        // A lost bitmap used to cost a whole round: for a 500-chunk image that is several
        // seconds of retransmission for the sake of one 200-byte packet. Ask again first -
        // PKT_END is cheap, the receiver answers every one of them.
        PhotoPacket r;
        bool gotBitmap = false;
        for (uint8_t ask = 0; ask < ACK_ASK_TRIES && !gotBitmap; ask++) {
            enterRx();
            unsigned long t0 = millis();
            while (millis() - t0 < ACK_WAIT_MS) {
                uint16_t left = (uint16_t)(ACK_WAIT_MS - (millis() - t0));
                if (!recvPkt(&r, left)) break;
                if (r.type == PKT_BITMAP && r.imgId == gImgId) { gotBitmap = true; break; }
            }
            if (!gotBitmap && ask + 1 < ACK_ASK_TRIES) {
                enterTxStandby();
                for (uint8_t i = 0; i < END_REPEAT; i++) {   // p still holds the PKT_END
                    sendPkt(p);
                    delay(2);
                }
            }
        }

        if (gotBitmap) {
            memcpy(txPending, r.data, BM_BYTES);
            for (uint16_t i = gChunkTotal; i < PHOTO_MAX_CHUNKS; i++) bmClear(txPending, i);

            uint16_t missing = bmCount(txPending, gChunkTotal);

            // The bitmap is a free link measurement: the chunks that never arrived are exactly
            // the packets this gap failed to deliver. Tighten while a round comes back clean,
            // back off when a meaningful share was lost. Same AIMD the video sketch uses, and
            // it matters more here than it looks: the gap is dead time on every single chunk,
            // so 4ms on a 125-chunk image is half a second of pure waiting.
            if (sentThisRound) {
                uint8_t oldGap = gChunkGapMs;
                if (missing == 0) {
                    if (gChunkGapMs > GAP_MIN) gChunkGapMs--;
                } else if ((uint32_t)missing * 8 >= (uint32_t)sentThisRound) {
                    if (gChunkGapMs < gGapMaxMs) gChunkGapMs++;
                }
                if (gChunkGapMs != oldGap) {
                    Serial.print("[GAP] ");
                    if (missing == 0) { Serial.print("无丢包"); }
                    else { Serial.print("丢 "); Serial.print(missing); Serial.print(" 块"); }
                    Serial.print(" -> 块间隔 "); Serial.print((int)gChunkGapMs);
                    Serial.print("ms (上限 "); Serial.print((int)gGapMaxMs); Serial.println("ms)");
                }
            }

            if (missing == 0) { ok = true; break; }

            txRetrans += missing;
            Serial.print("[TX] 第"); Serial.print(txRound);
            Serial.print("轮: 已发 "); Serial.print(sentThisRound);
            Serial.print(" 块, 还差 "); Serial.print(missing);
            // No progress at all: the handful of chunks just retransmitted were lost too, so a
            // targeted retry only repeats the same losing pattern. Fall back to a full round.
            if (missing >= lastMissing) {
                Serial.println(" 块, 补传无进展 -> 整轮重发");
                bmFill(txPending, gChunkTotal, true);
                lastMissing = 0xFFFF;      // next round starts from a clean slate
            } else {
                Serial.println(" 块, 补传");
                lastMissing = missing;
            }
        } else {
            // Bitmap lost (PKT_END or the bitmap itself eaten by noise): resend the whole round
            Serial.print("[TX] 第"); Serial.print(txRound);
            Serial.println("轮: 未收到回执, 整轮重发");
            bmFill(txPending, gChunkTotal, true);
        }

        enterTxStandby();
    }

    uint32_t dt = millis() - tStart;
    radio.standby();     // Finish in standby so the caller's enterRx() does not hit -706
    delay(2);
    ledOff();
    gTxBusy = false;
    txPct   = 100;

    if (ok) {
        txPhotos++;
        blinkGreen(2);
        Serial.print("[TX] 完成 #"); Serial.print(gImgId);
        Serial.print("  "); Serial.print(txRound);
        Serial.print(" 轮  共 "); Serial.print(sentPkts);
        Serial.print(" 包  "); Serial.print(dt);
        Serial.print("ms  有效吞吐 ");
        // Effective throughput = image bytes / total time, including retransmits and waiting
        Serial.print((dt > 0) ? ((float)len * 1000.0f / (float)dt) : 0.0f, 1);
        Serial.print(" B/s  ");
        if (sentPkts) {
            Serial.print((unsigned long)((dt * 1000UL) / sentPkts));
            Serial.print("us/包  gap ");
            Serial.print((int)gChunkGapMs);
            Serial.print("/");
            Serial.print((int)gGapMaxMs);
            Serial.print("ms");
        }
        Serial.println();
    } else {
        Serial.print("[TX] 失败 #"); Serial.print(gImgId);
        Serial.print("  "); Serial.print(gMaxRounds);
        Serial.println(" 轮仍未收齐");
        blinkRed(3);
    }
    return ok;
}

// ==================== Board B: return the bitmap / request a photo ====================
void sendBitmap(uint8_t imgId, const uint8_t* missing, uint16_t missCnt) {
    PhotoPacket p;
    memset(&p, 0, sizeof(p));
    p.type        = PKT_BITMAP;
    p.imgId       = imgId;
    p.totalChunks = rxChunkTotal;
    p.totalLen    = rxImgLen;
    p.chunkIdx    = missCnt;
    memcpy(p.data, missing, BM_BYTES);

    // Send the bitmap BM_REPEAT times back to back. Board A is the only side that can lose it
    // and it has no way of saying "I did not hear you" - asking again costs another round trip
    // over the same lossy link, which is exactly what made 10 rounds in a row fail with the
    // receiver printing "已回位图" every time. Three copies cost ~6ms and turn an ack loss
    // rate of p into p^3.
    enterTxStandby();
    for (uint8_t i = 0; i < BM_REPEAT; i++) {
        sendPkt(p);
        delay(2);          // let the peer re-arm before the next copy
    }
    enterRx();     // Back to RX immediately so the next round is not missed
}

void requestCapture() {
    enterTxStandby();
    PhotoPacket p;
    memset(&p, 0, sizeof(p));
    p.type  = PKT_REQ;
    p.imgId = gImgId;
    bool ok = sendPkt(p);
    enterRx();
    Serial.print("[RX] 已向 A 板发送拍照请求 ");
    Serial.println(ok ? "OK" : "FAIL");
}

// ==================== Board B: handle incoming packets ====================
void handleRxPacket(const PhotoPacket& p) {
    if (p.type == PKT_DATA) {
        if (p.imgId != rxImgId) {                 // New image, reset the session
            if (p.totalChunks == 0 || p.totalChunks > gMaxChunks ||
                p.totalLen == 0  || p.totalLen > (uint32_t)gMaxChunks * PHOTO_CHUNK) {
                Serial.println("[RX] 包头异常, 丢弃");
                rxImgId = 0;
                return;
            }
            rxImgId      = p.imgId;
            rxChunkTotal = p.totalChunks;
            rxFmt        = p.format;
            rxImgLen     = p.totalLen;
            rxGotChunks  = 0;
            rxDone       = false;
            bmFill(rxHave, rxChunkTotal, false);
            Serial.print("[RX] 收到新图 #"); Serial.print(rxImgId);
            Serial.print("  "); Serial.print(rxImgLen);
            Serial.print(" 字节 / "); Serial.print(rxChunkTotal);
            Serial.print(" 块  "); Serial.print(fmtMime(rxFmt));
            Serial.println(", 开始接收");
            ledBlue();
        }

        if (p.chunkIdx >= rxChunkTotal) return;

        size_t off = (size_t)p.chunkIdx * PHOTO_CHUNK;
        if (off >= rxImgLen) return;
        size_t n = (size_t)rxImgLen - off;
        if (n > PHOTO_CHUNK) n = PHOTO_CHUNK;

        memcpy(imgBuf + off, p.data, n);
        if (!bmGet(rxHave, p.chunkIdx)) {
            bmSet(rxHave, p.chunkIdx);
            rxGotChunks++;
        }
        return;
    }

    if (p.type == PKT_END) {
        if (p.imgId != rxImgId || rxImgId == 0) return;

        // Board A sends the END three times so the burst survives the receiver AGC cold start.
        // Answer only once per receive state: if no chunk has arrived since the previous
        // answer this is the same burst repeating, not a new request. The 300ms escape hatch
        // keeps a genuinely stalled round moving (all retransmitted chunks lost).
        static uint8_t  lastEndImg = 0;
        static uint16_t lastEndGot = 0xFFFF;
        static uint32_t lastEndMs  = 0;
        if (p.imgId == lastEndImg && rxGotChunks == lastEndGot &&
            (uint32_t)(millis() - lastEndMs) < 300) return;
        lastEndImg = p.imgId;
        lastEndGot = rxGotChunks;
        lastEndMs  = millis();

        // Build the missing bitmap (bit=1 = not received yet)
        uint8_t missing[BM_BYTES];
        bmFill(missing, rxChunkTotal, false);
        uint16_t miss = 0;
        for (uint16_t i = 0; i < rxChunkTotal; i++) {
            if (!bmGet(rxHave, i)) { bmSet(missing, i); miss++; }
        }

        sendBitmap(p.imgId, missing, miss);

        if (miss == 0) {
            rxDone      = true;
            rxLastLen   = rxImgLen;
            rxLastImgId = p.imgId;
            rxLastFmt   = rxFmt;
            rxPhotos++;
            blinkGreen(3);
            Serial.print("[RX] 完成 #"); Serial.print(p.imgId);
            Serial.print("  "); Serial.print(rxImgLen);
            Serial.print(" 字节  ("); Serial.print(rxGotChunks);
            Serial.println(" 块)");
            if (gWifiOn) {
                Serial.print("[WEB] 打开 http://");
                Serial.print(WiFi.softAPIP());
                Serial.println("/ 查看");
            }
        } else {
            Serial.print("[RX] 本轮结束: 已收 ");
            Serial.print(rxGotChunks); Serial.print("/");
            Serial.print(rxChunkTotal);
            Serial.print(" 块, 缺 "); Serial.print(miss);
            Serial.println(" 块 (已回位图)");
        }
    }
}

// ==================== Web page ====================
static const char PAGE_INDEX[] PROGMEM = R"rawliteral(
<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>W16 LoRa 图片</title>
<style>
:root{--bg:#f5f6f8;--card:#fff;--line:#e3e6ea;--txt:#1f2328;--dim:#6b7280;--acc:#2563eb}
*{box-sizing:border-box}
body{margin:0;padding:18px;background:var(--bg);color:var(--txt);
     font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif}
h1{font-size:17px;margin:0 0 14px;font-weight:600}
h1 span{color:var(--dim);font-weight:400;font-size:13px;margin-left:8px}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:14px;
      max-width:560px;margin:0 auto}
.meta{font-size:13px;color:var(--dim);margin-bottom:10px;line-height:1.7}
.meta b{color:var(--txt);font-weight:600}
.imgbox{background:#0f1115;border-radius:8px;min-height:180px;display:flex;
        align-items:center;justify-content:center;overflow:hidden}
.imgbox img{max-width:100%;display:block;cursor:zoom-in}
.lb{position:fixed;inset:0;background:rgba(0,0,0,.93);display:none;z-index:99;
    overflow:auto;padding:14px;text-align:center;cursor:zoom-out}
.lb.show{display:block}
.lb img{max-width:none;max-height:none;display:inline-block;margin:auto}
.lb i{position:fixed;top:10px;right:14px;color:#fff;font-style:normal;font-size:26px;
      line-height:1;padding:6px 10px;cursor:pointer}
.ph{color:#8b949e;font-size:13px}
.bar{height:4px;background:#e9edf2;border-radius:2px;margin:12px 0;overflow:hidden}
.bar i{display:block;height:100%;width:0;background:var(--acc);transition:width .2s}
.btns{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
button{border:1px solid var(--line);background:#fff;color:var(--txt);border-radius:8px;
       padding:8px 14px;font-size:13px;cursor:pointer}
button:hover{border-color:#c9ced6;background:#fafbfc}
button.pri{background:var(--acc);border-color:var(--acc);color:#fff}
button.pri:hover{background:#1d4ed8}
label{font-size:13px;color:var(--dim);display:flex;align-items:center;gap:5px}
</style></head><body>
<div class="card">
  <h1>W16 &middot; LR2021 图片传输<span id="ip"></span><span style="color:#059669;font-size:12px">v3</span></h1>
  <div class="meta" id="meta">正在连接…</div>
  <div class="imgbox"><img id="photo" alt="" style="display:none" onclick="view(this.src)">
    <div class="ph" id="ph">尚未收到图片</div></div>
  <div class="bar"><i id="prog"></i></div>
  <div class="btns">
    <button class="pri" onclick="req()">让 A 板重发</button>
    <button onclick="load()">刷新图片</button>
    <button id="big" disabled onclick="view(document.getElementById('photo').src)">查看大图</button>
    <button id="save" disabled onclick="save()">保存到相册</button>
    <label><input type="checkbox" id="auto" checked onchange="tick()"> 自动刷新</label>
  </div>
</div>
<div class="lb" id="lb" onclick="closeLb()"><i>&times;</i><img id="lbimg" alt="" onclick="event.stopPropagation()"></div>
<script>
let lastId=-1, timer=null, blobCache=null, blobType='';
async function st(){
  try{
    const r = await fetch('/status',{cache:'no-store'});
    const j = await r.json();
    document.getElementById('ip').textContent = j.ip ? '('+j.ip+')' : '';
    let s = '模式 <b>'+j.mode+'</b>　图片 <b>#'+j.imgId+'</b>　';
    if(j.done) s += '<b>'+j.len+'</b> 字节 · 已完成';
    else if(j.total) s += '接收中 <b>'+j.got+'/'+j.total+'</b> 块';
    else s += '等待 A 板发送（手机上传后）';
    s += '　噪声 '+j.noise+'　收包 '+j.packets;
    document.getElementById('meta').innerHTML = s;
    document.getElementById('prog').style.width =
      (j.total? Math.round(j.got*100/j.total) : 0)+'%';
    if(j.done && j.imgId!==lastId){ lastId=j.imgId; load(); }
  }catch(e){ document.getElementById('meta').textContent='连接断开, 正在重试…'; }
}

// One fetch feeds both the preview and the save button. Keeping the blob around is what lets
// save() run entirely inside the tap handler: navigator.share() refuses to open without a
// fresh user gesture, and awaiting a fetch first would have consumed it.
async function load(){
  var im=document.getElementById('photo');
  try{
    var r = await fetch('/photo?t='+Date.now(), {cache:'no-store'});
    if(!r.ok) return;
    var b = await r.blob();
    if(!b.size) return;
    blobCache = b;
    blobType  = b.type || 'image/jpeg';
    if(im.dataset.url) URL.revokeObjectURL(im.dataset.url);
    var u = URL.createObjectURL(b);
    im.dataset.url = u;
    im.src = u;
    im.style.display='block';
    document.getElementById('big').disabled=false;
    document.getElementById('save').disabled=false;
    document.getElementById('ph').style.display='none';
  }catch(e){}
}

// Full-screen viewer: the preview is scaled to the card, so the real pixels are otherwise
// only reachable by downloading the file.
function view(src){
  if(!src) return;
  document.getElementById('lbimg').src = src;
  document.getElementById('lb').classList.add('show');
}
function closeLb(){ document.getElementById('lb').classList.remove('show'); }

function stamp(){
  var d=new Date(), p=function(n){return ('0'+n).slice(-2);};
  return ''+d.getFullYear()+p(d.getMonth()+1)+p(d.getDate())+'_'+
         p(d.getHours())+p(d.getMinutes())+p(d.getSeconds());
}

// Save to the system photo library. A plain <a download> only ever lands in Downloads, which
// on a phone is not the gallery. navigator.share() hands the file to the OS sheet, where
// "保存图片 / Save Image" writes straight into the album. Falls back to a download when the
// browser has no file sharing at all (WeChat and older webviews).
function save(){
  if(!blobCache) return;
  var ext  = blobType.indexOf('png')>=0 ? '.png' : '.jpg';
  var name = 'W16_'+stamp()+ext;
  var f = null;
  try{ f = new File([blobCache], name, {type: blobType}); }catch(e){}
  if(f && navigator.canShare && navigator.canShare({files:[f]})){
    navigator.share({files:[f], title:'W16 图片'}).catch(function(){ dl(name); });
    return;
  }
  dl(name);
  document.getElementById('meta').innerHTML += '<br>浏览器不支持直接存相册，已下载文件；'+
    '在微信里请长按图片选「保存图片」';
}

function dl(name){
  var url = URL.createObjectURL(blobCache);
  var a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(function(){ URL.revokeObjectURL(url); }, 5000);
}

async function req(){
  document.getElementById('meta').textContent='已请求 A 板重发, 等待…';
  try{ await fetch('/capture'); }catch(e){}
}
function tick(){
  if(timer){clearInterval(timer);timer=null;}
  if(document.getElementById('auto').checked) timer=setInterval(st,1000);
}
st(); tick();
</script></body></html>
)rawliteral";

// ==================== Board A page: phone camera / local file upload ====================
// Compression happens in the browser (Canvas + toBlob('image/jpeg', q)), no board CPU.
// A phone photo is 3~5MB while LoRa carries ~20KB/s, so it must be compressed first.
static const char PAGE_UPLOAD[] PROGMEM = R"rawliteral(
<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<title>W16 发送图片</title>
<style>
:root{--bg:#f5f6f8;--card:#fff;--line:#e3e6ea;--txt:#1f2328;--dim:#6b7280;--acc:#059669}
*{box-sizing:border-box}
body{margin:0;padding:18px;background:var(--bg);color:var(--txt);
     font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif}
h1{font-size:17px;margin:0 0 6px;font-weight:600}
h1 span{color:var(--dim);font-weight:400;font-size:13px;margin-left:8px}
.sub{font-size:12px;color:var(--dim);margin-bottom:14px;line-height:1.7}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:14px;
      max-width:560px;margin:0 auto}
.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.row+.row{margin-top:10px}
.btn{border:1px solid var(--line);background:#fff;color:var(--txt);border-radius:8px;
     padding:9px 15px;font-size:13px;cursor:pointer;display:inline-block;user-select:none}
.btn:hover{border-color:#c9ced6;background:#fafbfc}
.btn.pri{background:var(--acc);border-color:var(--acc);color:#fff}
.btn.pri:hover{background:#047857}
button{border:1px solid var(--line);background:#fff;color:var(--txt);border-radius:8px;
       padding:9px 15px;font-size:13px;cursor:pointer}
button.pri{background:var(--acc);border-color:var(--acc);color:#fff}
button.pri:hover{background:#047857}
button[disabled],.btn[disabled]{opacity:.45;cursor:not-allowed}
select{font-size:13px;border:1px solid var(--line);border-radius:6px;padding:4px 6px;background:#fff}
input[type=range]{width:110px;vertical-align:middle}
label.opt{font-size:13px;color:var(--dim);display:flex;align-items:center;gap:6px}
.imgbox{background:#0f1115;border-radius:8px;min-height:160px;display:flex;margin-top:12px;
        align-items:center;justify-content:center;overflow:hidden}
.imgbox img{max-width:100%;max-height:340px;display:block;cursor:zoom-in}
/* Full-screen viewer: the preview above is scaled to the card, so a 320px photo looks
   tiny. Clicking it opens the real pixels here instead of forcing a download. */
.lb{position:fixed;inset:0;background:rgba(0,0,0,.93);display:none;z-index:99;
    overflow:auto;padding:14px;text-align:center;cursor:zoom-out}
.lb.show{display:block}
.lb img{max-width:none;max-height:none;display:inline-block;margin:auto}
.lb i{position:fixed;top:10px;right:14px;color:#fff;font-style:normal;font-size:26px;
      line-height:1;padding:6px 10px;cursor:pointer}
.ph{color:#8b949e;font-size:13px}
.meta{font-size:13px;color:var(--dim);margin-top:10px;line-height:1.7}
.meta b{color:var(--txt);font-weight:600}
.bar{height:4px;background:#e9edf2;border-radius:2px;margin:10px 0 0;overflow:hidden}
.bar i{display:block;height:100%;width:0;background:var(--acc);transition:width .25s}
</style></head><body>
<div class="card">
  <h1>W16 &middot; 拍照发送<span id="ip"></span><span style="color:#059669;font-size:12px">v5 &middot; 46KB</span></h1>
  <div class="sub">手机拍照 / 选一张本地图片 &rarr; 浏览器编码后经 LoRa 发到接收端<br>
    接收端热点 <b>W16-PHOTO</b>，浏览器打开 <b>192.168.4.1</b> 查看<br>
    <b>PNG 无损</b> = 逐字节还原；超过 46KB 上限时保持分辨率不变，自动改用 JPEG 发送</div>

  <div class="row">
    <label class="btn pri">&#128247; 拍照<input type="file" accept="image/*" capture="environment" hidden onchange="pick(this)"></label>
    <label class="btn">&#128444; 选本地图<input type="file" accept="image/*" hidden onchange="pick(this)"></label>
  </div>

  <div class="row">
    <label class="opt">格式
      <select id="fmt" onchange="reenc()">
        <option value="jpeg" selected>JPEG 有损</option>
        <option value="png">PNG 无损（超 46KB 转 JPEG）</option>
      </select>
    </label>
    <label class="opt">长边
      <select id="size" onchange="reenc()">
        <option value="160">160</option>
        <option value="320">320</option>
        <option value="480">480</option>
        <option value="640" selected>640</option>
      </select>
    </label>
    <label class="opt">质量
      <input type="range" id="q" min="40" max="95" value="80"
             oninput="document.getElementById('qo').textContent=this.value" onchange="reenc()">
      <span id="qo">80</span>
    </label>
  </div>

  <div class="imgbox"><img id="pv" alt="" style="display:none" onclick="viewBig()">
    <div class="ph" id="ph">还没有选图</div></div>

  <div class="meta" id="info">&mdash;</div>
  <div class="bar"><i id="prog"></i></div>

  <div class="row" style="margin-top:12px">
    <button class="pri" id="send" disabled onclick="send()">发送到接收端</button>
    <button onclick="viewBig()" id="big" disabled>查看原图</button>
    <span class="meta" id="state" style="margin:0"></span>
  </div>
</div>
<div class="lb" id="lb" onclick="closeLb()"><i>&times;</i><img id="lbimg" alt="" onclick="event.stopPropagation()"></div>
<script>
var HARD = 47280;          // 197 chunks x 240B = the firmware limit (~46KB)
var blob = null, blobMime = '', srcImg = null, busy = false, origUrl = null;

function isPng(){ return document.getElementById('fmt').value === 'png'; }

// Full-screen viewer. The card preview is the *downscaled* blob, so clicking it would just
// show a bigger version of a small image - the point is to inspect the original file.
function view(src){
  if(!src) return;
  document.getElementById('lbimg').src = src;
  document.getElementById('lb').classList.add('show');
}
function viewBig(){ view(origUrl || document.getElementById('pv').src); }
function closeLb(){ document.getElementById('lb').classList.remove('show'); }

function pick(inp){
  var f = inp.files && inp.files[0];
  inp.value = '';          // 清空，允许重复选同一张
  if(!f) return;
  var im = new Image();
  im.onload  = function(){ srcImg = im; origUrl = im.src; reenc(); };
  im.onerror = function(){ document.getElementById('info').textContent = '这张图浏览器打不开，换一张试试'; };
  im.src = URL.createObjectURL(f);
}

function mkCanvas(w, h){
  var cv = document.createElement('canvas');
  cv.width = w; cv.height = h;
  var cx = cv.getContext('2d');
  cx.fillStyle = '#fff';                 // 透明 PNG 转 JPEG 会变黑底，先铺白
  cx.fillRect(0, 0, w, h);
  cx.drawImage(srcImg, 0, 0, w, h);
  return cv;
}

// PNG is lossless, but it has no quality knob - only resolution. It used to shrink the image
// step by step until the file fit, which quietly threw away pixels the user asked to keep.
// Now the size is respected: if a PNG at the selected edge is over the ceiling, the same
// frame is sent as JPEG instead. JPEG at that size is both smaller and sharper than a PNG
// that had to be downscaled twice to fit.
function pngTry(side){
  var nat = Math.max(srcImg.naturalWidth, srcImg.naturalHeight);
  var sc  = Math.min(1, side / nat);
  var w   = Math.max(1, Math.round(srcImg.naturalWidth  * sc));
  var h   = Math.max(1, Math.round(srcImg.naturalHeight * sc));
  var cv  = mkCanvas(w, h);
  cv.toBlob(function(b){
    if(!b) return;
    if(b.size > HARD){
      // Over the limit: keep the pixels, change the container.
      jpgTry(cv, +document.getElementById('q').value / 100, w, h);
      return;
    }
    finish(b, w, h, 'image/png', side < nat);
  }, 'image/png');
}

// JPEG is lossy: keep the resolution, drop quality only until it fits. The floor is 0.45 -
// below that the picture turns to mush anyway, so stopping there and telling the user to pick
// a smaller edge is more honest than silently shipping a 320px-looking image at 640px.
function jpgTry(cv, q, w, h){
  cv.toBlob(function(b){
    if(!b) return;
    if(b.size > HARD && q > 0.45){ jpgTry(cv, q - 0.06, w, h); return; }
    finish(b, w, h, 'image/jpeg', false);
  }, 'image/jpeg', q);
}

function reenc(){
  if(!srcImg) return;
  var png = isPng();
  document.getElementById('q').disabled = png;   // quality means nothing for PNG
  var maxSide = +document.getElementById('size').value;
  if(png){ pngTry(maxSide); return; }

  var sc = Math.min(1, maxSide / Math.max(srcImg.naturalWidth, srcImg.naturalHeight));
  var w = Math.max(1, Math.round(srcImg.naturalWidth  * sc));
  var h = Math.max(1, Math.round(srcImg.naturalHeight * sc));
  jpgTry(mkCanvas(w, h), +document.getElementById('q').value / 100, w, h);
}

function finish(b, w, h, mime, shrunk){
  blob = b;
  blobMime = mime;                 // the real container, which may differ from the select
  var pv = document.getElementById('pv');
  pv.src = URL.createObjectURL(b);
  pv.style.display = 'block';
  document.getElementById('ph').style.display = 'none';

  var over   = b.size > HARD;
  var chunks = Math.ceil(b.size / 240);
  // ~32KB/s expected: 251-byte packets on an 8MHz SPI with a 1ms gap, plus one bitmap round
  var secs   = (b.size / 32000 + 1.2).toFixed(1);
  var kind;
  if (mime === 'image/png') {
    kind = '<b>无损 PNG</b>' + (shrunk ? '（已缩到该尺寸才塞得下，像素无损）' : '（未重编码）');
  } else if (isPng()) {
    kind = '<b>PNG 超过 46KB &rarr; 已转 JPEG</b>（分辨率未降）';
  } else {
    kind = 'JPEG 有损';
  }
  document.getElementById('info').innerHTML =
    w + '&times;' + h + ' &middot; <b>' + (b.size/1024).toFixed(1) + ' KB</b> &middot; ' +
    chunks + ' 块 &middot; 预计 <b>' + secs + ' 秒</b> &middot; ' + kind +
    (over ? ' &middot; <b style="color:#dc2626">仍超过 46KB 上限，请选更小的长边</b>' : '');
  document.getElementById('send').disabled = busy || over;
  document.getElementById('big').disabled  = false;
}

function send(){
  if(!blob || busy) return;
  busy = true;
  document.getElementById('send').disabled = true;
  document.getElementById('state').textContent = '上传中…';
  // The upload must be multipart/form-data! ESP32 WebServer only creates an upload
  // context (_currentUpload) for multipart; with application/octet-stream the core takes
  // the raw() branch and webServer.upload() gets a null pointer -> LoadProhibited crash
  // (the real cause of "AP drops mid-upload, Guru Meditation in the log").
  var fd = new FormData();
  fd.append('f', blob, blobMime === 'image/png' ? 'photo.png' : 'photo.jpg');
  fetch('/upload', {method:'POST', body: fd})
    .then(function(r){ return r.text().then(function(t){
        try { return JSON.parse(t); } catch(e) { return {ok:false, err:'HTTP ' + r.status}; }
    }); })
    .then(function(j){
      if(j.ok){
        // Uploaded, but the image is still being sent - keep busy=true until poll() sees txBusy false
        document.getElementById('state').textContent = '已上传，开始发送…';
        poll();
      }else{
        document.getElementById('state').textContent = '被拒: ' + (j.err || '未知');
        busy = false;
        document.getElementById('send').disabled = false;
      }
    })
    .catch(function(e){
      document.getElementById('state').textContent = '上传失败，确认手机还连着热点';
      busy = false;
      document.getElementById('send').disabled = false;
    });
}

// One self-scheduling poll chain: 300ms while sending, 2s when idle.
// Do not mix setInterval with setTimeout, that stacks several concurrent request chains.
var pollTimer = null;
function poll(){
  if(pollTimer){ clearTimeout(pollTimer); pollTimer = null; }
  fetch('/status', {cache:'no-store'}).then(function(r){ return r.json(); }).then(function(j){
    document.getElementById('ip').textContent = j.ip ? '(' + j.ip + ')' : '';
    if(j.txBusy){
      document.getElementById('prog').style.width = j.txPct + '%';
      document.getElementById('state').innerHTML =
        '发送中 #' + j.imgId + ' &middot; 第 ' + j.txRound + ' 轮 &middot; ' + j.txPct + '%';
      document.getElementById('send').disabled = true;
      pollTimer = setTimeout(poll, 300);
    }else{
      document.getElementById('prog').style.width = '100%';
      document.getElementById('state').innerHTML = j.imgId
        ? '已发送 <b>#' + j.imgId + '</b> &middot; 累计 ' + j.photos + ' 张'
        : '还没有发送过';
      busy = false;
      document.getElementById('send').disabled = !blob;
      pollTimer = setTimeout(poll, 2000);
    }
  }).catch(function(){ pollTimer = setTimeout(poll, 1500); });
}

poll();
</script></body></html>
)rawliteral";

void handleIndex() {
    // Page updates are unreliable on phones: browsers and in-app webviews cache the HTML and
    // may keep running an old page (symptom: "I switched to FormData but the board still
    // sees octet-stream"). Triple no-cache plus a version string in the page makes it visible.
    webServer.sendHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
    webServer.sendHeader("Pragma", "no-cache");
    webServer.sendHeader("Expires", "0");
    // Board A serves the upload page, board B the viewer - a board has exactly one role
    if (gRole == ROLE_TX) {
        webServer.send_P(200, "text/html; charset=utf-8", PAGE_UPLOAD);
    } else {
        webServer.send_P(200, "text/html; charset=utf-8", PAGE_INDEX);
    }
}

void handlePhoto() {
    if (rxLastLen == 0 || !imgBuf) {
        webServer.send(404, "text/plain; charset=utf-8", "尚未收到图片");
        return;
    }
    // The format comes with the packet (p.format) instead of magic-number sniffing: an
    // uploaded image may be JPEG or PNG and a wrong guess shows a blank page.
    const char* ct = fmtMime(rxLastFmt);

    webServer.sendHeader("Cache-Control", "no-store");
    // "inline" so the browser renders it instead of offering a download. The filename still
    // carries the right extension: the page's save path builds its own name, but a direct
    // open of /photo then lands as w16.png / w16.jpg instead of an extensionless blob.
    webServer.sendHeader("Content-Disposition",
                         String("inline; filename=\"w16.") +
                         (rxLastFmt == FMT_PNG ? "png"
                          : (rxLastFmt == FMT_BMP ? "bmp" : "jpg")) + "\"");
    webServer.setContentLength(rxLastLen);
    webServer.send(200, ct, "");

    // Stream in 4KB slices. A single sendContent() of 90KB keeps the WiFi stack busy long
    // enough for the radio RX FIFO (one packet deep) to overflow, and it also stalls the
    // browser for seconds.
    const size_t SLICE = 4096;
    for (size_t off = 0; off < rxLastLen; off += SLICE) {
        size_t n = (size_t)rxLastLen - off;
        if (n > SLICE) n = SLICE;
        webServer.sendContent((const char*)imgBuf + off, n);
    }
    Serial.print("[WEB] 下发图片 "); Serial.print((unsigned int)rxLastLen);
    Serial.print(" 字节  "); Serial.println(ct);
}

void handleStatus() {
    String j = "{";
    j += "\"mode\":\"";
    j += (gRole == ROLE_TX ? "TX" : (gRole == ROLE_RX ? "RX" : "IDLE"));
    j += "\",\"ip\":\"";
    j += (gWifiOn ? WiFi.softAPIP().toString() : String(""));
    j += "\"";

    // ---- board A (TX) fields, used by the page for the progress display ----
    j += ",\"hasImg\":";  j += (txHasImage ? "true" : "false");
    j += ",\"txLen\":";   j += String((int)(txHasImage ? txImgLen : gImgLen));
    j += ",\"txBusy\":";  j += (gTxBusy ? "true" : "false");
    j += ",\"txRound\":"; j += String((int)txRound);
    j += ",\"txPct\":";   j += String((int)txPct);

    // ---- board B (RX) fields ----
    j += ",\"imgId\":";   j += String((int)(gRole == ROLE_TX ? gImgId
                                             : (rxDone ? rxLastImgId : rxImgId)));
    j += ",\"len\":";     j += String((int)(rxDone ? rxLastLen : rxImgLen));
    j += ",\"got\":";     j += String((int)rxGotChunks);
    j += ",\"total\":";   j += String((int)rxChunkTotal);
    j += ",\"done\":";    j += (rxDone ? "true" : "false");
    j += ",\"photos\":";  j += String((int)(gRole == ROLE_TX ? txPhotos : rxPhotos));
    j += ",\"packets\":"; j += String((int)rxPackets);
    j += ",\"noise\":";   j += String((int)rxNoise);

    // ---- AP diagnostics: these fields pin down "the phone cannot see the SSID" ----
    gApClients = gWifiOn ? (uint8_t)WiFi.softAPgetStationNum() : 0;
    j += ",\"ap\":";      j += (gWifiOn ? "true" : "false");
    j += ",\"ch\":";      j += String((int)gApChannelNow);
    j += ",\"sta\":";     j += String((int)gApClients);
    j += ",\"heap\":";    j += String((int)(ESP.getFreeHeap() / 1024));
    j += "}";
    webServer.sendHeader("Cache-Control", "no-store");
    webServer.send(200, "application/json", j);
}

void handleCaptureReq() {
    gWantCapture = true;      // The real radio send happens in loop(), never inside the HTTP handler
    webServer.send(200, "application/json", "{\"ok\":true}");
}

// ==================== Board A: receive the uploaded image ====================
// The upload callback fires per chunk (~1436 bytes) and writes straight into imgBuf, so a
// 5MB original needs no contiguous buffer (over IMG_BUF_CAP it simply fails).
static uint32_t upLen  = 0;
static bool     upFail = false;
static bool     upBadEnc = false;    // Not a multipart upload -> reject before touching upload()

void handleUploadChunk() {
    // !! Critical pitfall !!
    // FunctionRequestHandler binds the same _ufn to both upload() and raw(). Any POST whose
    // Content-Type is not multipart/* takes the raw() branch, where _currentUpload is null -
    // webServer.upload() then dereferences null: LoadProhibited (EXCVADDR=0x0), reboot, AP
    // gone. So check Content-Type first, then take the upload object.
    if (!webServer.header("Content-Type").startsWith("multipart/")) {
        upFail   = true;
        upBadEnc = true;
        return;
    }

    HTTPUpload& up = webServer.upload();

    if (up.status == UPLOAD_FILE_START) {
        upLen      = 0;
        upFail     = false;
        upBadEnc   = false;
        txHasImage = false;
        Serial.println("[UP] 开始接收手机上传…");
        return;
    }

    if (up.status == UPLOAD_FILE_WRITE) {
        if (upFail) return;
        if (imgBuf == nullptr) { upFail = true; return; }
        if ((size_t)upLen + up.currentSize > (size_t)gMaxChunks * PHOTO_CHUNK) { upFail = true; return; }
        memcpy(imgBuf + upLen, up.buf, up.currentSize);
        upLen += up.currentSize;
        // Report every 8KB: if the upload dies midway, the last line shows where
        if ((upLen & 0x1FFF) < 0x400) {
            Serial.print("[UP] 已收 "); Serial.print(upLen); Serial.println(" 字节");
        }
        return;
    }

    if (up.status == UPLOAD_FILE_END) {
        Serial.print("[UP] 传输结束, 共 "); Serial.print(upLen);
        Serial.print(" 字节, 状态 "); Serial.println((int)up.status);
        if (upFail || upLen == 0) return;
        txImgLen   = upLen;
        txImgFmt   = sniffFormat(imgBuf, upLen);
        txHasImage = true;
    }
}

void handleUploadDone() {
    if (upBadEnc) {
        webServer.send(400, "application/json",
                       "{\"ok\":false,\"err\":\"页面是旧版(缓存), 请下拉刷新页面; 标题右边应显示 v2\"}");
        // Print the real Content-Type: an empty string means the header was never collected,
        // application/octet-stream means the page really is the old one.
        Serial.print("[UP] 拒绝: Content-Type=\"");
        Serial.print(webServer.header("Content-Type"));
        Serial.println("\" 不是 multipart/form-data");
        return;
    }
    if (upFail || upLen == 0) {
        String j = "{\"ok\":false,\"err\":\"";
        j += upFail ? "图片超过 46KB 上限，请调小长边" : "空文件";
        j += "\"}";
        webServer.send(400, "application/json", j);
        return;
    }

    // Radio send runs in loop() so the HTTP response goes out first and the phone does not time out
    gSendReq = true;

    String j = "{\"ok\":true,\"len\":";
    j += String((int)txImgLen);
    j += ",\"fmt\":";
    j += String((int)txImgFmt);
    j += "}";
    webServer.send(200, "application/json", j);

    Serial.print("[UP] 收到上传图片 ");
    Serial.print(txImgLen);
    Serial.print(" 字节  ");
    Serial.println(fmtMime(txImgFmt));
}

// ==================== AP: channel and TX power ====================
// Two boards on one desk hit two traps that make phones see only one AP:
//   1) same channel -> co-channel pressure, the scan list keeps the stronger one;
//   2) 20dBm at ~10cm -> the phone front end is blocked and the other AP vanishes.
// Default: channels split by role (A=6 / B=11) and AP power lowered to 11dBm, plenty at
// desk distance. Channel 1 was tried first but is crowded by home routers and the 11dBm
// beacon got buried - 6 is much cleaner.
static uint8_t channelForRole() {
    // The AP and the FLRC link share the same 2.4GHz antenna, so the AP desenses the receiver
    // by an amount that depends only on the frequency gap. ch11 is 2462MHz - 12MHz from the
    // 2450MHz carrier - and on its own cost 50% of the packets here (15% in the audio demo).
    //
    // Both boards use ch1 = 2412MHz, the full 38MHz away. A per-role split looks tidier but is
    // wrong: board A's AP keeps beaconing while it transmits, so its channel desenses board B
    // just as much. Within the 1~11 range the ESP32 allows by default, ch1 is the only channel
    // far enough from 2450MHz to be safe for either side. Sharing one channel also lets the two
    // APs coordinate through CSMA instead of transmitting over each other.
    return 1;
}

// dBm -> ESP32 power level enum
static wifi_power_t dbmToPower(int dbm) {
    if (dbm <= 8)  return WIFI_POWER_8_5dBm;
    if (dbm <= 11) return WIFI_POWER_11dBm;
    if (dbm <= 13) return WIFI_POWER_13dBm;
    if (dbm <= 15) return WIFI_POWER_15dBm;
    if (dbm <= 17) return WIFI_POWER_17dBm;
    if (dbm <= 19) return WIFI_POWER_19dBm;
    return WIFI_POWER_19_5dBm;
}

// Bring the AP up, 3 attempts. Switching from WIFI_OFF back to AP needs a moment: calling
// softAP() right away sometimes fails or comes up without broadcasting. Worst case seen:
// softAP() returns true, the log looks fine, no beacon is ever sent and the phone never
// sees the SSID. So check the real IP as well, not just the return value.
static bool apStart(const char* ssid, uint8_t ch) {
    if (ch < 1 || ch > 13) ch = 6;

    for (int attempt = 1; attempt <= 3; attempt++) {
        // Clean up first: previous AP, leftover STA link, then WiFi fully off
        WiFi.softAPdisconnect(true);
        WiFi.mode(WIFI_OFF);
        delay(300);

        WiFi.persistent(false);
        WiFi.mode(WIFI_AP);
        delay(400);                 // This delay cannot be skipped - it is the number one cause of "SSID not found"

        // Set the IP before starting the AP so it is always 192.168.4.1
        WiFi.softAPConfig(IPAddress(192, 168, 4, 1), IPAddress(192, 168, 4, 1),
                          IPAddress(255, 255, 255, 0));

        // args: ssid, pass, channel, ssid_hidden (0 = broadcast), max_connection
        bool ok = WiFi.softAP(ssid, AP_PASS, ch, 0, 4);
        if (ok) {
            WiFi.setSleep(false);   // The AP must not use power save, or beacons get irregular and harder to find
            // Lowered power: at desk distance 20dBm pushes the other AP out of the phone's scan list
            WiFi.setTxPower(dbmToPower(gApPowerDbm));
            delay(250);
            IPAddress ip = WiFi.softAPIP();
            if ((uint32_t)ip != 0) {
                Serial.print("[WEB] softAP OK  模式="); Serial.print((int)WiFi.getMode());
                Serial.print("  IP="); Serial.print(ip);
                Serial.print("  功率="); Serial.print((int)gApPowerDbm);
                Serial.println("dBm");
                return true;
            }
            Serial.println("[WEB] softAP 返回 true 但没拿到 IP, 重来");
        } else {
            Serial.print("[WEB] 第"); Serial.print(attempt);
            Serial.println("次 softAP 失败, 重试…");
        }
        delay(500);
    }
    return false;
}

void startWeb() {
    if (gWifiOn) return;

    const char* ssid = gSsidOverride ? gSsidOverride
                                     : ((gRole == ROLE_TX) ? AP_SSID_TX : AP_SSID_RX);

    // Channel: 0 = automatic (ch1), otherwise the user's value. Clamp to 1~11 because
    // softAP() fails outright above 11 with the default country code (cc=01, 1~11), which is
    // what happened when this returned ch13: three retries, then "热点启动失败".
    uint8_t ch = gApChannel;
    if (ch == 0) {
        ch = channelForRole();
        Serial.print("[WEB] 自动信道: ");
        Serial.println(ch);
    } else {
        Serial.print("[WEB] 使用指定信道 "); Serial.println(ch);
    }
    if (ch > 11) {
        Serial.print("[WEB] 信道 "); Serial.print(ch);
        Serial.println(" 超出 1~11, 改用 1");
        ch = 1;
    }

    if (!apStart(ssid, ch)) {
        Serial.println("[WEB] 热点启动失败 (3 次都失败)");
        Serial.println("[WEB]   多半是 WiFi 没初始化好, 输入 wifi 重开一次");
        Serial.println("[WEB]   也可能是供电不足: 换 USB 口 / 换根粗线");
        return;
    }
    gApChannelNow = ch;

    // Register routes once only: WebServer::on() appends to the handler list, so repeated
    // stopWeb()/startWeb() would stack several callbacks on the same URI.
    static bool routesReady = false;
    if (!routesReady) {
        // !! Headers must be registered explicitly !!
        // WebServer::_collectAllHeaders defaults to false (WebServer.h:327), so no header is
        // collected and webServer.header("Content-Type") always returns "". Without this the
        // multipart check in handleUploadChunk() fails 100% and even a valid multipart upload is
        // treated as an old page.
        static const char* kHdrs[] = {"Content-Type", "Content-Length"};
        webServer.collectHeaders(kHdrs, 2);

        webServer.on("/",        handleIndex);
        webServer.on("/photo",   handlePhoto);
        webServer.on("/status",  handleStatus);
        webServer.on("/capture", handleCaptureReq);
        // upload: HTTP_POST handler + chunk callback (writes while receiving, no extra buffer)
        webServer.on("/upload", HTTP_POST, handleUploadDone, handleUploadChunk);
        webServer.onNotFound([]() {
            webServer.send(404, "text/plain; charset=utf-8", "404");
        });
        routesReady = true;
    }
    webServer.begin();

    gWifiOn = true;
    Serial.print("[WEB] 热点 "); Serial.print(ssid);
    Serial.print(" / ");         Serial.print(AP_PASS);
    Serial.print("  信道 ");     Serial.print((int)ch);
    Serial.print(" (");          Serial.print(2407 + ch * 5); Serial.print("MHz)");
    Serial.print("  功率 ");     Serial.print((int)gApPowerDbm); Serial.print("dBm");
    Serial.print("  IP ");       Serial.print(WiFi.softAPIP());
    Serial.print("  MAC ");      Serial.println(WiFi.softAPmacAddress());
    Serial.print("[WEB] 手机打开 http://"); Serial.print(WiFi.softAPIP());
    Serial.print("/   (空闲堆 "); Serial.print(ESP.getFreeHeap() / 1024);
    Serial.println("KB)");
    if (gRole == ROLE_TX) {
        Serial.println("[WEB] A 板: 手机连上后拍照或选图, 点发送即可");
    } else {
        Serial.println("[WEB] B 板: 收到图后这里自动刷新");
    }
    Serial.println("[WEB] 两块板都在 ch1 (2412MHz, 离 FLRC 2450MHz 最远), SSID 不同");
    Serial.println("[WEB] 只看到其中一个? 1) 两块板拉开 1 米以上 (太近会互相压制)");
    Serial.println("[WEB]   2) 输入 power 8 再降一档功率  3) 手机 WiFi 关掉再开重新扫");
}

void stopWeb() {
    if (!gWifiOn) return;
    webServer.stop();
    WiFi.softAPdisconnect(true);
    WiFi.mode(WIFI_OFF);
    delay(150);          // Give the driver time to really stop, otherwise startWeb() right after fails
    gWifiOn = false;
    gApClients = 0;
    gSsidOverride = nullptr;
    Serial.println("[WEB] 热点已关闭");
}

// ==================== Role switching ====================
void switchRole(Role r) {
    // Typing the same role again reopens the AP, otherwise a failed AP start could never be
    // retried - the second "tx" would be swallowed by the early return.
    if (r == gRole) {
        // And it must say something: the role may come from NVS (already TX), and a silent "tx"
        // looks like the command was not received.
        if (r == ROLE_IDLE) {
            Serial.println("[MODE] 已经是 IDLE (不收发, 热点已关)");
        } else if (gWifiOn) {
            Serial.print("[MODE] 已经是 ");
            Serial.print(r == ROLE_TX ? "TX" : "RX");
            Serial.print(", 热点 ");
            Serial.print(r == ROLE_TX ? AP_SSID_TX : AP_SSID_RX);
            Serial.println(" 正在运行 (重复输入=重开热点)");
        } else {
            Serial.print("[MODE] 已经是 ");
            Serial.print(r == ROLE_TX ? "TX" : "RX");
            Serial.println(", 但热点没开, 正在重开…");
            startWeb();
        }
        return;
    }

    // tx/rx still work when the radio failed to init - AP and web page are independent of the
    // radio, so upload/view still work, only the data cannot go out. Returning early here used
    // to keep the AP down whenever the radio was broken, so the phone never saw W16-SEND and it
    // looked like a WiFi fault. That is the easiest trap when chasing "SSID not found".
    if (!gRadioOk && r != ROLE_IDLE) {
        Serial.println("[MODE] 注意: 射频未初始化, 热点照常打开, 但数据发不出去");
        Serial.println("[MODE]   网页拍照/选图/看图可用; 收发请先修射频接线");
    }

    if (gRadioOk) radio.standby();
    delay(5);
    // The SSID follows the role (A = W16-SEND / B = W16-PHOTO). The old AP must be torn down
    // first, otherwise startWeb() returns early because gWifiOn is still true and the phone
    // keeps seeing the previous role's name.
    if (gWifiOn) stopWeb();

    if (r == ROLE_TX) {
        gRole = ROLE_TX;
        gImgId = 0;
        bmFill(txPending, 0, false);
        if (gRadioOk) enterRx();   // Board A also listens while idle, waiting for board B's photo request
        ledBlue();
        Serial.println("[MODE] TX —— 等手机上传图片 (send 重发 / 按 BOOT 也发)");
        // Board A hosts its own AP for uploads: join W16-SEND and use the page
        startWeb();
    } else if (r == ROLE_RX) {
        gRole = ROLE_RX;
        rxImgId = 0; rxGotChunks = 0; rxChunkTotal = 0; rxImgLen = 0;
        rxDone = false;
        bmFill(rxHave, 0, false);
        if (gRadioOk) enterRx();
        ledBlue();
        Serial.println("[MODE] RX —— 接收图片 (串口保持安静, 收齐才打印)");
        startWeb();
    } else {
        gRole = ROLE_IDLE;
        radio.standby();
        ledOff();
        stopWeb();
        Serial.println("[MODE] IDLE —— 射频 standby");
    }

    // Remember the role so the next boot restores it without typing tx/rx
    prefs.begin("w16", false);
    prefs.putUChar("role", (uint8_t)gRole);
    prefs.end();
}

// ==================== Serial ====================
void printHelp() {
    Serial.println();
    Serial.println("Commands (type and press Enter):");
    Serial.println("  tx        A 板: 开热点 W16-SEND, 等手机上传图片");
    Serial.println("  rx        B 板: 收图 + 开热点 W16-PHOTO + 网页看图");
    Serial.println("  idle      停收发 (射频 standby)");
    Serial.println("  send      A 板: 立刻把当前图发出去 (有上传图就发上传的)");
    Serial.println("  req       B 板: 让 A 板重发上一张");
    Serial.println("  size X    qqvga/qvga/vga/svga (本机摄像头模式)");
    Serial.println("  gap N     块间隔上限 ms (默认 6, 自动从 1 收敛; 丢包多就加大)");
    Serial.println("  rounds N  最多重传轮数 (默认 10)");
    Serial.println("  wifi      开/关热点 (两块板都有)");
    Serial.println("  web       只开网页热点 W16-WEB (不依赖射频/角色), 排查搜不到 SSID");
    Serial.println("  wtest     只起一个测试热点 W16-TEST(20s), 排查搜不到 SSID");
    Serial.println("  ch N      热点信道: 0=自动 ch1 / 1~11=强制 (12~13 会被拒)");
    Serial.println("  power N   热点功率 5/8/11/15/20 dBm (默认 15, 信号弱就调大)");
    Serial.println("  clear     A 板: 丢弃手机上传的图, 改用本机采集");
    Serial.println("  status    打印计数");
    Serial.println("  help      本列表");
    Serial.println();
    Serial.println("  用法: A 板 tx -> 手机连 W16-SEND -> 网页拍照/选图 -> 发送");
    Serial.println("        B 板 rx -> 手机连 W16-PHOTO -> 192.168.4.1 看图");
    Serial.println();
    Serial.flush();     // Flush this batch before the next log line, otherwise bytes get interleaved and lost
}

void printStatus() {
    Serial.print("[STATUS] 模式=");
    Serial.print(gRole == ROLE_TX ? "TX" : (gRole == ROLE_RX ? "RX" : "IDLE"));
    Serial.print("  图#"); Serial.print((int)gImgId);
    Serial.print("  "); Serial.print((int)gImgLen);
    Serial.print(" 字节 / "); Serial.print((int)gChunkTotal); Serial.println(" 块");
    Serial.print("[STATUS] 待发图: ");
    if (txHasImage) {
        Serial.print(txImgLen); Serial.print(" 字节  ");
        Serial.println(fmtMime(txImgFmt));
    } else {
        Serial.println("无 (手机还没上传, 将用本机采集)");
    }
    Serial.print("[STATUS] 发送: 成功 "); Serial.print((int)txPhotos);
    Serial.print(" 张, 失败包 "); Serial.print((int)txFail);
    Serial.print(", 补传 "); Serial.print((int)txRetrans);
    Serial.print(" 块, 间隔 "); Serial.print((int)gChunkGapMs);
    Serial.print("ms (上限 "); Serial.print((int)gGapMaxMs);
    Serial.print("), 轮数 "); Serial.println((int)gMaxRounds);
    if (txPktN) {
        Serial.print("[STATUS] 每包 "); Serial.print((unsigned long)(txBusyUs / txPktN));
        Serial.print("us (空口理论 1545us)  共 "); Serial.print((unsigned long)txPktN);
        Serial.println(" 包");
    }
    Serial.print("[STATUS] 接收: 完成 "); Serial.print((int)rxPhotos);
    Serial.print(" 张, 收包 "); Serial.print((int)rxPackets);
    Serial.print(", 噪声 "); Serial.print((int)rxNoise);
    Serial.print(", 其他错 "); Serial.println((int)rxOtherErr);
    if (gRole == ROLE_RX) {
        Serial.print("[STATUS] 当前图 #"); Serial.print((int)rxImgId);
        Serial.print("  "); Serial.print((int)rxGotChunks); Serial.print("/");
        Serial.print((int)rxChunkTotal); Serial.print(" 块  ");
        Serial.println(rxDone ? "已完成" : "接收中");
    }
    if (gRole != ROLE_IDLE) {
        Serial.print("[STATUS] 热点 "); Serial.print(gWifiOn ? "开 " : "关 ");
        if (gWifiOn) {
            gApClients = (uint8_t)WiFi.softAPgetStationNum();
            Serial.print("SSID=");
            Serial.print(gRole == ROLE_TX ? AP_SSID_TX : AP_SSID_RX);
            Serial.print("  信道="); Serial.print((int)gApChannelNow);
            Serial.print("  功率="); Serial.print((int)gApPowerDbm); Serial.print("dBm");
            Serial.print("  IP="); Serial.print(WiFi.softAPIP());
            Serial.print("  已连="); Serial.print((int)gApClients); Serial.print("台");
            Serial.print("  MAC="); Serial.print(WiFi.softAPmacAddress());
        }
        Serial.println();
    }
    Serial.print("[STATUS] 空闲堆 "); Serial.print(ESP.getFreeHeap() / 1024);
    Serial.print("KB  PSRAM ");
    Serial.print(psramFound() ? (int)(ESP.getFreePsram() / 1024) : -1);
    Serial.println("KB");
    Serial.flush();
}

void handleCommand(char* s) {
    int n = (int)strlen(s);
    while (n > 0 && (s[n - 1] == ' ' || s[n - 1] == '\t')) s[--n] = 0;
    if (n == 0) return;

    // Echo the input line so it is visible that the board actually received the command.
    // A "> tx" line right away makes a dead command obvious.
    Serial.print("> "); Serial.println(s);

    if (!strcmp(s, "help") || !strcmp(s, "?")) { printHelp(); return; }
    if (!strcmp(s, "tx"))   { switchRole(ROLE_TX); return; }
    if (!strcmp(s, "rx"))   { switchRole(ROLE_RX); return; }
    if (!strcmp(s, "idle") || !strcmp(s, "stop")) { switchRole(ROLE_IDLE); return; }
    if (!strcmp(s, "status")) { printStatus(); return; }

    if (!strcmp(s, "send")) {
        if (gRole != ROLE_TX) { Serial.println("[CMD] 先输入 tx 切到发送角色"); return; }
        if (!gRadioOk) { Serial.println("[CMD] 射频未就绪, 图发不出去 (网页上传/预览仍可用)"); return; }
        gSendReq = true;
        Serial.println(txHasImage ? "[CMD] 发送手机上传的那张图"
                                  : "[CMD] 没有上传图, 用本机采集的图发送");
        return;
    }
    if (!strcmp(s, "req")) {
        if (gRole != ROLE_RX) { Serial.println("[CMD] 先输入 rx 切到接收角色"); return; }
        if (!gRadioOk) { Serial.println("[CMD] 射频未就绪, 请求发不出去"); return; }
        gWantCapture = true;
        Serial.println("[CMD] 请求 A 板重发上一张");
        return;
    }
    // AP self-test: does not touch the radio or the image buffer, just brings the AP up for
    // 20 seconds. Two-way triage: W16-TEST visible -> WiFi is fine, the problem is the tx/rx
    // startup flow; not visible -> antenna / power / the module itself.
    if (!strcmp(s, "wtest")) {
        bool wasOn = gWifiOn;
        if (wasOn) stopWeb();
        Serial.println("[WTEST] 单独起热点 W16-TEST / 12345678, 20 秒后自动关");
        if (apStart("W16-TEST", 9)) {
            for (int i = 0; i < 20; i++) {
                Serial.print("[WTEST] 剩 "); Serial.print(20 - i);
                Serial.print("s  已连 "); Serial.print((int)WiFi.softAPgetStationNum());
                Serial.print(" 台  IP "); Serial.println(WiFi.softAPIP());
                delay(1000);
            }
            WiFi.softAPdisconnect(true);
            WiFi.mode(WIFI_OFF);
            delay(300);
            Serial.println("[WTEST] 结束");
        } else {
            Serial.println("[WTEST] AP 起不来 -> 换 USB 口 / 换粗线 / 检查天线");
        }
        if (wasOn) startWeb();
        return;
    }
    // Web-only AP: no radio dependency, ignores the role, SSID is always W16-WEB.
    // Use it to tell "WiFi is broken" from "the role flow is broken": if W16-WEB shows up the
    // radio side is the problem, otherwise it is hardware.
    if (!strcmp(s, "web")) {
        if (gWifiOn) { stopWeb(); return; }
        gSsidOverride = "W16-WEB";
        Serial.println("[CMD] 纯网页热点 W16-WEB / 12345678 (与射频、角色都无关)");
        startWeb();
        return;
    }
    if (!strcmp(s, "wifi")) {
        if (gRole == ROLE_IDLE) { Serial.println("[CMD] 先输入 tx 或 rx"); return; }
        if (gWifiOn) stopWeb(); else startWeb();
        return;
    }
    if (!strncmp(s, "ch ", 3)) {
        int v = atoi(s + 3);
        // 12 and 13 are rejected by softAP() unless the country code allows them, and the
        // ESP32 default (cc=01) only permits 1~11, so the input range stops there too.
        if (v < 0 || v > 11) { Serial.println("[CMD] 信道 0~11 (0=自动 ch1)"); return; }
        gApChannel = (uint8_t)v;

        if (gApChannel == 0) {
            // 0 = automatic, no scanning, a restart applies it directly
            Serial.println("[CMD] 信道 -> 自动 ch1 (离 2450MHz 最远)");
        } else {
            Serial.print("[CMD] 信道 -> "); Serial.print((int)gApChannel);
            Serial.println(", 正在重开热点… (已记住, 重启不丢)");
        }
        // Store the channel in NVS so a tuned value survives a reboot
        prefs.begin("w16", false);
        prefs.putUChar("ch", gApChannel);
        prefs.end();

        if (gRole != ROLE_IDLE) {
            if (gWifiOn) stopWeb();
            startWeb();
        }
        return;
    }
    if (!strncmp(s, "power ", 6)) {
        int v = atoi(s + 6);
        if (v < 2 || v > 20) { Serial.println("[CMD] 功率 2~20 dBm (建议 5/8/11/15/20)"); return; }
        gApPowerDbm = (uint8_t)v;
        Serial.print("[CMD] 功率 -> "); Serial.print((int)gApPowerDbm);
        Serial.println("dBm, 正在重开热点… (已记住, 重启不丢)");
        // Store the power in NVS too
        prefs.begin("w16", false);
        prefs.putUChar("pw", gApPowerDbm);
        prefs.end();

        if (gRole != ROLE_IDLE) {
            if (gWifiOn) stopWeb();
            startWeb();
        }
        return;
    }
    if (!strcmp(s, "clear")) {
        txHasImage = false;
        txImgLen   = 0;
        Serial.println("[CMD] 已清除上传的图, 之后发送改用本机采集");
        return;
    }

    if (!strncmp(s, "gap ", 4)) {
        // The gap auto-tunes now, so this sets the ceiling it may climb to, not a fixed value.
        // Setting it also pulls the current value back to the floor so the change takes effect
        // immediately instead of after a few clean rounds.
        int v = atoi(s + 4);
        if (v >= GAP_MIN && v <= 200) { gGapMaxMs = (uint8_t)v; gChunkGapMs = GAP_MIN; }
        Serial.print("[CMD] 块间隔上限 "); Serial.print((int)gGapMaxMs);
        Serial.print("ms (当前 "); Serial.print((int)gChunkGapMs); Serial.println("ms, 自动收敛)");
        return;
    }
    if (!strncmp(s, "rounds ", 7)) {
        int v = atoi(s + 7);
        if (v >= 1 && v <= 255) { gMaxRounds = (uint8_t)v; }
        Serial.print("[CMD] 最多 "); Serial.print((int)gMaxRounds); Serial.println(" 轮");
        return;
    }
    if (!strncmp(s, "size ", 5)) {
#if (USE_CAMERA && CAM_LIB_OK)
        if (!gCamOk) { Serial.println("[CMD] 摄像头未就绪"); return; }
        sensor_t* sn = esp_camera_sensor_get();
        if (!sn) return;
        const char* v = s + 5;
        framesize_t fs = FRAMESIZE_QVGA;
        if      (!strcmp(v, "qqvga")) fs = FRAMESIZE_QQVGA;
        else if (!strcmp(v, "qvga"))  fs = FRAMESIZE_QVGA;
        else if (!strcmp(v, "vga"))   fs = FRAMESIZE_VGA;
        else if (!strcmp(v, "svga"))  fs = FRAMESIZE_SVGA;
        else { Serial.println("[CMD] 可选 qqvga/qvga/vga/svga"); return; }
        sn->set_framesize(sn, fs);
        Serial.print("[CMD] 分辨率 -> "); Serial.println(v);
#else
        Serial.println("[CMD] 当前是合成图模式, 无分辨率可设");
#endif
        return;
    }

    Serial.print("[CMD] 未知指令: "); Serial.println(s);
    Serial.println("       输入 help 看列表");
}

void pollSerial() {
    static char line[40];
    static uint8_t n = 0;
    while (Serial.available()) {
        char c = (char)Serial.read();
        if (c == '\r') continue;
        if (c == '\n') {
            line[n] = 0;
            if (n) handleCommand(line);
            n = 0;
        } else if (n < sizeof(line) - 1) {
            line[n++] = (char)tolower((int)c);
        }
    }
}

// ==================== Main loop ====================
void loop() {
    pollSerial();

    // Button: on board A BOOT takes a photo at once; on board B it acts as the page button
    static bool pttPrev = true;
    bool ptt = (digitalRead(PIN_PTT) == LOW);
    if (ptt && !pttPrev) {
        if (gRole == ROLE_TX)      { gSendReq = true;     Serial.println("[KEY] 拍照发送"); }
        else if (gRole == ROLE_RX) { gWantCapture = true; Serial.println("[KEY] 请求拍照"); }
    }
    pttPrev = ptt;

    if (gRole == ROLE_RX) {
        // Drain the radio FIRST, and only then think about HTTP. The RX FIFO holds exactly one
        // packet and one handleClient() can block 3~10ms - that is 2~4 chunks at a 1ms gap, and
        // it used to be spent on every single /status poll of the page. Serving HTTP only when
        // the link has gone quiet turns "every poll costs chunks" into "polling is free".
        // The 300ms ceiling stops the page from starving if the air stays busy.
        static uint32_t lastWeb = 0;
        static uint32_t lastPkt = 0;

        PhotoPacket p;
        if (rxPoll(&p)) {
            lastPkt = millis();
            handleRxPacket(p);
        }

        uint32_t now = millis();
        bool quiet = (uint32_t)(now - lastPkt) > 40;
        if (gWifiOn && (uint32_t)(now - lastWeb) >= 20 &&
            (quiet || (uint32_t)(now - lastWeb) >= 300)) {
            webServer.handleClient();
            lastWeb = millis();
        }

        if (gWantCapture) {
            gWantCapture = false;
            requestCapture();
        }
        return;
    }

    if (gRole == ROLE_TX) {
        // Board A also runs an AP, so HTTP must be served here or the upload page never loads
        if (gWifiOn) webServer.handleClient();

        if (gSendReq) {
            gSendReq = false;
            // fresh=true: capture a new image unless an uploaded one exists
            sendPhoto(true);
            enterRx();          // Back to "waiting for requests" after sending
            ledBlue();
            return;
        }

        // Idle: listen for board B's PKT_REQ and drain the noise
        PhotoPacket p;
        if (rxPoll(&p)) {
            if (p.type == PKT_REQ) {
                Serial.println("[TX] 收到 B 板重发请求");
                // fresh=false: reuse the image in imgBuf, do not capture again
                sendPhoto(false);
                enterRx();
                ledBlue();
            }
        }
        return;
    }

    delay(5);   // IDLE
}

// ==================== setup ====================
void setup() {
    // ---- USB-CDC serial hardening (important) ----
    // CDCOnBoot=Enabled, so Serial is USB-CDC (HWCDC) with a 256-byte TX ring by default.
    // Printing help (~800 bytes) at once overflows it and bytes are dropped: UTF-8 gets cut in
    // half, lines vanish, blank lines appear. The buffer must be enlarged, and setTxBufferSize()
    // only works before begin() (begin() allocates the ring).
#if defined(ARDUINO_USB_CDC_ON_BOOT) && ARDUINO_USB_CDC_ON_BOOT
    Serial.setTxBufferSize(4096);
#endif
    Serial.begin(115200);
#if defined(ARDUINO_USB_CDC_ON_BOOT) && ARDUINO_USB_CDC_ON_BOOT
    Serial.setTxTimeoutMs(100);        // Wait for the host instead of dropping bytes when the ring is full
    unsigned long tWait = millis();
    while (!Serial && millis() - tWait < 2000) delay(10);   // wait for the serial monitor
#endif
    delay(200);

    pinMode(PIN_PTT, INPUT_PULLUP);
    ledOff();

    Serial.println();
    Serial.println("=== W16 (LR2021) Photo over FLRC + Web ===");

    // Reset reason: if the AP drops during an upload because the board rebooted, this tells
    // brownout / panic / watchdog apart without guessing.
    {
        const char* why = "其他";
        esp_reset_reason_t rr = esp_reset_reason();
        switch (rr) {
            case ESP_RST_POWERON:   why = "上电"; break;
            case ESP_RST_SW:        why = "软件复位(烧录后正常)"; break;
            case ESP_RST_PANIC:     why = "程序崩溃(panic)! 上次跑挂了"; break;
            case ESP_RST_INT_WDT:   why = "中断看门狗复位!"; break;
            case ESP_RST_TASK_WDT:  why = "任务看门狗复位!"; break;
            case ESP_RST_WDT:       why = "看门狗复位!"; break;
            case ESP_RST_BROWNOUT:  why = "欠压复位! 供电不足实锤, 换粗线/换USB口/独立供电"; break;
            case ESP_RST_DEEPSLEEP: why = "深度睡眠唤醒"; break;
            default: break;
        }
        Serial.print("[INIT] 复位原因: "); Serial.println(why);
    }

    // AP station join/leave events with MAC, so it is visible who actually connected (a phone
    // reconnecting to a saved network triggers it too).
    WiFi.onEvent([](WiFiEvent_t event, WiFiEventInfo_t info) {
        const uint8_t* m = info.wifi_ap_staconnected.mac;
        char buf[18];
        snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X",
                 m[0], m[1], m[2], m[3], m[4], m[5]);
        Serial.print("[WEB] 手机已连上热点 ✓ MAC="); Serial.println(buf);
    }, ARDUINO_EVENT_WIFI_AP_STACONNECTED);
    WiFi.onEvent([](WiFiEvent_t event, WiFiEventInfo_t info) {
        const uint8_t* m = info.wifi_ap_stadisconnected.mac;
        char buf[18];
        snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X",
                 m[0], m[1], m[2], m[3], m[4], m[5]);
        Serial.print("[WEB] 手机从热点断开 ✗ MAC="); Serial.println(buf);
    }, ARDUINO_EVENT_WIFI_AP_STADISCONNECTED);

    Serial.print("[CFG] 单包 "); Serial.print((unsigned int)sizeof(PhotoPacket));
    Serial.print(" 字节 (头 11 + 数据 "); Serial.print(PHOTO_CHUNK);
    Serial.println(")");
    Serial.print("[CFG] 最多 "); Serial.print(PHOTO_MAX_CHUNKS);
    Serial.print(" 块, 单图上限 "); Serial.print(PHOTO_MAX_CHUNKS * PHOTO_CHUNK);
    Serial.println(" 字节");

    // Image buffer: PSRAM first (8MB on XIAO ESP32S3), internal heap as fallback.
    // 47KB next to WiFi is comfortable, but if it still does not fit, halve the ceiling
    // instead of leaving the feature dead.
    imgBuf = (uint8_t*)ps_malloc(IMG_BUF_CAP);
    if (!imgBuf) imgBuf = (uint8_t*)malloc(IMG_BUF_CAP);
    if (!imgBuf) {
        gMaxChunks = PHOTO_MAX_CHUNKS / 2;
        imgBuf = (uint8_t*)malloc((size_t)gMaxChunks * PHOTO_CHUNK + 64);
        if (imgBuf) {
            Serial.print("[INIT] 分配失败, 退回 "); Serial.print(gMaxChunks);
            Serial.println(" 块");
        }
    }
    if (!imgBuf) {
        Serial.println("[INIT] 图片缓冲分配失败, 功能不可用");
    } else {
        Serial.print("[INIT] 图片缓冲 "); Serial.print((unsigned int)((size_t)gMaxChunks * PHOTO_CHUNK));
        Serial.print(" 字节 @ ");
        Serial.println(psramFound() ? "PSRAM" : "内部 RAM");
    }

    initCamera();

    // !! This line cannot be omitted !!
    // RadioLib Module::init() only calls the parameterless SPI.begin(), and the ESP32-S3
    // defaults are SCK=12 / MISO=13 / MOSI=11 / SS=10 while this board is
    // SCK=12 / MISO=11 / MOSI=10 - MISO and MOSI are swapped. The chip then answers
    // intermittently: beginFLRC() returns -707 (CMD_FAIL) and startReceive() flips between
    // -707 and -2 (CHIP_NOT_FOUND). Create the bus here with the real pins first; mod->init()
    // then reuses it.
    SPI.begin(PIN_SCK, PIN_MISO, PIN_MOSI);

    if (!beginRadio()) {
        gRadioOk = false;
        Serial.println("[INIT] 射频初始化失败, 请检查接线");
        Serial.println("[INIT] 引脚: SCK=12 MISO=11 MOSI=10 NSS=47 RST=39 BUSY=21 DIO7=42");
        Serial.println("[INIT] 注意: 射频失败不影响热点! 输 tx/rx 或 web 照样能开 WiFi");
        Serial.println("[INIT]       只是图片发不出去, 网页拍照/选图/看图都正常");
    } else {
        gRadioOk = true;
    }

    // Boot into IDLE by default, but restore the role and bring the AP up when tx/rx was
    // stored before, so a configured board is reachable right after boot.
    // ch / power are read back from NVS too, so a tuned channel survives a reboot.
    gRole = ROLE_IDLE;
    if (gRadioOk) radio.standby();

    uint8_t savedRole = 255;
    prefs.begin("w16", true);
    savedRole   = prefs.getUChar("role", 255);
    gApChannel  = prefs.getUChar("ch",  gApChannel);   // default 0 = automatic when unset
    // A channel saved by an older build (12/13) makes softAP() fail three times and leaves the
    // board with no AP at all, so drop it back to automatic instead of honouring it.
    if (gApChannel > 11) gApChannel = 0;
    gApPowerDbm = prefs.getUChar("pw",  gApPowerDbm);  // keep default 15 when unset
    prefs.end();
    if (gApPowerDbm < 2 || gApPowerDbm > 20) gApPowerDbm = 15;   // guard against bad data

    if (savedRole == (uint8_t)ROLE_TX || savedRole == (uint8_t)ROLE_RX) {
        Serial.println("[INIT] 恢复上次角色并自动开热点 (idle 可退回)");
        switchRole((Role)savedRole);
    } else {
        Serial.println("[INIT] OK  当前 IDLE: 输入 tx / rx 开始 (之后上电自动恢复)");
        Serial.println("[INIT]   A 板输 tx -> 热点 W16-SEND   B 板输 rx -> 热点 W16-PHOTO");
    }
    printHelp();
}
