#include <RadioLib.h>

#define PIN_SCK     12
#define PIN_MISO    11
#define PIN_MOSI    10
#define PIN_NSS     47
#define PIN_DIO7    42
#define PIN_NRESET  39
#define PIN_BUSY    21
#define PIN_LED     48    // WS2812 RGB LED

struct BandConfig {
    const char* name;
    float freq;           // MHz
    float bw;             // kHz
    uint8_t sf;           // Spreading factor
    uint8_t cr;           // Coding rate
    int8_t power;         // dBm (Sub-G max 22, 2.4G max 12)
};

BandConfig bands[] = {
    {"Sub-G", 868.0,  125.0, 12, 5, 22},
    {"Sub-G", 915.0,  125.0, 12, 5, 22},
    {"2.4G",  2450.0, 250.0, 12, 5, 12},
};
const int NUM_BANDS = sizeof(bands) / sizeof(bands[0]);

enum RadioMode { MODE_IDLE = 0, MODE_RX = 1, MODE_TX = 2 };

int currentBand = 0;              // default Sub-G 868MHz
RadioMode currentMode = MODE_IDLE; // power-on default: idle (standby)

Module mod(PIN_NSS, PIN_DIO7, PIN_NRESET, PIN_BUSY);
LR2021 radio(&mod);

volatile bool txFlag = false;
volatile bool rxFlag = false;

#include <esp32-hal-rgb-led.h>

void ledGreen()  { neopixelWrite(PIN_LED, 0, 8, 0); }
void ledRed()    { neopixelWrite(PIN_LED, 8, 0, 0); }
void ledBlue()   { neopixelWrite(PIN_LED, 0, 0, 8); }
void ledOff()    { neopixelWrite(PIN_LED, 0, 0, 0); }

void blinkRed(int times, int onMs, int offMs) {
    for (int i = 0; i < times; i++) {
        ledRed(); delay(onMs);
        ledOff(); if (i < times - 1) delay(offMs);
    }
}

void blinkGreen(int times, int onMs, int offMs) {
    for (int i = 0; i < times; i++) {
        ledGreen(); delay(onMs);
        ledOff(); if (i < times - 1) delay(offMs);
    }
}

unsigned int txCount = 0;
unsigned int rxCount = 0;
unsigned int errCount = 0;
int8_t activePower = 22;      // actual TX power; 2.4G may be derated by the chip

void printBandInfo(int idx) {
    Serial.print("  ");
    Serial.print(bands[idx].name);
    Serial.print("  Freq="); Serial.print(bands[idx].freq, 1); Serial.print("MHz");
    Serial.print("  BW=");   Serial.print(bands[idx].bw, 0);   Serial.print("kHz");
    Serial.print("  SF");    Serial.print((int)bands[idx].sf);
    Serial.print("  CR4/");  Serial.print((int)bands[idx].cr);
    Serial.print("  Power="); Serial.print((int)bands[idx].power); Serial.println("dBm");
}

void printHelp() {
    Serial.println("Commands (type and press Enter):");
    Serial.println("  868rx / 915rx / 2.4rx    switch band + RX mode");
    Serial.println("  868tx / 915tx / 2.4tx    switch band + TX mode");
    Serial.println("  868 / 915 / 2.4g         switch band only (keep current mode)");
    Serial.println("  idle / stop              stop RX/TX, back to standby (idle)");
    Serial.println("  help / ?                 show this list");
    Serial.println("  (2.4rx also accepts 2.4grx / 2400rx / 2450rx)");
}

const char* modeName(RadioMode m) {
    if (m == MODE_RX) return "RX";
    if (m == MODE_TX) return "TX";
    return "IDLE";
}

void printConfig() {
    Serial.print("[CFG] Mode=");
    Serial.print(modeName(currentMode));
    Serial.print("  Band=");
    Serial.print(bands[currentBand].name);
    Serial.print(" "); Serial.print(bands[currentBand].freq, 1); Serial.print("MHz");
    Serial.print("  BW"); Serial.print(bands[currentBand].bw, 0); Serial.print("kHz");
    Serial.print("  SF"); Serial.print((int)bands[currentBand].sf);
    Serial.print("  CR4/"); Serial.print((int)bands[currentBand].cr);
    Serial.print("  Power="); Serial.print((int)activePower); Serial.print("dBm");
    if (activePower != bands[currentBand].power) {
        Serial.print(" (目标 "); Serial.print((int)bands[currentBand].power); Serial.print("dBm)");
    }
    Serial.println();
}

void printTxLog(const String& msg, const String& status) {
    Serial.print("#"); Serial.print(txCount);
    Serial.print("  "); Serial.print(msg);
    Serial.print("  "); Serial.print(bands[currentBand].name);
    Serial.print(" "); Serial.print(bands[currentBand].freq, 1); Serial.print("MHz");
    Serial.print("  "); Serial.println(status);
}

#if defined(RADIOLIB_VERSION_MAJOR) && (RADIOLIB_VERSION_MAJOR >= 8)
  #define FREQ_HZ(mhz) ((uint32_t)((double)(mhz) * 1000000.0))
  #define BW_HZ(khz)   ((uint32_t)((double)(khz) * 1000.0))
#else
  #define FREQ_HZ(mhz) (mhz)     // 7.x takes MHz / kHz floats
  #define BW_HZ(khz)   (khz)
#endif

static int16_t beginLoRa(float freqMHz, float bwKHz, uint8_t sf, uint8_t cr, int8_t power) {
#if defined(RADIOLIB_VERSION_MAJOR) && (RADIOLIB_VERSION_MAJOR >= 8)
    radio.tcxoVoltage = Voltage1V8;              // 7.x passed this as the 8th argument
    ConfigLoRa_t cfg;
    cfg.frequency       = FREQ_HZ(freqMHz);
    cfg.bandwidth       = BW_HZ(bwKHz);
    cfg.spreadingFactor = sf;
    cfg.codingRate      = cr;
    cfg.syncWord        = RADIOLIB_LORA_SYNC_WORD_PRIVATE;   // 0x12, same as before
    cfg.power           = power;
    cfg.preambleLength  = 8;
    return radio.begin(cfg);
#else
    return radio.begin(freqMHz, bwKHz, sf, cr,
                       RADIOLIB_LR2021_LORA_SYNC_WORD_PRIVATE, power, 8, 1.8);
#endif
}

bool applyBandParams(int idx) {
    if (idx < 0 || idx >= NUM_BANDS) return false;

    radio.irqDioNum = 7;

    // 1) Try a full begin() on the target band first (power set to a safe 10dBm)
    int16_t state = beginLoRa(bands[idx].freq, bands[idx].bw,
                              bands[idx].sf, bands[idx].cr, 10);
    if (state != RADIOLIB_ERR_NONE) {
        // 2) Fallback (common on 2.4G): begin on Sub-G, then setFrequency to the target band.
        //    This path is expected, so no error is printed - otherwise -706 floods the log.
        state = beginLoRa(915.0, 125.0, 7, 5, 10);
        if (state != RADIOLIB_ERR_NONE) {
            Serial.print("[CFG] begin FAIL - err="); Serial.println(state);
            return false;
        }
    }
    radio.setFrequency(FREQ_HZ(bands[idx].freq));
    radio.setSpreadingFactor(bands[idx].sf);
    radio.setBandwidth(BW_HZ(bands[idx].bw));
    radio.setCodingRate(bands[idx].cr);
    radio.standby();
    delay(50);

    radio.setOutputPower(bands[idx].power);
    activePower = bands[idx].power;
    return true;
}

bool startRx() {
    rxFlag = false;
    int16_t state = radio.startReceive();
    if (state != RADIOLIB_ERR_NONE) {
        Serial.print("[RX] startReceive FAIL - err="); Serial.println(state);
        return false;
    }
    return true;
}

bool enterMode(RadioMode mode) {
    if (mode == MODE_RX) {
        return startRx();
    }
    radio.finishReceive();
    txFlag = false;
    rxFlag = false;
    return true;
}

void setIdle() {
    if (currentMode == MODE_RX) {
        radio.finishReceive();
    } else {
        radio.standby();
    }
    delay(50);

    currentMode = MODE_IDLE;
    txFlag = false;
    rxFlag = false;

    printConfig();
    Serial.println("[CFG] IDLE (standby) - type 868rx / 915tx ... to start");
    blinkGreen(1, 200, 0);
    ledOff();
}

bool fullReinit() {
    if (!applyBandParams(currentBand)) {
        Serial.println("[INIT] re-init FAIL");
        return false;
    }
    return enterMode(currentMode);
}

bool switchConfig(int idx, RadioMode mode) {
    if (idx < 0 || idx >= NUM_BANDS) return false;

    int prevBand = currentBand;
    RadioMode prevMode = currentMode;

    if (prevMode == MODE_RX) {
        radio.finishReceive();          // standby + clear IRQ flags
    } else {
        radio.standby();
    }
    delay(50);

    if (!applyBandParams(idx)) {
        Serial.println("[CFG] apply FAILED, restore previous config");
        applyBandParams(prevBand);
        enterMode(prevMode);
        blinkRed(3, 100, 100);
        if (prevMode == MODE_RX) ledBlue();
        return false;
    }

    currentBand = idx;
    currentMode = mode;
    txCount = 0;
    rxCount = 0;
    errCount = 0;

    if (!enterMode(mode)) {
        Serial.println("[CFG] enter mode FAILED, full re-init");
        if (!fullReinit()) {
            Serial.println("[CFG] re-init FAILED, restore previous config");
            currentBand = prevBand;
            currentMode = prevMode;
            applyBandParams(prevBand);
            enterMode(prevMode);
            blinkRed(5, 100, 100);
            return false;
        }
    }

    printConfig();
    blinkGreen(1, 200, 0);
    if (mode == MODE_RX) ledBlue();     // Blue steady while listening
    else if (mode == MODE_IDLE) ledOff();
    return true;
}

void switchBandOnly(int idx) {
    if (idx == currentBand) {
        Serial.print("[CFG] Already on ");
        Serial.print(bands[idx].name);
        Serial.print(" ");
        Serial.print(bands[idx].freq, 1);
        Serial.println("MHz");
        return;
    }
    switchConfig(idx, currentMode);
}

String cmdBuf;

int bandIndexFromToken(const String& s) {
    if (s == "868") return 0;
    if (s == "915") return 1;
    if (s == "2.4" || s == "2.4g" || s == "24" || s == "2400" || s == "2450") return 2;
    return -1;
}

void handleCommand(String raw) {
    raw.trim();
    raw.toLowerCase();
    if (raw.length() == 0) return;

    if (raw == "help" || raw == "?") {
        printHelp();
        return;
    }

    if (raw == "idle" || raw == "stop") {
        setIdle();
        return;
    }

    // Parse the rx / tx mode suffix
    bool hasMode = false;
    RadioMode mode = MODE_TX;
    String body = raw;

    if (raw.endsWith("rx")) {
        hasMode = true;
        mode = MODE_RX;
        body = raw.substring(0, raw.length() - 2);
    } else if (raw.endsWith("tx")) {
        hasMode = true;
        mode = MODE_TX;
        body = raw.substring(0, raw.length() - 2);
    }
    body.trim();

    int idx = bandIndexFromToken(body);
    if (idx < 0) {
        Serial.print("[CMD] unknown command: ");
        Serial.println(raw);
        Serial.println("      valid: 868rx / 915rx / 2.4rx / 868tx / 915tx / 2.4tx / idle / help");
        return;
    }

    if (hasMode) {
        switchConfig(idx, mode);        // Switch band + mode
    } else {
        switchBandOnly(idx);            // Switch band only
    }
}

void pollSerial() {
    while (Serial.available() > 0) {
        char c = Serial.read();
        if (c == '\r' || c == '\n') {
            if (cmdBuf.length() > 0) {
                // Echo the command line so the log shows what was actually typed
                Serial.print("> ");
                Serial.println(cmdBuf);
                handleCommand(cmdBuf);
                cmdBuf = "";
            }
        } else if (c >= 32 && c <= 126) {
            if (cmdBuf.length() < 16) cmdBuf += c;
        }
    }
}

void idleWait(unsigned long ms) {
    RadioMode modeAtEntry = currentMode;
    unsigned long start = millis();
    while (millis() - start < ms) {
        pollSerial();
        if (currentMode != modeAtEntry) return;
        delay(10);
    }
}

void setup() {
    Serial.begin(115200);
    delay(3000);  // ESP32-S3 native USB CDC: wait for the monitor to enumerate so boot logs are not lost

    Serial.println("\n=== LR2021 Ping-Pong Test ===");
    for (int i = 0; i < NUM_BANDS; i++) printBandInfo(i);
    Serial.println();

    SPI.begin(PIN_SCK, PIN_MISO, PIN_MOSI);

    radio.irqDioNum = 7;

    Serial.print("[INIT] Radio...");
    int state = beginLoRa(915.0, 125.0, 7, 5, 10);

    if (state != RADIOLIB_ERR_NONE) {
        Serial.print(" FAIL - begin() err="); Serial.println(state);
        blinkRed(10, 100, 100);
        while (true) delay(10);
    }
    Serial.println(" OK");

#if defined(RADIOLIB_VERSION_MAJOR) && (RADIOLIB_VERSION_MAJOR >= 8)
    Serial.print("[INIT] RadioLib ");
    Serial.print(RADIOLIB_VERSION_MAJOR); Serial.print(".");
    Serial.print(RADIOLIB_VERSION_MINOR); Serial.print(".");
    Serial.println(RADIOLIB_VERSION_PATCH);
#else
    uint8_t fwMaj = 0, fwMin = 0;
    if (radio.getVersion(&fwMaj, &fwMin) == RADIOLIB_ERR_NONE) {
        Serial.print("[INIT] FW version: ");
        Serial.print((int)fwMaj); Serial.print(".");
        Serial.print((int)fwMin);
        Serial.println(fwMaj == 1 ? "  (LR2021)" : "  (LR2022 / LR2012)");
    }
#endif

    if (!applyBandParams(currentBand)) {
        Serial.println("[INIT] applyBandParams FAILED");
        blinkRed(10, 100, 100);
        while (true) delay(10);
    }
    Serial.println("[INIT] PASS - Module initialized");

    if (!enterMode(currentMode)) {
        Serial.println("[INIT] enterMode FAILED");
        blinkRed(10, 100, 100);
        while (true) delay(10);
    }
    radio.standby();

    printConfig();
    Serial.println("[CFG] IDLE (standby) - type 868rx / 915tx ... to start");
    Serial.println();
    printHelp();
    Serial.println();

    ledOff();
    Serial.println("--- Ping-Pong Test Ready ---\n");
}

void loopRx() {
    if (!rxFlag) {
        if (radio.getIrqFlags() & RADIOLIB_LR2021_IRQ_RX_DONE) {
            rxFlag = true;
        } else {
            return;
        }
    }
    rxFlag = false;

    String received;
    int state = radio.readData(received);

    if (state == RADIOLIB_ERR_NONE) {
        rxCount++;
        float rssi = radio.getRSSI();
        float snr  = radio.getSNR();

        Serial.print("#"); Serial.print(rxCount);
        Serial.print("  "); Serial.print(bands[currentBand].name);
        Serial.print(" "); Serial.print(bands[currentBand].freq, 1); Serial.print("MHz");
        Serial.print("  RSSI="); Serial.print(rssi, 1); Serial.print("dBm");
        Serial.print("  SNR=");  Serial.print(snr, 1);  Serial.print("dB");
        Serial.print("  Data："); Serial.println(received);

        blinkGreen(1, 100, 0);
        ledBlue();
    } else {
        errCount++;
        Serial.print("#"); Serial.print(rxCount);
        Serial.print("  ReadData FAIL - err="); Serial.println(state);
        blinkRed(3, 100, 100);
        ledBlue();
    }

    // Restart RX to keep listening
    radio.standby();
    delay(50);
    if (!startRx()) {
        Serial.println("[RX] restart FAILED, full re-init");
        fullReinit();
    }
}

void loopTx() {
    txCount++;
    txFlag = false;
    String msg = "hello" + String(txCount);
    int state = radio.startTransmit(msg);

    if (state != RADIOLIB_ERR_NONE) {
        errCount++;
        printTxLog(msg, "FAIL - err=" + String(state));
        radio.finishTransmit();
        blinkRed(5, 100, 100);
        ledBlue();
        idleWait(2000);
        return;
    }

    unsigned long txTimeout = millis() + 5000;
    while (!txFlag && millis() < txTimeout) {
        if (radio.getIrqFlags() & RADIOLIB_LR2021_IRQ_TX_DONE) {
            txFlag = true;
            break;
        }
        delay(1);
    }
    radio.finishTransmit();

    if (!txFlag) {
        errCount++;
        printTxLog(msg, "TIMEOUT");
        blinkRed(5, 100, 100);
        ledBlue();
        idleWait(2000);
        return;
    }

    printTxLog(msg, "OK");

    // Green blink on success
    ledGreen(); delay(100); ledBlue();

    idleWait(2000);  // 2s interval, serial commands accepted meanwhile
}

void loop() {
    pollSerial();

    if (currentMode == MODE_IDLE) {
        delay(10);
        return;
    }

    if (currentMode == MODE_RX) {
        loopRx();
    } else {
        loopTx();
    }

    delay(10);
}
