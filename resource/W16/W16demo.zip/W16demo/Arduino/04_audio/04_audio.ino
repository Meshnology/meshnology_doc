#include <RadioLib.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <esp32-hal-rgb-led.h>
#include <ctype.h>

#define PIN_SCK     12
#define PIN_MISO    11
#define PIN_MOSI    10
#define PIN_NSS     47
#define PIN_DIO7    42
#define PIN_NRESET  39
#define PIN_BUSY    21
#define PIN_LED     48    // WS2812 RGB LED

#define SAMPLE_RATE       8000                                   // Hz
#define FRAME_MS          20                                     // frame duration
#define SAMPLES_PER_FRAME ((SAMPLE_RATE * FRAME_MS) / 1000)       // 160 samples
#define ADPCM_BYTES       (SAMPLES_PER_FRAME / 2)                 // 80 bytes

#define FLRC_FREQ         2450.0f       // MHz (FLRC is 2.4GHz only)
#define FLRC_BR           650
#define FLRC_POWER        12            // dBm (2.4G max 12)
#define FLRC_PRE          32

#define PKT_TX_TIMEOUT    120           // Max wait for TX_DONE per packet (ms)

#define TX_HOLD_MS        600

#define MIC_RING_CAP      4096          // bytes (= 1.024s @ 4KB/s)
#define MIC_RING_MAX      2400          // bytes (= 600ms)
#define MIC_RING_KEEP     800           // bytes (= 200ms)

#define PCM_RING_SAMPLES  8000          // samples (= 1s @ 8kHz, 16KB)

// ==================== WiFi AP ====================
#define AP_SSID_TX      "W16-MIC"
#define AP_SSID_RX      "W16-SPK"
#define AP_PASS         "12345678"      // at least 8 chars
#define WEB_PORT        80

struct __attribute__((packed)) AudioPacket {
    uint16_t seq;                  // sequence number (loss detection)
    uint8_t  len;                  // ADPCM byte count (0 = silence frame)
    uint8_t  data[ADPCM_BYTES];
};

enum Role { ROLE_IDLE = 0, ROLE_TX = 1, ROLE_RX = 2 };

Role gRole = ROLE_IDLE;

Module mod(PIN_NSS, PIN_DIO7, PIN_NRESET, PIN_BUSY);
LR2021 radio(&mod);

volatile bool gStreaming = false;   // board A: streaming out at 50 frames/s
volatile bool gUseTone   = false;   // board A: send the built-in 1kHz tone instead of phone audio
volatile bool gTxWanted  = false;   // first uplink chunk while armed -> let loop() start streaming

uint16_t txSeq      = 0;            // air packet sequence
uint32_t txFrames   = 0;
uint32_t txUnderrun = 0;            // ring underruns (the phone cannot keep up)
uint32_t txMicBytes = 0;            // ADPCM bytes received from the phone
uint32_t txMicDrops = 0;            // bytes dropped on ring overflow
uint32_t txLastMicMs = 0;           // last phone audio timestamp (release detection)
uint32_t pushReqs    = 0;           // number of POST /push requests (diagnostics)

uint16_t rxLastSeq  = 0;
bool     rxSeqInit  = false;
uint32_t rxFrames   = 0;
uint32_t rxLost     = 0;            // total lost frames
uint32_t rxPackets  = 0;
uint32_t rxNoise    = 0;
uint32_t rxOtherErr = 0;
bool     rxSilent   = true;
unsigned long lastErrPrint = 0;

// stats window
uint32_t txStatMs = 0, txPrevFrames = 0;
uint32_t txPrevMicBytes = 0;
uint32_t rxStatMs = 0, rxPrevFrames = 0;
uint32_t rxPrevNoise = 0, rxPrevOther = 0;   // report deltas when idle instead of absolute values
uint32_t rxPrevLost  = 0;
uint32_t rxSrvMaxUs  = 0;                    // longest webServer.handleClient() call in this window
bool     rxIdleLogged = false;               // print the "listening" line only once

// Power-on default is IDLE (radio in standby, no AP). The board only starts doing
// something when "mic" / "spk" is typed - same convention as 01_rx / 02_tx / 03_pingpong.
// `auto` can be switched on to resume the last role at every boot; it is off by default
// so that a freshly flashed board never opens a hotspot or streams on its own.
uint8_t  gAutoRestore = 0;

bool gRadioOk = false;

bool gWifiOn = false;
WebServer webServer(WEB_PORT);

uint8_t gApChannel    = 0;
uint8_t gApChannelNow = 6;
uint8_t gApClients    = 0;
uint8_t gApPowerDbm   = 15;     // AP TX power: raise when the signal is weak, lower when the boards sit too close

const char* gSsidOverride = nullptr;

Preferences prefs;

void ledGreen() { neopixelWrite(PIN_LED, 0, 8, 0); }
void ledRed()   { neopixelWrite(PIN_LED, 8, 0, 0); }
void ledBlue()  { neopixelWrite(PIN_LED, 0, 0, 8); }
void ledOff()   { neopixelWrite(PIN_LED, 0, 0, 0); }

void blinkRed(int times) {
    for (int i = 0; i < times; i++) { ledRed(); delay(60); ledOff(); delay(60); }
}

static const int8_t imaIndexTable[16] = {
    -1, -1, -1, -1, 2, 4, 6, 8,
    -1, -1, -1, -1, 2, 4, 6, 8
};

static const int16_t imaStepTable[89] = {
        7,     8,     9,    10,    11,    12,    13,    14,
       16,    17,    19,    21,    23,    25,    28,    31,
       34,    37,    41,    45,    50,    55,    60,    66,
       73,    80,    88,    97,   107,   118,   130,   143,
      157,   173,   190,   209,   230,   253,   279,   307,
      337,   371,   408,   449,   494,   544,   598,   658,
      724,   796,   876,   963,  1060,  1166,  1282,  1411,
     1552,  1707,  1878,  2066,  2272,  2499,  2749,  3024,
     3327,  3660,  4026,  4428,  4871,  5358,  5894,  6484,
     7132,  7845,  8630,  9493, 10442, 11487, 12635, 13899,
    15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794,
    32767
};

static int    decPred  = 0;
static int8_t decIndex = 0;

void adpcmDecReset() { decPred = 0; decIndex = 0; }

static inline int16_t adpcmDecodeSample(uint8_t code) {
    int step = imaStepTable[decIndex];
    int vpdiff = step >> 3;
    if (code & 4) vpdiff += step;
    if (code & 2) vpdiff += step >> 1;
    if (code & 1) vpdiff += step >> 2;

    if (code & 8) decPred -= vpdiff; else decPred += vpdiff;
    if (decPred > 32767)  decPred = 32767;
    if (decPred < -32768) decPred = -32768;

    decIndex += imaIndexTable[code & 0x0F];
    if (decIndex < 0)  decIndex = 0;
    if (decIndex > 88) decIndex = 88;

    return (int16_t)decPred;
}

void adpcmDecodeFrame(const uint8_t* in, int bytes, int16_t* pcm) {
    for (int i = 0; i < bytes; i++) {
        uint8_t b = in[i];
        pcm[2 * i]     = adpcmDecodeSample(b & 0x0F);
        pcm[2 * i + 1] = adpcmDecodeSample((b >> 4) & 0x0F);
    }
}

static int16_t beginFlrc() {
#if defined(RADIOLIB_VERSION_MAJOR) && (RADIOLIB_VERSION_MAJOR >= 8)
    radio.tcxoVoltage = Voltage1V8;            // 7.x passed this as the 7th argument
    ConfigFLRC_t cfg;
    cfg.frequency      = (uint32_t)(FLRC_FREQ * 1000000.0f);   // Hz
    cfg.bitRate        = (uint32_t)FLRC_BR * 1000;             // bps
    cfg.codingRate     = RADIOLIB_LR2021_FLRC_CR_1_2;
    cfg.power          = FLRC_POWER;
    cfg.preambleLength = FLRC_PRE;
    cfg.dataShaping    = RADIOLIB_SHAPING_0_5;
    return radio.beginFLRC(cfg);
#else
    return radio.beginFLRC(FLRC_FREQ, FLRC_BR,
                           RADIOLIB_LR2021_FLRC_CR_1_2,
                           FLRC_POWER, FLRC_PRE,
                           RADIOLIB_SHAPING_0_5, 1.8);
#endif
}

bool beginRadio() {
    radio.irqDioNum = 7;

    int16_t st = RADIOLIB_ERR_CHIP_NOT_FOUND;
    for (int attempt = 1; attempt <= 3; attempt++) {
        st = beginFlrc();
        if (st == RADIOLIB_ERR_NONE || st == RADIOLIB_ERR_SPI_CMD_INVALID) break;
        Serial.print("[RADIO] 第"); Serial.print(attempt);
        Serial.print("次初始化失败 err="); Serial.println(st);
        delay(80);
    }

    bool needPatch = (st == RADIOLIB_ERR_SPI_CMD_INVALID);
    if (needPatch) {
        Serial.println("[RADIO] WARN 2.4G PA 被拒(-706), 补设被跳过的 FLRC 参数");
    } else if (st != RADIOLIB_ERR_NONE) {
        Serial.print("[RADIO] beginFLRC FAIL - err="); Serial.println(st);
        if (st == RADIOLIB_ERR_CHIP_NOT_FOUND) {
            Serial.println("[RADIO]   -2 = 芯片没应答: 查 SPI 引脚(MISO/MOSI 是否接反)、3V3、NSS、复位脚");
        } else if (st == RADIOLIB_ERR_SPI_CMD_FAILED) {
            Serial.println("[RADIO]   -707 = 芯片回了 CMD_FAIL: 多为 SPI 总线错位/时钟过快, 或 TCXO 未起振");
        } else if (st == RADIOLIB_ERR_SPI_CMD_INVALID) {
            Serial.println("[RADIO]   -706 = 命令参数被拒");
        }
        return false;
    }

    if (needPatch) {
        int16_t s2 = radio.setPreambleLength(FLRC_PRE);
        int16_t s3 = radio.setDataShaping(RADIOLIB_SHAPING_0_5);
        uint8_t sync[] = { 0x2D, 0x01, 0x4B, 0x1D };
        int16_t s4 = radio.setSyncWord(sync, 4);
        int16_t s5 = radio.setCRC(2);
        Serial.print("[RADIO] 补设 pre="); Serial.print(s2);
        Serial.print(" shape="); Serial.print(s3);
        Serial.print(" sync=");  Serial.print(s4);
        Serial.print(" crc=");   Serial.println(s5);
    }

    int16_t s1 = radio.fixedPacketLengthMode(sizeof(AudioPacket));
    if (s1 != RADIOLIB_ERR_NONE) {
        Serial.print("[RADIO] fixedPacketLengthMode FAIL - err="); Serial.println(s1);
        return false;
    }

    radio.standby();
    Serial.print("[RADIO] OK  FLRC ");
    Serial.print(FLRC_FREQ, 1); Serial.print("MHz ");
    Serial.print(FLRC_BR);      Serial.print("kbps CR1/2 pre=");
    Serial.print(FLRC_PRE);     Serial.print(" pkt=");
    Serial.println((unsigned int)sizeof(AudioPacket));
    return true;
}

bool enterRx() {
    if (!gRadioOk) return false;
    radio.standby();
    delay(2);
    int16_t st = radio.startReceive();
    if (st != RADIOLIB_ERR_NONE) {
        // Must throttle: one line at 115200 takes ~30ms and flooding stalls the main loop
        if (millis() - lastErrPrint > 1000) {
            Serial.print("[RF] startReceive FAIL - err="); Serial.println(st);
            lastErrPrint = millis();
        }
        return false;
    }
    return true;
}

bool sendPkt(const AudioPacket& p) {
    if (!gRadioOk) return false;
    int16_t st = radio.startTransmit((const uint8_t*)&p, sizeof(p));
    if (st != RADIOLIB_ERR_NONE) {
        if (millis() - lastErrPrint > 1000) {
            Serial.print("[RF] startTransmit FAIL - err="); Serial.println(st);
            lastErrPrint = millis();
        }
        radio.standby();     // Return to a sane state after an error, otherwise the next packet fails too
        return false;
    }

    unsigned long t0 = millis();
    bool done = false;
    while (millis() - t0 < PKT_TX_TIMEOUT) {
        if (radio.getIrqFlags() & RADIOLIB_LR2021_IRQ_TX_DONE) { done = true; break; }
        delay(0);
    }
    radio.finishTransmit();
    return done;
}

bool rxPoll(AudioPacket* p) {
    if (!gRadioOk) return false;
    if (!(radio.getIrqFlags() & RADIOLIB_LR2021_IRQ_RX_DONE)) return false;

    size_t len = radio.getPacketLength();
    if (len < 3 || len > sizeof(AudioPacket)) {
        enterRx();
        return false;
    }

    int16_t st = radio.readData((uint8_t*)p, len);
    if (st != RADIOLIB_ERR_NONE) {
        if (st == RADIOLIB_ERR_CRC_MISMATCH) rxNoise++;
        else                                 rxOtherErr++;
        return false;
    }
    rxPackets++;
    return true;
}

static uint8_t  micRing[MIC_RING_CAP];
static uint16_t micHead = 0;      // write index
static uint16_t micTail = 0;      // read index
static uint16_t micUsed = 0;

void micPush(const uint8_t* p, size_t n) {
    for (size_t i = 0; i < n; i++) {
        if (micUsed >= MIC_RING_CAP) {
            // When full drop the oldest: live audio would rather lose old data than build up delay
            micTail = (uint16_t)((micTail + 1) % MIC_RING_CAP);
            micUsed--;
            txMicDrops++;
        }
        micRing[micHead] = p[i];
        micHead = (uint16_t)((micHead + 1) % MIC_RING_CAP);
        micUsed++;
    }
    txMicBytes += (uint32_t)n;

    if (micUsed > MIC_RING_MAX) {
        uint16_t drop = (uint16_t)(micUsed - MIC_RING_KEEP);
        micTail = (uint16_t)((micTail + drop) % MIC_RING_CAP);
        micUsed -= drop;
        txMicDrops += drop;
    }
}

bool micPop(uint8_t* out, size_t n) {
    if (micUsed < n) return false;
    for (size_t i = 0; i < n; i++) {
        out[i] = micRing[micTail];
        micTail = (uint16_t)((micTail + 1) % MIC_RING_CAP);
        micUsed--;
    }
    return true;
}

void micClear() {
    micHead = micTail = 0;
    micUsed = 0;
}

static float synthPhase = 0.0f;

static void synthFill(int16_t* pcm, int n) {
    const float w = 2.0f * PI * 1000.0f / (float)SAMPLE_RATE;   // 1kHz phase step
    for (int i = 0; i < n; i++) {
        pcm[i] = (int16_t)(8000.0f * sinf(synthPhase));
        synthPhase += w;
        if (synthPhase >= 2.0f * PI) synthPhase -= 2.0f * PI;
    }
}

static int    encPred  = 0;
static int8_t encIndex = 0;

static inline uint8_t adpcmEncodeSample(int16_t sample) {
    int step = imaStepTable[encIndex];
    int diff = (int)sample - encPred;
    uint8_t code = 0;
    if (diff < 0) { code = 8; diff = -diff; }

    int vpdiff = step >> 3;
    if (diff >= step)        { code |= 4; diff -= step;        vpdiff += step; }
    if (diff >= (step >> 1)) { code |= 2; diff -= (step >> 1); vpdiff += (step >> 1); }
    if (diff >= (step >> 2)) { code |= 1;                      vpdiff += (step >> 2); }

    if (code & 8) encPred -= vpdiff; else encPred += vpdiff;
    if (encPred > 32767)  encPred = 32767;
    if (encPred < -32768) encPred = -32768;

    encIndex += imaIndexTable[code];
    if (encIndex < 0)  encIndex = 0;
    if (encIndex > 88) encIndex = 88;

    return code & 0x0F;
}

static void adpcmEncodeFrame(const int16_t* pcm, int n, uint8_t* out) {
    for (int i = 0; i < n; i += 2) {
        uint8_t lo = adpcmEncodeSample(pcm[i]);
        uint8_t hi = adpcmEncodeSample(pcm[i + 1]);
        out[i >> 1] = (uint8_t)((lo & 0x0F) | (hi << 4));
    }
}

static void txStatsTick() {
    uint32_t now  = millis();
    uint32_t dt   = now - txStatMs;
    uint32_t dMic = txMicBytes - txPrevMicBytes;

    if (!gUseTone && dMic == 0) return;
    if (dt < 2000) return;

    uint32_t d  = txFrames - txPrevFrames;
    float fps = (float)d * 1000.0f / (float)dt;

    Serial.print("[STAT] TX  ");
    Serial.print(fps, 1); Serial.print("帧/s  ");
    Serial.print("缓存 "); Serial.print((int)micUsed); Serial.print("B(");
    Serial.print((int)((uint32_t)micUsed * FRAME_MS / ADPCM_BYTES)); Serial.print("ms)");
    Serial.print("  欠载 "); Serial.print((int)txUnderrun);
    Serial.print("  溢出丢 "); Serial.print((int)txMicDrops); Serial.print("B");
    Serial.println();

    txPrevFrames   = txFrames;
    txPrevMicBytes = txMicBytes;
    txStatMs       = now;
}

void micStream() {
    gStreaming = true;
    gTxWanted  = false;          // Already streaming, do not let loop() trigger it again
    txSeq = 0;
    ledRed();

    Serial.print("[TX] 发流开始 (音源: ");
    Serial.print(gUseTone ? "内置 1kHz 测试音" : "手机麦克风");
    Serial.println(")");

    radio.standby();
    delay(2);

    uint32_t nextUs = micros();
    txStatMs = millis();
    txPrevFrames = txFrames;
    txPrevMicBytes = txMicBytes;
    if (!gUseTone) {
        uint32_t t0 = millis();
        while (micUsed < ADPCM_BYTES * 3 && millis() - t0 < 300 && gRole == ROLE_TX) {
            if (gWifiOn) webServer.handleClient();
            pollSerial();
            delay(5);
        }
    }

    int16_t tonePcm[SAMPLES_PER_FRAME];
    AudioPacket p;
    int starve = 0;                       // consecutive slots with nothing to send

    while (gStreaming && gRole == ROLE_TX) {
        pollSerial();                              // allow "idle" in the middle
        if (gWifiOn) webServer.handleClient();     // drain audio pushed by the phone

        memset(&p, 0, sizeof(p));
        p.seq = txSeq;
        bool haveFrame = true;

        if (gUseTone) {
            synthFill(tonePcm, SAMPLES_PER_FRAME);
            adpcmEncodeFrame(tonePcm, SAMPLES_PER_FRAME, p.data);
            p.len = ADPCM_BYTES;
        } else if (micPop(p.data, ADPCM_BYTES)) {
            p.len = ADPCM_BYTES;
            starve = 0;
        } else {
            haveFrame = false;
            txUnderrun++;
            starve++;
        }

        if (haveFrame) {
            sendPkt(p);
            txSeq++;
            txFrames++;
        } else if (starve > 40) {
            Serial.println("[TX] 上行中断 800ms, 结束本次发流");
            break;
        }

        nextUs += (uint32_t)FRAME_MS * 1000UL;
        while ((int32_t)(nextUs - micros()) > 0) {
            if (gWifiOn) webServer.handleClient();
            pollSerial();
        }
        if ((int32_t)(nextUs - micros()) < -20000) nextUs = micros();   // far behind: resync

        txStatsTick();

        if (!gUseTone && (millis() - txLastMicMs > TX_HOLD_MS)) {
            Serial.println("[TX] 手机停止推流 -> 暂停发流 (再按住会自动继续)");
            break;
        }
    }

    gStreaming = false;
    gTxWanted  = false;

    if (gRole == ROLE_TX) {
        radio.standby();
        delay(2);
        ledOff();
    }
    Serial.print("[TX] 发流暂停, 累计 ");
    Serial.print((int)txFrames);
    Serial.println(" 帧");
}

static int16_t  pcmRing[PCM_RING_SAMPLES];
static uint32_t pcmHead = 0;

void pcmWrite(const int16_t* s, int n) {
    for (int i = 0; i < n; i++) {
        pcmRing[pcmHead % PCM_RING_SAMPLES] = s[i];
        pcmHead++;
    }
}

void pcmWriteSilence(int n) {
    for (int i = 0; i < n; i++) {
        pcmRing[pcmHead % PCM_RING_SAMPLES] = 0;
        pcmHead++;
    }
}

static int16_t lastFramePcm[SAMPLES_PER_FRAME];
static uint8_t concealPct = 100;            // percent of the last frame still being replayed

void pcmConceal(int n) {
    for (int i = 0; i < n; i++) {
        int16_t v = (int16_t)(((int32_t)lastFramePcm[i % SAMPLES_PER_FRAME] * concealPct) / 100);
        pcmRing[pcmHead % PCM_RING_SAMPLES] = v;
        pcmHead++;
        if ((i % SAMPLES_PER_FRAME) == SAMPLES_PER_FRAME - 1) {
            concealPct = (concealPct > 25) ? (uint8_t)(concealPct - 25) : 0;
        }
    }
}

void handleRxPacket(const AudioPacket& pkt) {
    if (pkt.len > ADPCM_BYTES) return;

    if (!rxSeqInit) {
        rxSeqInit = true;
        rxLastSeq = pkt.seq;
        adpcmDecReset();
    } else if (pkt.seq != (uint16_t)(rxLastSeq + 1)) {
        int16_t gap = (int16_t)(pkt.seq - rxLastSeq - 1);
        if (gap > 0 && gap < 50) {          // normal loss: conceal it, keep the decoder state
            rxLost += (uint32_t)gap;
            int fill = gap * SAMPLES_PER_FRAME;
            if (fill > PCM_RING_SAMPLES / 2) fill = PCM_RING_SAMPLES / 2;   // never pad more than half a second at once
            pcmConceal(fill);
        } else {
            adpcmDecReset();
            concealPct = 0;
        }
        rxLastSeq = pkt.seq;
    } else {
        rxLastSeq = pkt.seq;
    }

    if (pkt.len == 0) {
        pcmWriteSilence(SAMPLES_PER_FRAME);
        rxFrames++;
        return;
    }

    int16_t pcm[ADPCM_BYTES * 2];
    adpcmDecodeFrame(pkt.data, pkt.len, pcm);
    pcmWrite(pcm, pkt.len * 2);

    int src = pkt.len * 2;
    for (int i = 0; i < SAMPLES_PER_FRAME; i++) lastFramePcm[i] = pcm[i % src];
    concealPct = 100;

    rxFrames++;
    ledGreen();

    if (rxSilent) {
        rxSilent = false;
        Serial.println("[RX] 收到语音流, 链路建立");
        ledBlue();
    }
}

void rxStatsTick() {
    uint32_t now = millis();
    uint32_t dt  = now - rxStatMs;
    uint32_t d   = rxFrames - rxPrevFrames;

    if (d > 0) {
        if (dt < 2000) return;
        float fps = (float)d * 1000.0f / (float)dt;

        uint32_t dLost  = rxLost - rxPrevLost;
        uint32_t dNoise = rxNoise - rxPrevNoise;
        uint32_t dOther = rxOtherErr - rxPrevOther;
        uint32_t total  = d + dLost + dNoise + dOther;      // frames the peer actually sent
        float lossPct   = total ? 100.0f * (float)(dLost + dNoise + dOther) / (float)total : 0.0f;

        Serial.print("[STAT] RX  ");
        Serial.print(fps, 1); Serial.print("帧/s  ");
        Serial.print("收 "); Serial.print((int)d);
        Serial.print("  丢 "); Serial.print((int)dLost);
        Serial.print(" (");    Serial.print(lossPct, 0); Serial.print("%)");
        Serial.print("  噪 "); Serial.print((int)dNoise);
        Serial.print("  其他 "); Serial.print((int)dOther);
        Serial.print("  最长服务 "); Serial.print((int)(rxSrvMaxUs / 1000)); Serial.print("ms");
        Serial.println();

        rxPrevFrames = rxFrames;
        rxPrevLost   = rxLost;
        rxPrevNoise  = rxNoise;
        rxPrevOther  = rxOtherErr;
        rxSrvMaxUs   = 0;
        rxStatMs     = now;
        return;
    }

    if (dt < 2000) return;

    if (!rxSilent) {
        rxSilent = true;
        Serial.println("[RX] 语音中断, 继续 Listening......");
        ledBlue();
    }

    rxPrevFrames = rxFrames;
    rxPrevLost   = rxLost;
    rxPrevNoise  = rxNoise;
    rxPrevOther  = rxOtherErr;
    rxSrvMaxUs   = 0;
    rxStatMs     = now;
}

static const char PAGE_MIC[] PROGMEM = R"rawliteral(
<!DOCTYPE html><html lang="zh-CN"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
<title>W16 对讲 · 麦克风</title>
<style>
  :root{--bg:#0e1116;--fg:#e8edf5;--dim:#8b95a7;--acc:#38bdf8;--ok:#34d399;--warn:#fbbf24;--red:#f87171}
  *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
  body{margin:0;background:var(--bg);color:var(--fg);
       font:14px/1.5 -apple-system,"Segoe UI",system-ui,"Microsoft YaHei",sans-serif}
  .wrap{max-width:620px;margin:0 auto;padding:18px}
  h1{font-size:17px;margin:0 0 4px;font-weight:600}
  h1 span{color:var(--dim);font-weight:400;font-size:12px;margin-left:8px}
  .sub{color:var(--dim);font-size:12px;margin-bottom:16px}
  .ptt{width:100%;padding:0;height:180px;border-radius:18px;border:2px solid #263040;
       background:radial-gradient(circle at 50% 40%,#1b2531,#11161d);
       color:var(--fg);font-size:20px;font-weight:600;letter-spacing:2px;cursor:pointer;
       transition:transform .08s,border-color .15s,background .15s;user-select:none;
       -webkit-user-select:none;-webkit-touch-callout:none;
       /* touch-action is essential: without it Chrome treats a press-and-hold as a scroll
          gesture and fires pointercancel, so nothing happens at all. */
       touch-action:none}
  .ptt:active,.ptt.on{border-color:#ef4444;
       background:radial-gradient(circle at 50% 40%,#3b1214,#1a0d0e);transform:scale(.985)}
  .ptt small{display:block;font-size:12px;font-weight:400;color:var(--dim);margin-top:8px;letter-spacing:0}
  .meter{height:10px;border-radius:6px;background:#161b23;overflow:hidden;margin-top:16px}
  .meter i{display:block;height:100%;width:0;background:linear-gradient(90deg,#22c55e,#eab308,#ef4444);
           transition:width .06s linear}
  .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:14px}
  .grid div{background:#161b23;border-radius:10px;padding:10px 8px;text-align:center}
  .grid b{display:block;font-size:17px;color:var(--ok);font-variant-numeric:tabular-nums}
  .grid small{display:block;color:var(--dim);font-size:11px;margin-top:2px}
  .msg{margin-top:16px;padding:12px 14px;border-radius:10px;font-size:13px;line-height:1.7;display:none}
  .msg.show{display:block}
  .msg.err{background:#2a1416;border:1px solid #7f1d1d;color:#fecaca}
  .msg.info{background:#0f1c24;border:1px solid #164e63;color:#bae6fd}
  .msg code{background:#000;padding:1px 5px;border-radius:4px;color:var(--warn);
            font-size:12px;word-break:break-all}
  .tip{color:var(--dim);font-size:12px;margin-top:18px;line-height:1.8}
  .dbg{margin-top:10px;padding:8px 10px;border-radius:8px;background:#12161d;
       border:1px solid #1f2733;color:var(--dim);font-size:11px;line-height:1.7;
       font-family:ui-monospace,Consolas,monospace;word-break:break-all}
</style></head><body>
<div class="wrap">
  <h1>W16 对讲 <span id="who">A 板 · 麦克风端</span></h1>
  <div class="sub" id="sub">按住下面的按钮说话，声音会经 2.4G 送到对面</div>

  <button class="ptt" id="ptt">按住 说 话<small>松开即停止发送</small></button>

  <div class="meter"><i id="lvl"></i></div>

  <div class="grid">
    <div><b id="gRate">0</b><small>上行 KB/s</small></div>
    <div><b id="gFrame">0</b><small>已发帧</small></div>
    <div><b id="gLat">0</b><small>缓存 ms</small></div>
  </div>

  <div class="dbg" id="dbg">初始化…</div>

  <div class="msg err" id="err"></div>
  <div class="msg info" id="info"></div>

  <p class="tip">
    音质是 8kHz / ADPCM 4bit，电话水平 —— 这条链路只有约 4KB/s。<br>
    松开按钮后会有约 0.4 秒尾音，那是缓冲里还没发完的数据，正常。
  </p>
</div>
<script>
var SR = 8000, FRAME = 160, ABYTES = 80;   // 与板端一致
var PAGE_VER = '7';                        // 页面版本：串口会打印，用来识别浏览器缓存
var IMA_INDEX = [-1,-1,-1,-1,2,4,6,8,-1,-1,-1,-1,2,4,6,8];
var IMA_STEP = [7,8,9,10,11,12,13,14,16,17,19,21,23,25,28,31,34,37,41,45,50,55,60,66,
  73,80,88,97,107,118,130,143,157,173,190,209,230,253,279,307,337,371,408,449,494,544,
  598,658,724,796,876,963,1060,1166,1282,1411,1552,1707,1878,2066,2272,2499,2749,3024,
  3327,3660,4026,4428,4871,5358,5894,6484,7132,7845,8630,9493,10442,11487,12635,13899,
  15289,16818,18500,20350,22385,24623,27086,29794,32767];

var encPred = 0, encIndex = 0;
function encReset(){ encPred = 0; encIndex = 0; hpIn = 0; hpOut = 0; }

function encSample(s){
  var step = IMA_STEP[encIndex];
  var diff = s - encPred, code = 0;
  if (diff < 0) { code = 8; diff = -diff; }
  var vpdiff = step >> 3;
  if (diff >= step)        { code |= 4; diff -= step;        vpdiff += step; }
  if (diff >= (step >> 1)) { code |= 2; diff -= (step >> 1); vpdiff += (step >> 1); }
  if (diff >= (step >> 2)) { code |= 1;                      vpdiff += (step >> 2); }
  if (code & 8) encPred -= vpdiff; else encPred += vpdiff;
  if (encPred > 32767)  encPred = 32767;
  if (encPred < -32768) encPred = -32768;
  encIndex += IMA_INDEX[code];
  if (encIndex < 0) encIndex = 0;
  if (encIndex > 88) encIndex = 88;
  return code & 15;
}

var actx = null, srcNode = null, proc = null, stream = null;
var talking = false;
var pending = [];          // 待上传的 ADPCM 字节
var pendingLen = 0;
var inflight = false;
var PEND_MAX = 24000;      // 6s of backlog: beyond that the link is slower than realtime

// Page self-check: when press-to-talk does nothing, this line shows which step failed
var micReady = false, micRate = 0, micErr = '';
var pushes = 0, pushFails = 0, lastCode = 0, held = false, statusOk = false;
var framesMade = 0;                 // 采集+编码了多少帧（0 = onaudioprocess 根本没跑）
var lastFrameSeen = 0, noFrameTicks = 0;
var dbgBoard = { streaming:false, micBytes:0, frames:0, pushReq:0 };

// Resampling phase accumulator (48k / 44.1k in -> 8k out)
var accSum = 0, accN = 0, accPhase = 0;
var pcmAcc = [];           // 攒够 160 个样本再编码
var level = 0;

// ---- Software AGC ----
// The phone's own 'autoGainControl' is unreliable - on many Android builds it is a no-op.
// Speech then arrives around -25dBFS while a knock on the table hits 0dBFS. 4-bit ADPCM
// spends its whole code range on that quiet speech, and the far end hears clicks only.
// Normalise before encoding: attack instantly, release over ~200ms.
var agcGain = 1.0, agcPeak = 0;

function agcUpdate(peak){
  if (peak > agcPeak) agcPeak = peak;                 // attack immediately
  else agcPeak = agcPeak * 0.85 + peak * 0.15;        // release slowly
  var target = 0.55;                                  // aim at about -5dBFS
  // Below about -48dBFS there is no speech, only the room: hold the gain instead of
  // winding it up to the ceiling, otherwise every pause is filled with 8x amplified hiss.
  var want = (agcPeak > 0.004) ? target / agcPeak : agcGain;
  if (want > 8) want = 8;
  if (want < 1) want = 1;
  agcGain = agcGain * 0.6 + want * 0.4;               // ~150ms to settle
}

// One-pole high-pass at about 120Hz, run at 8kHz. A phone mic carries a DC offset and a
// lot of handling rumble; both sit in the ADPCM predictor and steal code range from the
// speech, which is heard as a low buzz under everything.
var hpIn = 0, hpOut = 0, HP_A = 0.910;

function showErr(html){
  var e = document.getElementById('err');
  e.innerHTML = html; e.classList.add('show');
}
function hideErr(){ document.getElementById('err').classList.remove('show'); }

function checkSecure(){
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    showErr('<b>浏览器不允许使用麦克风</b><br>' +
      '当前页面是 <code>http://192.168.4.1</code>，不属于"安全上下文"，' +
      'Chrome 会直接禁用麦克风。<br><br>' +
      '<b>解决办法（Android / 电脑 Chrome，一次设置永久有效）：</b><br>' +
      '1. 新开一个标签页，地址栏输入 <code>chrome://flags/#unsafely-treat-insecure-origin-as-secure</code><br>' +
      '2. 在输入框里填 <code>http://192.168.4.1</code><br>' +
      '3. 右边选 <b>Enabled</b>，点底部 <b>Relaunch</b> 重启浏览器<br>' +
      '4. 重新连热点打开本页<br><br>' +
      'iPhone 的 Safari 没有这个开关，请用 iPhone 当"喇叭端"（B 板）。');
    return false;
  }
  return true;
}

async function startMic(){
  micErr = '';
  try {
    // The context was closed by the system (rare): rebuild everything
    if (actx && actx.state === 'closed') { actx = null; srcNode = null; proc = null; stream = null; }
    if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)();

    // !! The most common cause of 'press and nothing is sent' !!
    // Android Chrome suspends the AudioContext (background, lock screen, long idle).
    // Once suspended, onaudioprocess never fires - no samples are captured,
    // pending stays 0, so not a single /push goes out and the serial log stays quiet.
    // So resume() on every press and verify it really reached 'running'.
    if (actx.state !== 'running') {
      try { await actx.resume(); } catch(e) {}
    }
    if (actx.state !== 'running') {
      micErr = 'AudioContext=' + actx.state;
      showErr('<b>音频上下文没启动</b>（state=' + actx.state + '）<br>' +
        '再按一次按钮，或刷新页面重试。');
      return false;
    }

    if (!stream) {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: { channelCount:1, echoCancellation:true, noiseSuppression:true, autoGainControl:true }
      });
    }
    if (!proc) {
      srcNode = actx.createMediaStreamSource(stream);
      // ScriptProcessor is deprecated, but it is the most compatible and shortest option
      proc = actx.createScriptProcessor(2048, 1, 1);
      proc.onaudioprocess = onAudio;
      srcNode.connect(proc);
      proc.connect(actx.destination);   // 必须连到 destination 才会被驱动（输出静音）
    }
    micReady = true;
    micRate = actx.sampleRate;
    hideErr();
    document.getElementById('sub').textContent = '麦克风已就绪，按住按钮说话';
    return true;
  } catch (e) {
    micErr = (e && e.name ? e.name : String(e));
    showErr('<b>打开麦克风失败：</b>' + micErr + '<br>' +
      '请确认已允许本站使用麦克风；若没有弹窗，按上面 4 步打开 Chrome 白名单。');
    return false;
  }
}

function onAudio(e){
  var inp = e.inputBuffer.getChannelData(0);
  var ratio = actx.sampleRate / SR;      // 48000/8000 = 6，44100/8000 = 5.51

  var peak = 0;
  for (var k = 0; k < inp.length; k++) {
    var p = inp[k];
    if (p > peak) peak = p; else if (-p > peak) peak = -p;
  }
  agcUpdate(peak);

  for (var i = 0; i < inp.length; i++) {
    accSum += inp[i]; accN++; accPhase += 1;
    if (accPhase >= ratio) {             // 块平均降采样，比线性插值少混叠
      accPhase -= ratio;
      var x = accSum / accN;
      accSum = 0; accN = 0;
      var y = HP_A * (hpOut + x - hpIn);
      hpIn = x; hpOut = y;
      var s = Math.max(-32768, Math.min(32767, Math.round(y * agcGain * 32767)));
      pcmAcc.push(s);
      if (pcmAcc.length >= FRAME) encodeFrame();
    }
  }
  level = level * 0.7 + Math.min(1, peak * agcGain) * 0.3;
  document.getElementById('lvl').style.width = Math.min(100, level * 140) + '%';
}

function encodeFrame(){
  framesMade++;
  var out = new Uint8Array(ABYTES);
  for (var i = 0; i < FRAME; i += 2) {
    var lo = encSample(pcmAcc[i]);
    var hi = encSample(pcmAcc[i + 1]);
    out[i >> 1] = (lo & 15) | (hi << 4);
  }
  pcmAcc.length = 0;
  if (!talking) return;                  // 没按住就不上传（但编码器状态继续走）
  for (var k = 0; k < ABYTES; k++) pending.push(out[k]);
  pendingLen += ABYTES;
  // Backlog guard: if the link really is slower than realtime, drop the oldest audio
  // rather than let the delay grow without bound (the far end would hear everything late).
  if (pendingLen > PEND_MAX) {
    var drop = pendingLen - 4000;
    pending.splice(0, drop);
    pendingLen -= drop;
  }
}

// The upload must be multipart/form-data:
// ESP32 WebServer only creates an upload context (_currentUpload) for multipart.
// With application/octet-stream the core takes the raw() branch and reuses the
// same callback, so webServer.upload() gets a null pointer -> LoadProhibited crash.
function pushForm(u8){
  var fd = new FormData();
  fd.append('f', new Blob([u8]), 'p.bin');
  return fd;
}

var lastSendMs = 0;
// The page can never push faster than it captures, so the push path runs at 1.0x realtime
// at best. This loop is stop-and-wait: one POST, wait for the reply, send the next. Every
// millisecond of dead time between the reply and the next POST is a millisecond the board's
// ring spends draining, and the deficit shows up on the far end as underruns.
// Two things used to add exactly that dead time - a "wait for a 60ms batch" gate and a
// 10ms timer after each reply - which capped the push at about 75% of realtime. The ring
// drained, the receiver's playback buffer ran dry every ~100ms, and each restart inserted
// an 80ms hole: that periodic chopping is the low buzz that was left.
// So: send everything queued, and chain the next POST straight onto the reply.
// Buffering 120ms before the first POST gives the ring a lead that absorbs the jitter.
var LEAD = 480;            // bytes (= 120ms)
var lead = 0;

function pump(){
  if (inflight) { setTimeout(pump, 10); return; }
  if (lead > 0) {
    if (pendingLen < lead) { setTimeout(pump, 10); return; }
    lead = 0;
  }
  if (pendingLen <= 0) { setTimeout(pump, 10); return; }
  var take = Math.min(pendingLen, 4096);
  var chunk = new Uint8Array(pending.splice(0, take));
  pendingLen -= take;
  inflight = true;
  lastSendMs = Date.now();
  fetch('/push', {method:'POST', body: pushForm(chunk)})
    .then(function(r){
      lastCode = r.status;
      if (r.ok) pushes++; else pushFails++;     // 400 = 板子不认 multipart
      return null;
    })
    .catch(function(){ pushFails++; })
    .then(function(){ inflight = false; pump(); });   // chain at once, keep the pipe full
}

function setTalking(on){
  if (on === talking) return;
  talking = on;
  document.getElementById('ptt').classList.toggle('on', on);
  if (!on) {
    // Release: flush the remaining data, then tell the board to clear its buffer -
    // otherwise the tail of this sentence runs into the next one (stuck audio).
    var rest = pending.splice(0, pending.length);
    pendingLen = 0;
    var done = rest.length ? fetch('/push', {method:'POST',
        body: pushForm(new Uint8Array(rest))}) : Promise.resolve();
    done.catch(function(){}).then(function(){ return fetch('/flush', {method:'POST'}); }).catch(function(){});
  } else {
    encReset();          // 每次开口重新对齐编码器，避免残留状态
    pending = []; pendingLen = 0;
    lead = LEAD;         // rebuild the ring lead before the first POST of this press
  }
}

var btn = document.getElementById('ptt');

// Pitfall: the first getUserMedia call shows a permission prompt and can take a second.
// Awaiting it inside pointerdown means the finger is already up -
// talking stays true forever, or this press never starts pushing at all.
// 'held' tracks whether the finger is still down and decides afterwards.
btn.addEventListener('pointerdown', async function(ev){
  ev.preventDefault();
  held = true;
  try { btn.setPointerCapture(ev.pointerId); } catch(e) {}
  btn.classList.add('on');
  renderDbg();
  var ok = await startMic();
  if (!ok) { held = false; btn.classList.remove('on'); renderDbg(); return; }
  if (held) setTalking(true);
  renderDbg();
});
function release(){ held = false; btn.classList.remove('on'); setTalking(false); renderDbg(); }
btn.addEventListener('pointerup',     function(ev){ ev.preventDefault(); release(); });
btn.addEventListener('pointercancel', release);
// Do not listen to pointerleave - it fires on the slightest move and cuts the speech.
// setPointerCapture keeps pointerup coming even when the finger leaves the button.
window.addEventListener('blur', release);

function renderDbg(){
  var l1 = '页面v' + PAGE_VER + ' · 麦克风 ' + (micReady ? ('就绪 ' + micRate + 'Hz')
                                          : (micErr ? ('失败 ' + micErr) : '未开启'));
  l1 += ' · 按住 ' + (talking ? '是' : '否');
  l1 += ' · 采样 ' + framesMade + ' 帧';
  l1 += ' · 已推 ' + pushes + ' 批';
  if (pushFails) l1 += ' 失败' + pushFails + '(HTTP ' + lastCode + ')';

  var l2;
  if (!statusOk) {
    l2 = '板子 /status 无响应 (热点连上了但网页接口不通)';
  } else {
    l2 = '板子 收到请求 ' + (dbgBoard.pushReq | 0) + ' 次 · 已收 '
       + (dbgBoard.micBytes | 0) + 'B · ' + (dbgBoard.streaming ? '发流中' : '待发');
  }
  document.getElementById('dbg').innerHTML = l1 + '<br>' + l2;
}

function poll(){
  // Report the page state with the request: the board prints one [UI] line per change,
  // so a dead button can be traced to 'no event' / 'mic off' / 'upload failed'.
  var q = '/status?v=' + PAGE_VER
        + '&t=' + (talking ? 1 : 0)
        + '&m=' + (micReady ? 1 : 0)
        + '&p=' + pushes
        + '&f=' + pushFails
        + '&c=' + lastCode
        + '&n=' + framesMade;
  fetch(q, {cache:'no-store'}).then(function(r){ return r.json(); }).then(function(j){
    document.getElementById('gRate').textContent = j.kbs.toFixed(1);
    document.getElementById('gFrame').textContent = j.frames;
    document.getElementById('gLat').textContent = Math.round(j.bufMs);
    dbgBoard = j;
    statusOk = true;
    if (j.mode !== 'TX') {
      showErr('板子当前不是发送角色，请在串口输入 <code>mic</code>');
    }
    // Pressed but no frames captured - the audio context was suspended, tell the user
    if (talking) {
      if (framesMade === lastFrameSeen) {
        noFrameTicks++;
        if (noFrameTicks >= 2) {
          document.getElementById('sub').textContent =
            '⚠ 麦克风没采到声音（页面被系统挂起？）松手再按一次';
        }
      } else {
        noFrameTicks = 0;
        lastFrameSeen = framesMade;
        document.getElementById('sub').textContent = '正在发送…';
      }
    } else {
      noFrameTicks = 0;
      lastFrameSeen = framesMade;
    }
    renderDbg();
  }).catch(function(){ statusOk = false; renderDbg(); })
    .then(function(){ setTimeout(poll, 800); });
}

if (!checkSecure()) {
  document.getElementById('ptt').style.opacity = .35;
}
renderDbg();
pump();
poll();
</script>
</body></html>
)rawliteral";

// ==================== Web page (board B: phone speaker) ====================
static const char PAGE_SPK[] PROGMEM = R"rawliteral(
<!DOCTYPE html><html lang="zh-CN"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
<title>W16 对讲 · 喇叭</title>
<style>
  :root{--bg:#0e1116;--fg:#e8edf5;--dim:#8b95a7;--acc:#38bdf8;--ok:#34d399}
  *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
  body{margin:0;background:var(--bg);color:var(--fg);
       font:14px/1.5 -apple-system,"Segoe UI",system-ui,"Microsoft YaHei",sans-serif}
  .wrap{max-width:620px;margin:0 auto;padding:18px}
  h1{font-size:17px;margin:0 0 4px;font-weight:600}
  h1 span{color:var(--dim);font-weight:400;font-size:12px;margin-left:8px}
  .sub{color:var(--dim);font-size:12px;margin-bottom:16px}
  .play{width:100%;height:150px;border-radius:18px;border:2px solid #263040;
        background:radial-gradient(circle at 50% 40%,#10202a,#0d1419);
        color:var(--fg);font-size:19px;font-weight:600;letter-spacing:2px;cursor:pointer;
        transition:transform .08s,border-color .15s}
  .play:active{transform:scale(.985)}
  .play.on{border-color:#0ea5e9;background:radial-gradient(circle at 50% 40%,#0b2d3d,#0a1720)}
  .vol{display:flex;align-items:center;gap:10px;margin-top:14px;color:var(--dim);font-size:12px}
  .vol label{white-space:nowrap}
  .vol b{color:var(--ok);font-variant-numeric:tabular-nums}
  .vol input{flex:1;accent-color:#0ea5e9}
  .play small{display:block;font-size:12px;font-weight:400;color:var(--dim);margin-top:8px;letter-spacing:0}
  .meter{height:10px;border-radius:6px;background:#161b23;overflow:hidden;margin-top:16px}
  .meter i{display:block;height:100%;width:0;background:linear-gradient(90deg,#22c55e,#eab308,#ef4444);
           transition:width .06s linear}
  .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:14px}
  .grid div{background:#161b23;border-radius:10px;padding:10px 8px;text-align:center}
  .grid b{display:block;font-size:17px;color:var(--ok);font-variant-numeric:tabular-nums}
  .grid small{display:block;color:var(--dim);font-size:11px;margin-top:2px}
  .msg{margin-top:16px;padding:12px 14px;border-radius:10px;font-size:13px;line-height:1.7;display:none}
  .msg.show{display:block}
  .msg.err{background:#2a1416;border:1px solid #7f1d1d;color:#fecaca}
  code{background:#000;padding:1px 5px;border-radius:4px;color:#fbbf24;font-size:12px}
  .tip{color:var(--dim);font-size:12px;margin-top:18px;line-height:1.8}
</style></head><body>
<div class="wrap">
  <h1>W16 对讲 <span id="who">B 板 · 喇叭端</span></h1>
  <div class="sub" id="sub">点一下开始播放（浏览器要求先有一次点击才允许出声）</div>

  <button class="play" id="play">开 始 播 放<small>点一下即可，之后自动连续播放</small></button>

  <div class="meter"><i id="lvl"></i></div>

  <div class="vol">
    <label for="rVol">输出音量 <b id="vVol">350%</b></label>
    <input type="range" id="rVol" min="100" max="800" step="50" value="350" oninput="setVol(this.value)">
  </div>

  <div class="grid">
    <div><b id="gFps">0</b><small>接收 帧/s</small></div>
    <div><b id="gLost">0</b><small>累计丢帧</small></div>
    <div><b id="gBuf">0</b><small>缓冲 ms</small></div>
  </div>

  <div class="msg err" id="err"></div>

  <p class="tip">
    第一次点"开始播放"是为了解锁浏览器的音频播放权限，之后不用再点。<br>
    声音小先拉上面的<b>输出音量</b>（最高 800%，超过 300% 会启动限幅，不会破音）。<br>
    仍然断续说明信号弱：把两块板靠近，或串口 <code>power 8</code> 降低热点功率。
  </p>
</div>
<script>
var SR = 8000;
var PAGE_VER = '7';       // 页面版本：串口会打印，用来识别浏览器缓存
var actx = null, gain = null, limiter = null, playTime = 0, running = false;
var vol = 3.5;            // playback gain, 1.0 = original level
var want = 0;             // 下一个想取的样本号
var level = 0;

function showErr(html){
  var e = document.getElementById('err');
  e.innerHTML = html; e.classList.add('show');
}

function setVol(v){
  vol = v / 100;
  if (gain) gain.gain.value = vol;
  document.getElementById('vVol').textContent = Math.round(v) + '%';
}

async function startPlay(){
  // Same trap as board A: the system suspends the AudioContext and src.start() goes silent.
  // So a second click must not return early, it has to resume() first.
  if (!actx) {
    actx = new (window.AudioContext || window.webkitAudioContext)();
    // An 8kHz ADPCM stream is far quieter than anything else on the phone, so the system
    // volume slider runs out of range before it gets loud. Boost it here - and put a
    // compressor after the gain, otherwise every boost above ~200% just clips.
    limiter = actx.createDynamicsCompressor();
    limiter.threshold.value = -10;
    limiter.knee.value = 12;
    limiter.ratio.value = 6;
    limiter.attack.value = 0.004;
    limiter.release.value = 0.15;
    limiter.connect(actx.destination);

    gain = actx.createGain();
    gain.gain.value = vol;
    gain.connect(limiter);
  }
  if (actx.state !== 'running') {
    try { await actx.resume(); } catch(e) {}
  }
  if (actx.state !== 'running') {
    showErr('<b>音频上下文没启动</b>（state=' + actx.state + '）<br>再点一次"开始播放"。');
    return;
  }
  running = true;
  playTime = 0;
  document.getElementById('play').classList.add('on');
  document.getElementById('play').innerHTML = '正 在 播 放<small>保持这个页面在前台</small>';
  document.getElementById('sub').textContent = '已开始播放，等待对方说话…';
  pull();
}

// Queue a block of PCM16 for playback
function enqueue(i16){
  var n = i16.length;
  if (!n) return;
  var buf = actx.createBuffer(1, n, SR);
  var ch = buf.getChannelData(0);
  var peak = 0;
  for (var i = 0; i < n; i++) {
    var v = i16[i] / 32768;
    ch[i] = v;
    if (v > peak) peak = v; else if (-v > peak) peak = -v;
  }
  var src = actx.createBufferSource();
  src.buffer = buf;
  src.connect(gain);

  var now = actx.currentTime;
  // Underrun (the playhead fell behind now): push it forward and restart. Keep the restart
  // gap small - it is heard as a hole, and a series of holes is what makes the far end
  // buzz instead of just sounding choppy.
  if (playTime < now + 0.03) playTime = now + 0.05;
  // Too much backlog: drop and re-queue, otherwise latency keeps growing
  if (playTime > now + 0.6)  playTime = now + 0.10;

  src.start(playTime);
  playTime += buf.duration;

  level = level * 0.7 + peak * 0.3;
  document.getElementById('lvl').style.width = Math.min(100, level * 140) + '%';
  document.getElementById('gBuf').textContent = Math.round((playTime - now) * 1000);
}

// Every /pcm request blocks the board for several ms, and while it is blocked the radio
// FIFO is not read - that costs roughly one audio frame per request. Re-fetching
// immediately after every successful response (setTimeout 0) turned into ~100 requests
// per second and threw away ~40% of the frames. Pull on a fixed cadence instead, and
// skip the request entirely while enough audio is already queued.
var PULL_MS = 30;                  // at most 33 requests/s
function pull(){
  if (!running) return;
  var ahead = playTime - actx.currentTime;        // seconds already queued
  if (ahead > 0.15) { setTimeout(pull, PULL_MS); return; }
  fetch('/pcm?since=' + want, {cache:'no-store'}).then(function(r){
    if (r.status !== 200) return null;
    return r.arrayBuffer();
  }).then(function(ab){
    if (!ab || ab.byteLength < 12) { setTimeout(pull, PULL_MS); return; }
    var dv = new DataView(ab);
    if (dv.getUint8(0) !== 87 || dv.getUint8(1) !== 65) { setTimeout(pull, PULL_MS); return; }
    var count = dv.getUint16(4);
    var start = dv.getUint32(6);
    if (start > want) {
      // The server says the requested samples were overwritten: jump to the oldest available
      want = start;
    }
    if (count > 0) {
      var i16 = new Int16Array(ab, 12, count);
      enqueue(i16);
      want = start + count;
    }
    setTimeout(pull, PULL_MS);
  }).catch(function(){ setTimeout(pull, 200); });
}

document.getElementById('play').addEventListener('click', startPlay);

function poll(){
  // Send v (page version) and r (playing): the board prints one line per change,
  // which tells 'not clicked' apart from 'clicked but audio not unlocked'.
  fetch('/status?v=' + PAGE_VER + '&r=' + (running ? 1 : 0), {cache:'no-store'}).then(function(r){ return r.json(); }).then(function(j){
    document.getElementById('gFps').textContent = j.fps.toFixed(1);
    document.getElementById('gLost').textContent = j.lost;
    if (j.mode !== 'RX') {
      showErr('板子当前不是接收角色，请在串口输入 <code>spk</code>');
    }
  }).catch(function(){}).then(function(){ setTimeout(poll, 1000); });
}
poll();
</script>
</body></html>
)rawliteral";

// ==================== Web handlers ====================
void handleIndex() {
    webServer.sendHeader("Cache-Control", "no-store");
    if (gRole == ROLE_TX) {
        webServer.send_P(200, "text/html; charset=utf-8", PAGE_MIC);
    } else {
        webServer.send_P(200, "text/html; charset=utf-8", PAGE_SPK);
    }
}

// ---- Board A: receive ADPCM pushed by the phone ----
// The upload callback fires per chunk (~1.4KB) and writes straight into the ring, so
// no full-body buffer is needed and a 400-byte batch costs no heap.
static size_t upBytes = 0;
static bool   upBadEnc = false;

void handlePushUpload() {
    // !! Critical pitfall !!
    // FunctionRequestHandler binds the same callback to both upload() and raw(). A POST
    // whose Content-Type is not multipart/* takes the raw() path, where _currentUpload is
    // null, so webServer.upload() dereferences null -> LoadProhibited -> reboot, AP gone.
    // Hence the Content-Type check first (headers are collected in startWeb()).
    if (!webServer.header("Content-Type").startsWith("multipart/")) {
        upBadEnc = true;
        return;
    }
    // Audio arriving while the board is not in TX role is dropped, but say so once -
    // otherwise the phone pushes and the board stays silent, looking like a dead button.
    if (gRole != ROLE_TX) {
        static bool warnedRole = false;
        if (!warnedRole) {
            warnedRole = true;
            Serial.println("[UP] 手机在推音频, 但板子不是 TX 角色 -> 丢弃 (串口输 mic 切过去)");
        }
        return;
    }
    HTTPUpload& up = webServer.upload();
    if (up.status == UPLOAD_FILE_START) {
        upBytes = 0;
        upBadEnc = false;
        return;
    }
    if (up.status == UPLOAD_FILE_WRITE) {
        if (!up.currentSize) return;
        micPush(up.buf, up.currentSize);
        upBytes += up.currentSize;
        txLastMicMs = millis();     // release detection: no new data for 600ms stops the stream
        // First chunk while armed -> let loop() start streaming. micStream() must not be
        // called here: it would block the HTTP response and break the phone's push loop.
        gTxWanted = true;
        return;
    }
    // UPLOAD_FILE_END needs no work: data was already written while receiving
}

void handlePushDone() {
    pushReqs++;
    // Log the first two requests: it proves the phone POST really reached the board and
    // shows whether Content-Type is multipart (old pages send octet-stream -> 400).
    if (pushReqs <= 2) {
        Serial.print("[UP] 收到推流请求 #"); Serial.print((int)pushReqs);
        Serial.print("  ");                  Serial.print((int)upBytes); Serial.print("B");
        Serial.print("  CT=");               Serial.print(webServer.header("Content-Type"));
        Serial.println();
    }
    if (upBadEnc) {
        // Dozens of requests per second: warn once, do not flood the port
        static bool warned = false;
        if (!warned) {
            warned = true;
            Serial.print("[UP] 拒绝: Content-Type=\"");
            Serial.print(webServer.header("Content-Type"));
            Serial.println("\" 不是 multipart/form-data (页面是旧版, 刷新页面)");
        }
        webServer.send(400, "text/plain; charset=utf-8", "need multipart/form-data");
        return;
    }
    webServer.sendHeader("Cache-Control", "no-store");
    webServer.send(200, "application/json", "{\"ok\":true}");
}

void handleFlush() {
    micClear();
    webServer.sendHeader("Cache-Control", "no-store");
    webServer.send(200, "application/json", "{\"ok\":true}");
}

// ---- Board B: hand PCM to the page ----
// Header (12 bytes): 'W' 'A' ver flags | count(2) | startSeq(4) | rsv(2), followed
// by count little-endian int16 samples.
void handlePcm() {
    const int MAX_OUT = 1920;        // At most 240ms per call, enough for the page to refill its playback queue

    uint32_t since = 0;
    if (webServer.hasArg("since")) {
        since = (uint32_t)strtoul(webServer.arg("since").c_str(), nullptr, 10);
    }

    uint32_t head = pcmHead;
    uint32_t oldest = (head > PCM_RING_SAMPLES) ? (head - PCM_RING_SAMPLES) : 0;

    if (since < oldest) since = oldest;      // Requested position was overwritten: jump to the oldest available sample
    int count = 0;
    if (head > since) {
        uint32_t avail = head - since;
        count = (avail > (uint32_t)MAX_OUT) ? MAX_OUT : (int)avail;
    }

    uint8_t hdr[12];
    hdr[0] = 'W'; hdr[1] = 'A'; hdr[2] = 1; hdr[3] = 0;
    hdr[4] = (uint8_t)(count >> 8);  hdr[5] = (uint8_t)(count & 0xFF);
    hdr[6] = (uint8_t)(since >> 24); hdr[7] = (uint8_t)(since >> 16);
    hdr[8] = (uint8_t)(since >> 8);  hdr[9] = (uint8_t)(since & 0xFF);
    hdr[10] = 0; hdr[11] = 0;

    webServer.sendHeader("Cache-Control", "no-store");
    webServer.setContentLength((size_t)count * 2 + 12);
    webServer.send(200, "application/octet-stream", "");
    webServer.sendContent((const char*)hdr, 12);

    if (count > 0) {
        // The ring may wrap: send two segments instead of building a temporary array
        uint32_t start = since % PCM_RING_SAMPLES;
        int first = (int)(PCM_RING_SAMPLES - start);
        if (first > count) first = count;
        webServer.sendContent((const char*)&pcmRing[start], (size_t)first * 2);
        if (count > first) {
            webServer.sendContent((const char*)&pcmRing[0], (size_t)(count - first) * 2);
        }
    }
}

void handleStatus() {
    // ---- Phone telemetry ----
    // The page reports its state every 800ms (v/t/m/p/f). Only changes are printed, so
    // it never floods, yet a dead button can be localized from the log alone:
    //   [UI] button pressed  -> the event arrived, the problem is mic or upload
    //   [UI] mic ready       -> permission granted
    //   [UI] N batches sent  -> fetch() really left the phone
    //   no [UI] line at all  -> the page is not running (stale cache / JS error)
    if (webServer.hasArg("v")) {
        // lastT/lastM start at 0 (a fresh page is "not pressed / mic off"), otherwise the
        // first /status call would report a bogus "released after 0 frames".
        static int  lastT = 0, lastM = 0, lastP = -1, lastF = -1;
        static bool pageHello = false;
        int t = webServer.hasArg("t") ? webServer.arg("t").toInt() : 0;
        int m = webServer.hasArg("m") ? webServer.arg("m").toInt() : 0;
        int p = webServer.hasArg("p") ? webServer.arg("p").toInt() : 0;
        int f = webServer.hasArg("f") ? webServer.arg("f").toInt() : 0;
        int c = webServer.hasArg("c") ? webServer.arg("c").toInt() : 0;
        int n = webServer.hasArg("n") ? webServer.arg("n").toInt() : 0;

        if (!pageHello) {
            pageHello = true;
            Serial.print("[WEB] 页面已连上 (v"); Serial.print(webServer.arg("v"));
            Serial.print(")  板子角色=");
            Serial.println(gRole == ROLE_TX ? "TX" : (gRole == ROLE_RX ? "RX" : "IDLE"));
            if (gRole == ROLE_TX) {
                Serial.println("[WEB] 手机按住按钮说话 -> 板子自动开始发流 (松手即停)");
            } else if (gRole == ROLE_RX) {
                Serial.println("[WEB] 点\"开始播放\"解锁声音; 之后保持页面在前台");
            } else {
                Serial.println("[WEB] !! 板子是 IDLE, 收发都停了: 串口输 mic 或 spk");
            }
        }
        // board B page: whether "start playing" was clicked
        if (webServer.hasArg("r")) {
            static int lastR = 0;
            int r = webServer.arg("r").toInt();
            if (r != lastR) {
                lastR = r;
                Serial.println(r ? "[UI] B 板 开始播放 (音频已解锁)"
                                 : "[UI] B 板 停止播放");
            }
        }
        if (m != lastM) {
            lastM = m;
            if (m) Serial.println("[UI] 麦克风 已就绪");
            else   Serial.println("[UI] 麦克风 未开启或被拒 (页面红框里写着原因)");
        }
        if (t != lastT) {
            if (t) {
                Serial.println("[UI] 手机按下按钮");
            } else {
                // The release line is the most informative: 0 frames captured means the mic or the
                // audio context never started; frames captured but 0 batches means the upload path.
                Serial.print("[UI] 手机松开按钮  本次采集 "); Serial.print(n);
                Serial.print(" 帧, 推送 ");                   Serial.print(p);
                Serial.print(" 批, 板子收到 ");               Serial.print((int)pushReqs);
                Serial.println(" 次");
                if (n == 0) {
                    Serial.println("[UI] !! 采集到 0 帧: 麦克风没在采集 (AudioContext 被挂起/权限被拒, 页面红框会写原因)");
                } else if (pushReqs == 0) {
                    Serial.println("[UI] !! 采集到了但一个请求都没到板子: 网页 /push 没发出去或地址不通");
                }
            }
            lastT = t;
        }
        if (p != lastP) {
            if (p > lastP && lastP >= 0) {
                Serial.print("[UI] 已推送 "); Serial.print(p);
                Serial.print(" 批 (板子已收 "); Serial.print((int)pushReqs); Serial.println(" 次)");
            }
            lastP = p;
        }
        if (f != lastF) {
            if (f > lastF && lastF >= 0) {
                Serial.print("[UI] 推送失败 "); Serial.print(f);
                Serial.print(" 次  HTTP=");    Serial.println(c);
            }
            lastF = f;
        }
    }

    // Frame rate from a 1-second sliding window
    static uint32_t lastMs = 0, lastFrames = 0;
    static float fps = 0;
    uint32_t now = millis();
    if (now - lastMs >= 900) {
        uint32_t f = (gRole == ROLE_TX) ? txFrames : rxFrames;
        uint32_t df = f - lastFrames;
        float dt = (float)(now - lastMs) / 1000.0f;
        if (dt > 0.05f) fps = (float)df / dt;
        lastFrames = f;
        lastMs = now;
    }

    // uplink rate / buffer depth
    float kbs = 0;
    float bufMs = 0;
    if (gRole == ROLE_TX) {
        static uint32_t lastBytes = 0, lastBMs = 0;
        if (now - lastBMs >= 900) {
            kbs = (float)(txMicBytes - lastBytes) / ((float)(now - lastBMs) / 1000.0f) / 1024.0f;
            lastBytes = txMicBytes;
            lastBMs = now;
        }
        bufMs = (float)micUsed * 1000.0f / (float)(SAMPLE_RATE / 2);   // 80B = 20ms
    }

    String j = "{";
    j += "\"mode\":\"";
    j += (gRole == ROLE_TX ? "TX" : (gRole == ROLE_RX ? "RX" : "IDLE"));
    j += "\",\"ip\":\"";   j += (gWifiOn ? WiFi.softAPIP().toString() : String(""));
    j += "\",\"fps\":";    j += String(fps, 2);
    j += ",\"kbs\":";      j += String(kbs, 2);
    j += ",\"bufMs\":";    j += String(bufMs, 1);
    j += ",\"frames\":";   j += String((int)(gRole == ROLE_TX ? txFrames : rxFrames));
    j += ",\"lost\":";     j += String((int)rxLost);
    j += ",\"underrun\":"; j += String((int)txUnderrun);
    j += ",\"drops\":";    j += String((int)txMicDrops);
    j += ",\"noise\":";    j += String((int)rxNoise);
    j += ",\"streaming\":"; j += (gStreaming ? "true" : "false");
    j += ",\"tone\":";     j += (gUseTone ? "true" : "false");

    // ---- AP diagnostics: these fields pin down "the phone cannot see the SSID" ----
    gApClients = gWifiOn ? (uint8_t)WiFi.softAPgetStationNum() : 0;
    j += ",\"ap\":";      j += (gWifiOn ? "true" : "false");
    j += ",\"ch\":";      j += String((int)gApChannelNow);
    j += ",\"sta\":";     j += String((int)gApClients);
    j += ",\"heap\":";    j += String((int)(ESP.getFreeHeap() / 1024));
    j += "}";
    webServer.sendHeader("Cache-Control", "no-store");
    webServer.send(200, "application/json", j);
}

// ==================== AP: channel and TX power ====================
// Two boards on one desk hit two traps that make phones see only one AP:
//   1) same channel -> co-channel pressure, the scan list keeps the stronger one;
//   2) 20dBm at ~10cm -> the phone front end is blocked and the other AP vanishes.
// Default: channels split by role (A=6 / B=11, non-overlapping), 15dBm.
// Channel 1 was tried first, but it is crowded by home routers in practice and the
// low-power beacon gets buried. The scan-based picker was dropped as well: on
// ESP32-S3 softAP() sometimes returns true without broadcasting any beacon.
// The AP and the FLRC link share the same 2.4GHz antenna, so the AP desenses the receiver.
// Channel 11 is 2462MHz - only 12MHz from the 2450MHz carrier - and that alone costs about
// 15% of the frames. Channel 1 is 2412MHz, 38MHz away, which is the best separation the
// band offers. Both roles use it: each AP only carries a few KB/s, so sharing one channel
// costs nothing, and "two APs on different channels" is not worth 15% packet loss.
static uint8_t channelForRole() {
    return 1;
}

// dBm -> ESP32 power level enum
static wifi_power_t dbmToPower(int dbm) {
    if (dbm <= 8)  return WIFI_POWER_8_5dBm;
    if (dbm <= 11) return WIFI_POWER_11dBm;
    if (dbm <= 13) return WIFI_POWER_13dBm;
    if (dbm <= 15) return WIFI_POWER_15dBm;
    if (dbm <= 17) return WIFI_POWER_17dBm;
    if (dbm <= 19) return WIFI_POWER_19dBm;
    return WIFI_POWER_19_5dBm;
}

// Bring the AP up, 3 attempts. WiFi.mode(WIFI_AP) must be followed by a delay:
// calling softAP() right away sometimes returns success without broadcasting any
// beacon (the phone never sees the SSID). So check the real IP, not just the return value.
static bool apStart(const char* ssid, uint8_t ch) {
    if (ch < 1 || ch > 13) ch = 6;

    for (int attempt = 1; attempt <= 3; attempt++) {
        // Clean up first: previous AP, leftover STA link, then WiFi fully off
        WiFi.softAPdisconnect(true);
        WiFi.mode(WIFI_OFF);
        delay(300);

        WiFi.persistent(false);
        WiFi.mode(WIFI_AP);
        delay(400);                 // This delay cannot be skipped - it is the number one cause of "SSID not found"

        WiFi.softAPConfig(IPAddress(192, 168, 4, 1), IPAddress(192, 168, 4, 1),
                          IPAddress(255, 255, 255, 0));

        if (WiFi.softAP(ssid, AP_PASS, ch, 0, 4)) {
            WiFi.setSleep(false);   // The AP must not use power save, or beacons get irregular and harder to find
            WiFi.setTxPower(dbmToPower(gApPowerDbm));
            delay(250);
            IPAddress ip = WiFi.softAPIP();
            if ((uint32_t)ip != 0) {
                Serial.print("[WEB] softAP OK  模式="); Serial.print((int)WiFi.getMode());
                Serial.print("  IP="); Serial.print(ip);
                Serial.print("  功率="); Serial.print((int)gApPowerDbm);
                Serial.println("dBm");
                return true;
            }
            Serial.println("[WEB] softAP 返回 true 但没拿到 IP, 重来");
        } else {
            Serial.print("[WEB] 第"); Serial.print(attempt);
            Serial.println("次 softAP 失败, 重试…");
        }
        delay(500);
    }
    return false;
}

void startWeb() {
    if (gWifiOn) return;

    const char* ssid = gSsidOverride ? gSsidOverride
                                     : ((gRole == ROLE_TX) ? AP_SSID_TX : AP_SSID_RX);

    uint8_t ch = gApChannel;
    if (ch == 0) {
        ch = channelForRole();
        Serial.print("[WEB] 自动信道(按角色): "); Serial.println(ch);
    } else {
        Serial.print("[WEB] 使用指定信道 "); Serial.println(ch);
    }

    if (!apStart(ssid, ch)) {
        Serial.println("[WEB] 热点启动失败 (3 次都失败)");
        Serial.println("[WEB]   输入 wifi 重开一次; 仍失败请查供电/天线");
        return;
    }
    gApChannelNow = ch;

    // Register routes once only: WebServer::on() appends to the handler list, so
    // repeated stopWeb()/startWeb() would stack several callbacks on the same URI.
    static bool routesReady = false;
    if (!routesReady) {
        // !! Headers must be registered explicitly !!
        // WebServer::_collectAllHeaders defaults to false (WebServer.h:327), so no header is
        // collected at all and webServer.header("Content-Type") always returns "" - the
        // multipart check in handlePushUpload() would then fail 100% of the time.
        static const char* kHdrs[] = {"Content-Type", "Content-Length"};
        webServer.collectHeaders(kHdrs, 2);

        webServer.on("/",        handleIndex);
        webServer.on("/status",  handleStatus);
        webServer.on("/pcm",     handlePcm);
        webServer.on("/flush",   HTTP_POST, handleFlush);
        // uplink: completion callback + chunk callback (writes the ring while receiving)
        webServer.on("/push",    HTTP_POST, handlePushDone, handlePushUpload);
        // Every page load requests /favicon.ico; answer 204 so it does not fall through to
        // onNotFound() and get logged as a 404.
        webServer.on("/favicon.ico", []() { webServer.send(204, "text/plain", ""); });

        webServer.onNotFound([]() {
            // Log the first three hits to catch "the page POSTs to a wrong path" (never seen normally)
            static uint8_t n404 = 0;
            String u = webServer.uri();
            if (n404 < 3 && !u.endsWith("/favicon.ico")) {
                n404++;
                Serial.print("[WEB] 404  ");
                Serial.print(webServer.method() == HTTP_POST ? "POST " : "GET ");
                Serial.println(u);
            }
            webServer.send(404, "text/plain; charset=utf-8", "404");
        });
        routesReady = true;
    }
    webServer.begin();

    gWifiOn = true;
    Serial.print("[WEB] 热点 "); Serial.print(ssid);
    Serial.print(" / ");         Serial.print(AP_PASS);
    Serial.print("  信道 ");     Serial.print((int)ch);
    Serial.print(" (");          Serial.print(2407 + ch * 5); Serial.print("MHz)");
    Serial.print("  功率 ");     Serial.print((int)gApPowerDbm); Serial.print("dBm");
    Serial.print("  IP ");       Serial.print(WiFi.softAPIP());
    Serial.print("  MAC ");      Serial.println(WiFi.softAPmacAddress());
    Serial.print("[WEB] 手机打开 http://"); Serial.print(WiFi.softAPIP());
    Serial.print("/   (空闲堆 "); Serial.print(ESP.getFreeHeap() / 1024);
    Serial.println("KB)");
    Serial.println("[WEB] 手机搜不到热点? 1) 手机 WiFi 关掉再开 2) 串口 ch 6 换信道");
    Serial.println("[WEB]   3) 串口 power 20 加大功率 4) 仍不行查天线/供电");
    if (gRole == ROLE_TX) {
        Serial.println("[WEB] A 板: 手机连上后按住按钮说话");
        Serial.println("[WEB] 注意: http 不是安全上下文, 麦克风需在 Chrome 里加白名单");
    } else {
        Serial.println("[WEB] B 板: 手机连上后点\"开始播放\"");
    }
}

void stopWeb() {
    if (!gWifiOn) return;
    webServer.stop();
    WiFi.softAPdisconnect(true);
    WiFi.mode(WIFI_OFF);
    delay(150);          // Give the driver time to really stop, otherwise startWeb() right after fails
    gWifiOn = false;
    gApClients = 0;
    gSsidOverride = nullptr;
    Serial.println("[WEB] 热点已关闭");
}

// ==================== Role switching ====================
// Persist the role in NVS so the next boot restores it automatically. It is a
// separate function because the TX branch never returns from micStream().
static void saveRoleToNvs() {
    prefs.begin("w16", false);
    prefs.putUChar("role", (uint8_t)gRole);
    prefs.end();
}

// Every recompile changes this string, so the hash changes with it. It is stored in NVS and
// compared at boot: a different stamp means "this firmware has just been flashed". In that
// case the saved role is dropped, so a freshly flashed board really comes up in IDLE
// (standby). Without it, NVS still held the role of the previous build and the board opened
// its hotspot and resumed mic/spk the moment the upload finished.
static uint32_t buildStamp() {
    const char* s = __DATE__ " " __TIME__;
    uint32_t h = 2166136261u;                  // FNV-1a
    while (*s) { h ^= (uint8_t)(*s++); h *= 16777619u; }
    return h;
}

// switchRole() only sets the role and the AP. Streaming is not started here: board A
// streams only while the phone is pushing audio (see the release check in micStream()).
// It used to enter micStream() at boot and sent silence frames at 50 frames/s with no
// phone attached and no command typed.
void switchRole(Role r) {
    // Typing the same role again reopens the AP and must say something: the role may have
    // been restored from NVS (already TX) and a silent "mic" looks like a lost command.
    if (r == gRole) {
        if (r == ROLE_IDLE) {
            Serial.println("[MODE] 已经是 IDLE (不收发, 热点已关)");
            return;
        }
        if (!gWifiOn) {
            Serial.print("[MODE] 已经是 ");
            Serial.print(r == ROLE_TX ? "MIC" : "SPK");
            Serial.println(", 但热点没开, 正在重开…");
            startWeb();
        } else {
            Serial.print("[MODE] 已经是 ");
            Serial.print(r == ROLE_TX ? "MIC" : "SPK");
            Serial.print(", 热点 ");
            Serial.print(r == ROLE_TX ? AP_SSID_TX : AP_SSID_RX);
            Serial.println(" 正在运行 (重复输入=重开热点)");
        }
        if (r == ROLE_TX && !gStreaming) {
            Serial.println("[MODE] 现在是待发: 手机按住按钮说话才会发流");
        }
        return;
    }

    // mic/spk still work when the radio failed to init - AP and web page are independent
    // of the radio. Returning early here used to leave the AP down whenever the radio was
    // broken, so the phone never saw W16-MIC and it looked like a WiFi fault.
    if (!gRadioOk && r != ROLE_IDLE) {
        Serial.println("[MODE] 注意: 射频未初始化, 热点照常打开, 但语音传不出去");
        Serial.println("[MODE]   网页录音/播放可用; 收发请先修射频接线");
    }

    gStreaming = false;
    if (gRadioOk) radio.standby();
    delay(5);

    // The SSID follows the role (A = W16-MIC / B = W16-SPK). The old AP must be torn down
    // first, otherwise startWeb() returns early because gWifiOn is still true.
    if (gWifiOn) stopWeb();

    if (r == ROLE_TX) {
        gRole = ROLE_TX;
        saveRoleToNvs();          // Must be saved before micStream(): it never returns
        micClear();
        txFrames = 0; txUnderrun = 0; txMicBytes = 0; txMicDrops = 0;
        txSeq = 0;
        ledBlue();
        Serial.println("[MODE] MIC —— 手机麦克风转发端 (网页按住说话)");
        startWeb();
        if (!gRadioOk) return;       // radio down: keep the web page only
        gTxWanted = false;
        radio.standby();
        delay(2);
        Serial.println("[MODE] 待发: 手机按住按钮说话才会开始发流 (松手即停)");
    } else if (r == ROLE_RX) {
        gRole = ROLE_RX;
        saveRoleToNvs();
        rxSeqInit = false;
        rxLastSeq = 0;
        rxFrames = 0; rxLost = 0; rxPackets = 0; rxNoise = 0; rxOtherErr = 0;
        rxPrevFrames = 0; rxStatMs = millis();
        rxPrevNoise = 0; rxPrevOther = 0; rxIdleLogged = false;
        pcmHead = 0;
        rxSilent = true;
        adpcmDecReset();
        // Drop the concealment history too: replaying the previous session's last frame
        // into a fresh stream would be a burst of stale audio.
        concealPct = 0;
        memset(lastFramePcm, 0, sizeof(lastFramePcm));
        if (gRadioOk) enterRx();
        ledBlue();
        Serial.println("[MODE] SPK —— 接收端 (网页点开始播放)");
        Serial.println("[MODE] 射频已经在监听, 不用等手机连上; 手机只负责网页播放");
        Serial.println("[MODE] 空闲时不打印任何东西, 收到 A 板语音才出现 [STAT] RX");
        startWeb();
    } else {
        gRole = ROLE_IDLE;
        saveRoleToNvs();
        if (gRadioOk) radio.standby();
        ledOff();
        stopWeb();
        Serial.println("[MODE] IDLE —— 射频 standby");
    }
}

// ==================== Serial ====================
void printHelp() {
    Serial.println();
    Serial.println("Commands (type and press Enter):");
    Serial.println("  mic       A 板: 开热点 W16-MIC, 转发手机麦克风 (按住说话才发流)");
    Serial.println("  spk       B 板: 收流 + 热点 W16-SPK + 网页播放 (别名 rx)");
    Serial.println("  idle      停止收发 (射频 standby) (别名 stop)");
    Serial.println("  tone      A 板: 不用手机, 改发内置 1kHz 测试音");
    Serial.println("  wifi      开/关热点");
    Serial.println("  web       只开网页热点 W16-WEB (不依赖射频/角色), 排查搜不到 SSID");
    Serial.println("  wtest     只起一个测试热点 W16-TEST(20s), 排查搜不到 SSID");
    Serial.println("  ch N      热点信道: 0=按角色错开(A板6/B板11) / 1~13=强制");
    Serial.println("  power N   热点功率 5/8/11/15/20 dBm (默认 15, 信号弱就调大)");
    Serial.println("  auto      开/关 \"上电自动恢复角色\" (默认关; 关了每次上电都停在 IDLE/standby)");
    Serial.println("  status    打印计数");
    Serial.println("  help      本列表");
    Serial.println();
    Serial.println("  用法: A 板 mic -> 手机连 W16-MIC  按住按钮说话");
    Serial.println("        B 板 spk -> 手机连 W16-SPK  点开始播放");
    Serial.println("  两块板必须烧同一版固件 (包长 83 / 同步字 / 速率都要一致)");
    Serial.println();
    Serial.println("  !! 手机麦克风需要安全上下文 !!");
    Serial.println("  Chrome 打开 chrome://flags/#unsafely-treat-insecure-origin-as-secure");
    Serial.println("  填入 http://192.168.4.1 -> Enabled -> Relaunch");
    Serial.println();
    Serial.flush();     // Flush this batch before the next log line, otherwise bytes get interleaved and lost
}

void printStatus() {
    Serial.print("[STATUS] 模式=");
    Serial.print(gRole == ROLE_TX ? "MIC" : (gRole == ROLE_RX ? "SPK" : "IDLE"));
    Serial.print("  转发="); Serial.print(gStreaming ? "是" : "否");
    Serial.print("  测试音="); Serial.print(gUseTone ? "是" : "否");
    Serial.print("  auto="); Serial.println(gAutoRestore ? "开" : "关");

    Serial.print("[STATUS] 发送: "); Serial.print((int)txFrames);
    Serial.print(" 帧 / seq="); Serial.print((int)txSeq);
    Serial.print("  上行 "); Serial.print((int)(txMicBytes / 1024));
    Serial.print("KB  欠载 "); Serial.print((int)txUnderrun);
    Serial.print("  溢出丢 "); Serial.print((int)txMicDrops);
    Serial.print("B  缓存 "); Serial.print((int)micUsed); Serial.println("B");

    Serial.print("[STATUS] 接收: "); Serial.print((int)rxFrames);
    Serial.print(" 帧  丢 "); Serial.print((int)rxLost);
    Serial.print("  收包 "); Serial.print((int)rxPackets);
    Serial.print("  噪声 "); Serial.print((int)rxNoise);
    Serial.print("  其他 "); Serial.println((int)rxOtherErr);

    Serial.print("[STATUS] PCM 缓冲 "); Serial.print((int)(PCM_RING_SAMPLES / 8));
    Serial.print("ms  ");
    if (gWifiOn) {
        gApClients = (uint8_t)WiFi.softAPgetStationNum();
        Serial.print("热点开 SSID=");
        Serial.print(gRole == ROLE_TX ? AP_SSID_TX : AP_SSID_RX);
        Serial.print("  信道="); Serial.print((int)gApChannelNow);
        Serial.print("  功率="); Serial.print((int)gApPowerDbm); Serial.print("dBm");
        Serial.print("  IP="); Serial.print(WiFi.softAPIP());
        Serial.print("  已连="); Serial.print((int)gApClients); Serial.print("台");
    } else {
        Serial.print("热点关");
    }
    Serial.println();

    Serial.print("[STATUS] 空闲堆 "); Serial.print(ESP.getFreeHeap() / 1024);
    Serial.println("KB");
    Serial.flush();
}

void handleCommand(char* s) {
    int n = (int)strlen(s);
    while (n > 0 && (s[n - 1] == ' ' || s[n - 1] == '\t')) s[--n] = 0;
    if (n == 0) return;

    // Echo the input line so it is visible that the board actually received the command
    Serial.print("> "); Serial.println(s);

    if (!strcmp(s, "help") || !strcmp(s, "?")) { printHelp(); return; }
    if (!strcmp(s, "mic") || !strcmp(s, "tx"))  { gUseTone = false; switchRole(ROLE_TX); return; }
    if (!strcmp(s, "spk") || !strcmp(s, "rx"))  { switchRole(ROLE_RX); return; }
    if (!strcmp(s, "idle") || !strcmp(s, "stop")) { switchRole(ROLE_IDLE); return; }
    if (!strcmp(s, "status")) { printStatus(); return; }

    // AP self-test: does not touch the radio, just brings the AP up for 20 seconds.
    // Two-way triage: W16-TEST visible -> WiFi is fine, the role flow is the problem;
    // not visible -> antenna / power / the module itself.
    if (!strcmp(s, "wtest")) {
        bool wasOn = gWifiOn;
        if (wasOn) stopWeb();
        Serial.println("[WTEST] 单独起热点 W16-TEST / 12345678, 20 秒后自动关");
        if (apStart("W16-TEST", 9)) {
            for (int i = 0; i < 20; i++) {
                Serial.print("[WTEST] 剩 "); Serial.print(20 - i);
                Serial.print("s  已连 "); Serial.print((int)WiFi.softAPgetStationNum());
                Serial.print(" 台  IP "); Serial.println(WiFi.softAPIP());
                delay(1000);
            }
            WiFi.softAPdisconnect(true);
            WiFi.mode(WIFI_OFF);
            delay(300);
            Serial.println("[WTEST] 结束");
        } else {
            Serial.println("[WTEST] AP 起不来 -> 换 USB 口 / 换粗线 / 检查天线");
        }
        if (wasOn) startWeb();
        return;
    }
    // Web-only AP: no radio dependency, ignores the role, SSID is always W16-WEB
    if (!strcmp(s, "web")) {
        if (gWifiOn) { stopWeb(); return; }
        gSsidOverride = "W16-WEB";
        Serial.println("[CMD] 纯网页热点 W16-WEB / 12345678 (与射频、角色都无关)");
        startWeb();
        return;
    }
    if (!strcmp(s, "wifi")) {
        if (gRole == ROLE_IDLE) { Serial.println("[CMD] 先输入 mic 或 spk"); return; }
        if (gWifiOn) stopWeb(); else startWeb();
        return;
    }
    if (!strncmp(s, "ch ", 3)) {
        int v = atoi(s + 3);
        if (v < 0 || v > 13) { Serial.println("[CMD] 信道 0~13 (0=按角色错开)"); return; }
        gApChannel = (uint8_t)v;

        if (gApChannel == 0) {
            Serial.println("[CMD] 信道 -> 按角色自动 (A板6 / B板11)");
        } else {
            Serial.print("[CMD] 信道 -> "); Serial.print((int)gApChannel);
            Serial.println(", 正在重开热点… (已记住, 重启不丢)");
        }
        // Store the channel in NVS so a tuned value survives a reboot
        prefs.begin("w16", false);
        prefs.putUChar("ch", gApChannel);
        prefs.end();

        // No scanning any more, reopening takes ~0.7s and applies immediately
        if (gRole != ROLE_IDLE) {
            if (gWifiOn) stopWeb();
            startWeb();
        }
        return;
    }
    if (!strncmp(s, "power ", 6)) {
        int v = atoi(s + 6);
        if (v < 2 || v > 20) { Serial.println("[CMD] 功率 2~20 dBm (建议 5/8/11/15/20)"); return; }
        gApPowerDbm = (uint8_t)v;
        Serial.print("[CMD] 功率 -> "); Serial.print((int)gApPowerDbm);
        Serial.println("dBm, 正在重开热点… (已记住, 重启不丢)");
        prefs.begin("w16", false);
        prefs.putUChar("pw", gApPowerDbm);
        prefs.end();

        if (gRole != ROLE_IDLE) {
            if (gWifiOn) stopWeb();
            startWeb();
        }
        return;
    }

    if (!strcmp(s, "tone")) {
        gUseTone = true;
        Serial.println("[CMD] 改用内置 1kHz 测试音 (不用手机)");
        if (gRole != ROLE_TX) {
            Serial.println("[CMD] 正在切到 mic 模式…");
            switchRole(ROLE_TX);
        }
        // switchRole() no longer enters the streaming loop; loop() starts it
        gTxWanted = true;
        return;
    }

    // Whether to restore the last role at boot: some prefer "boot and wait for the phone",
    // others "boot and do nothing until a command". Stored in NVS.
    if (!strcmp(s, "auto")) {
        gAutoRestore = gAutoRestore ? 0 : 1;
        prefs.begin("w16", false);
        prefs.putUChar("auto", gAutoRestore);
        prefs.end();
        Serial.print("[CMD] 上电自动恢复角色 -> ");
        Serial.println(gAutoRestore ? "开 (上电直接进上次的 mic/spk, 热点自动开)"
                                    : "关 (上电停在 IDLE, 等 mic/spk 指令)");
        return;
    }

    Serial.print("[CMD] 未知指令: "); Serial.println(s);
    Serial.println("       输入 help 看列表");
}

void pollSerial() {
    static char line[40];
    static uint8_t n = 0;
    while (Serial.available()) {
        char c = (char)Serial.read();
        if (c == '\r') continue;
        if (c == '\n') {
            line[n] = 0;
            if (n) handleCommand(line);
            n = 0;
        } else if (n < sizeof(line) - 1) {
            line[n++] = (char)tolower((int)c);
        }
    }
}

// ==================== Main loop ====================
void loop() {
    // Board A runs pollSerial + handleClient inside micStream() and never gets here;
    // this only handles RX and IDLE.
    pollSerial();

    if (gRole == ROLE_RX) {
        AudioPacket p;
        for (int i = 0; i < 6; i++) {
            if (!rxPoll(&p)) break;
            handleRxPacket(p);
        }

        if (gWifiOn) {
            uint32_t t0 = micros();
            webServer.handleClient();
            uint32_t dt = micros() - t0;
            if (dt > rxSrvMaxUs) rxSrvMaxUs = dt;   // shown in [STAT]: >20ms means frames are lost here
        }
        rxStatsTick();
        return;
    }

    if (gRole == ROLE_TX && !gStreaming) {
        if (gWifiOn) webServer.handleClient();
        if (gTxWanted) {
            if (gRadioOk) {
                micStream();      // Runs 20ms per frame until release / idle
                return;
            }
            // Data arrives but the radio is down: say so, otherwise the silent log hides the cause
            gTxWanted = false;
            Serial.println("[TX] 收到手机音频, 但射频没初始化成功 -> 发不出去 (看上面 [RADIO] 行)");
        }
        delay(2);
        return;
    }

    delay(5);
}

// ==================== setup ====================
void setup() {
#if defined(ARDUINO_USB_CDC_ON_BOOT) && ARDUINO_USB_CDC_ON_BOOT
    Serial.setTxBufferSize(4096);
#endif
    Serial.begin(115200);
#if defined(ARDUINO_USB_CDC_ON_BOOT) && ARDUINO_USB_CDC_ON_BOOT
    Serial.setTxTimeoutMs(100);        // Wait for the host instead of dropping bytes when the ring is full
    unsigned long tWait = millis();
    while (!Serial && millis() - tWait < 2000) delay(10);   // wait for the serial monitor
#endif
    delay(200);

    ledOff();

    Serial.println();
    Serial.println("=== W16 (LR2021) Audio over FLRC + Phone Mic/Speaker ===");

    // Reset reason: if the AP vanishes or the page stalls because the board rebooted,
    // this tells brownout / panic / watchdog apart without guessing.
    {
        const char* why = "未知";
        esp_reset_reason_t rr = esp_reset_reason();
        switch (rr) {
            case ESP_RST_POWERON:   why = "上电"; break;
            case ESP_RST_EXT:       why = "外部复位(按了 RESET 键)"; break;
            case ESP_RST_SW:        why = "软件复位(烧录后正常)"; break;
            case ESP_RST_PANIC:     why = "程序崩溃(panic)! 上次跑挂了"; break;
            case ESP_RST_INT_WDT:   why = "中断看门狗复位!"; break;
            case ESP_RST_TASK_WDT:  why = "任务看门狗复位!"; break;
            case ESP_RST_WDT:       why = "看门狗复位!"; break;
            case ESP_RST_BROWNOUT:  why = "欠压复位! 供电不足实锤, 换粗线/换USB口/独立供电"; break;
            case ESP_RST_DEEPSLEEP: why = "深度睡眠唤醒"; break;
#if defined(ESP_RST_USB)
            case ESP_RST_USB:       why = "USB 复位(串口监视器打开/关闭时会触发, 正常)"; break;
#endif
            case ESP_RST_UNKNOWN:   why = "未知(多半是串口监视器开关瞬间的复位, 正常)"; break;
            default: break;
        }
        Serial.print("[INIT] 复位原因: "); Serial.println(why);
    }

    // AP station join/leave events with MAC, to see who actually connected
    WiFi.onEvent([](WiFiEvent_t event, WiFiEventInfo_t info) {
        const uint8_t* m = info.wifi_ap_staconnected.mac;
        char buf[18];
        snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X",
                 m[0], m[1], m[2], m[3], m[4], m[5]);
        Serial.print("[WEB] 手机已连上热点 ✓ MAC="); Serial.println(buf);
    }, ARDUINO_EVENT_WIFI_AP_STACONNECTED);
    WiFi.onEvent([](WiFiEvent_t event, WiFiEventInfo_t info) {
        const uint8_t* m = info.wifi_ap_stadisconnected.mac;
        char buf[18];
        snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X",
                 m[0], m[1], m[2], m[3], m[4], m[5]);
        Serial.print("[WEB] 手机从热点断开 ✗ MAC="); Serial.println(buf);
    }, ARDUINO_EVENT_WIFI_AP_STADISCONNECTED);

    Serial.print("[CFG] 采样 "); Serial.print(SAMPLE_RATE);
    Serial.print("Hz  16bit  mono  ADPCM4bit  帧="); Serial.print(FRAME_MS);
    Serial.println("ms");
    Serial.print("[CFG] 空中帧 "); Serial.print((unsigned int)sizeof(AudioPacket));
    Serial.print(" 字节 (seq2 + len1 + adpcm"); Serial.print(ADPCM_BYTES);
    Serial.println(")  50 帧/秒 = 4.15KB/s");
    Serial.print("[CFG] 缓冲: 上行 "); Serial.print(MIC_RING_CAP);
    Serial.print("B  下行 PCM "); Serial.print(PCM_RING_SAMPLES / 8);
    Serial.println("ms");

    SPI.begin(PIN_SCK, PIN_MISO, PIN_MOSI);

    if (!beginRadio()) {
        gRadioOk = false;
        Serial.println("[INIT] 射频初始化失败, 请检查接线");
        Serial.println("[INIT] 引脚: SCK=12 MISO=11 MOSI=10 NSS=47 RST=39 BUSY=21 DIO7=42");
        Serial.println("[INIT] 注意: 射频失败不影响热点! 输 mic/spk 或 web 照样能开 WiFi");
        Serial.println("[INIT]       只是语音传不出去, 网页录音/播放都正常");
    } else {
        gRadioOk = true;
    }

    gRole = ROLE_IDLE;
    if (gRadioOk) radio.standby();

    uint8_t savedRole = 255;
    prefs.begin("w16", false);                          // read-write: the build stamp is written back below
    savedRole   = prefs.getUChar("role", 255);
    gApChannel  = prefs.getUChar("ch",  gApChannel);    // keep default 0 = split by role when unset
    gApPowerDbm = prefs.getUChar("pw",  gApPowerDbm);   // keep default 15 when unset
    gAutoRestore= prefs.getUChar("auto", 0);            // 0 = stay in IDLE at boot (default)

    // First boot after a new build: forget the old role. A freshly flashed board must sit in
    // standby, not resume the role of whatever ran before it.
    uint32_t savedStamp  = prefs.getUInt("build", 0);
    bool     freshBuild  = (savedStamp != buildStamp());
    if (freshBuild) {
        savedRole    = 255;
        gAutoRestore = 0;
        prefs.putUChar("role", (uint8_t)ROLE_IDLE);
        prefs.putUChar("auto", 0);
        prefs.putUInt("build", buildStamp());
    }
    prefs.end();
    if (gApPowerDbm < 2 || gApPowerDbm > 20) gApPowerDbm = 15;   // guard against bad data

    if (freshBuild) {
        Serial.println("[INIT] 新固件首次启动: 已清除上次角色, 停在 IDLE/standby");
    }

    if (gAutoRestore && (savedRole == (uint8_t)ROLE_TX || savedRole == (uint8_t)ROLE_RX)) {
        Serial.println("[INIT] auto=on: 恢复上次角色并自动开热点 (输 auto 可关掉这个行为)");
        // Restore the role and the AP only, never start streaming: board A waits for real audio
        switchRole((Role)savedRole);
    } else {
        Serial.println("[INIT] 停在 IDLE (standby): 射频不收发, 热点不开");
        Serial.println("[INIT]   A 板输 mic -> 热点 W16-MIC   B 板输 spk -> 热点 W16-SPK");
        if (gAutoRestore) Serial.println("[INIT]   auto 已开, 但还没有保存的角色");
        else              Serial.println("[INIT]   想上电自动恢复角色: 输 auto");
    }
    printHelp();
}
